# Maktabati (مكتبتي) — Android

An Android application for creating, organizing, editing, and reading books.

## Project version

- `versionName`: **1.3.0**
- `versionCode`: **4**
- Android application ID: `com.maktabati.app`
- Minimum Android SDK: 23
- Compile / target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Kotlin: 2.0.21

## Open in Android Studio

1. Extract the ZIP archive.
2. Open the `MaktabatiNative` directory in Android Studio.
3. Allow Gradle sync to complete.
4. Run the `app` configuration on an Android device or emulator.

## Build with GitHub Actions

The workflow at `.github/workflows/android-build.yml` runs on pushes and pull requests to `main` / `master`, and can also be started manually from the **Actions** tab (`Android APK Build` → **Run workflow**).

The workflow installs JDK 17 and Gradle 8.9, verifies required project files, and runs:

```bash
gradle --no-daemon --stacktrace assembleDebug
```

When the build succeeds, download the `maktabati-debug-apk` artifact from the workflow run. This repository is configured to build a debug APK; it does not create a signed release APK.

## App language and display name

- Arabic device locale: `مكتبتي`
- English device locale: `My Library`
- French device locale: `Ma bibliothèque`

On first launch, the interface follows the device language when it is Arabic, English, or French. The selected in-app language is saved and used on later launches. The book-language selector is separate and searchable.

## Data compatibility

The app continues to use the existing private app storage and JSON book-library format. Keep the same application ID when installing updates so Android treats the new APK as an update to the existing app. Back up the library before installing a new build.

## Notes

- The project ZIP contains source code and GitHub Actions configuration, not an APK.
- A successful GitHub Actions run is the final confirmation that the APK compiles in GitHub's build environment.
