package com.maktabati.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.util.LruCache
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.PI

private const val GREEN = 0xFF176044

@Volatile private var activeAppLanguage: String = "en"
private val frenchUi: Map<String, String> = mapOf(
    "Saved locally" to "Enregistré localement",
    "Bookmark" to "Marque-page",
    "Saved" to "Enregistrée",
    "Reset" to "Réinitialiser",
    "Duplicate book" to "Dupliquer le livre",
    "Book duplicated" to "Livre dupliqué",
    "pages selected" to "pages sélectionnées",
    "Delete selected" to "Supprimer la sélection",
    "Clear temporary files" to "Nettoyer les fichiers temporaires",
    "Temporary files" to "Fichiers temporaires",
    "Temporary files cleared." to "Fichiers temporaires nettoyés.",
    "Remove temporary cache files that the app can recreate. Books and page images will not be deleted." to "Supprime les fichiers temporaires que l’application peut recréer. Les livres et les images des pages ne seront pas supprimés.",
    "New page" to "Nouvelle page",
    "Back cover" to "Quatrième de couverture",
    " - Copy" to " - Copie",
    "New book settings" to "Paramètres du nouveau livre",
    "Book title *" to "Titre du livre *",
    "Author" to "Auteur",
    "Description" to "Description",
    "Book language" to "Langue du livre",
    "Search languages" to "Rechercher des langues",
    "Each page will automatically use the dimensions and proportions of its selected image. No A4/A5 selection or manual width and height are required." to "Chaque page adoptera automatiquement les dimensions et les proportions de l’image sélectionnée. Aucun format A4/A5 ni aucune dimension manuelle ne sont nécessaires.",
    "Optional cover image" to "Image de couverture (facultatif)",
    "Front cover" to "Couverture avant",
    "Page 1" to "Page 1",
    "Create book" to "Créer le livre",
    "Cancel" to "Annuler",
    "Your Library" to "Votre bibliothèque",
    "Organize and find your books easily." to "Organisez et retrouvez facilement vos livres.",
    "Create new book" to "Créer un livre",
    "Search title, author, description or tags..." to "Rechercher par titre, auteur, description ou étiquettes…",
    "Book title" to "Titre du livre",
    "Author name" to "Nom de l’auteur",
    "Description / idea" to "Description / idée",
    "Search in book title" to "Rechercher dans le titre du livre",
    "Search in author name" to "Rechercher dans le nom de l’auteur",
    "Search in description and tags" to "Rechercher dans la description et les étiquettes",
    "Search results match all entered words. Choose a field above to narrow your search." to "Les résultats correspondent à tous les mots saisis. Choisissez un champ ci-dessus pour affiner la recherche.",
    "Search matches all words" to "Les résultats contiennent tous les mots recherchés",
    "Manage categories" to "Gérer les catégories",
    "books" to "livres",
    "Sort" to "Trier",
    "Title" to "Titre",
    "Newest created" to "Les plus récents",
    "Page count" to "Nombre de pages",
    "Recently updated" to "Modifiés récemment",
    "Select" to "Sélectionner",
    "Clear" to "Effacer la sélection",
    "selected" to "sélectionné(s)",
    "Move to list" to "Déplacer vers une liste",
    "Categories" to "Catégories",
    "Add to: " to "Ajouter à : ",
    "Move to: " to "Déplacer vers : ",
    "Delete" to "Supprimer",
    "No books yet." to "Aucun livre pour le moment.",
    "No matching books." to "Aucun livre correspondant.",
    "Confirm book deletion" to "Confirmer la suppression des livres",
    "Move the selected books to trash? You can restore them later?" to "Déplacer les livres sélectionnés vers la corbeille ? Vous pourrez les restaurer plus tard.",
    "New category name" to "Nom de la nouvelle catégorie",
    "Add category" to "Ajouter une catégorie",
    "Remove" to "Retirer",
    "Close" to "Fermer",
    "Book categories & tags" to "Catégories et étiquettes du livre",
    "Categories (select multiple)" to "Catégories (sélection multiple)",
    "Tags, comma separated" to "Étiquettes, séparées par des virgules",
    "Save" to "Enregistrer",
    "pages" to "pages",
    "Unknown author" to "Auteur inconnu",
    "Organize" to "Organiser",
    "Open" to "Ouvrir",
    "Settings" to "Paramètres",
    "Customize your Maktabati experience." to "Personnalisez votre expérience Ma bibliothèque.",
    "App language" to "Langue de l’application",
    "Default book language" to "Langue par défaut des livres",
    "Primary color" to "Couleur principale",
    "Presets or custom color" to "Couleurs prédéfinies ou personnalisées",
    "Appearance" to "Apparence",
    "System" to "Système",
    "Light" to "Clair",
    "Dark" to "Sombre",
    "Library layout" to "Affichage de la bibliothèque",
    "List" to "Liste",
    "Grid" to "Grille",
    "Default sorting" to "Tri par défaut",
    "Date created" to "Date de création",
    "Back" to "Retour",
    "Project management" to "Gestion du projet",
    "Book title" to "Titre du livre",
    "Search language" to "Rechercher une langue",
    "Save changes" to "Enregistrer les modifications",
    "Move project to trash" to "Déplacer le projet vers la corbeille",
    "Delete project?" to "Supprimer le projet ?",
    "The project will move to trash and can be restored later." to "Le projet sera déplacé vers la corbeille et pourra être restauré ultérieurement.",
    "Move to trash" to "Déplacer vers la corbeille",
    "◉ Read book" to "◉ Lire le livre",
    "Edit pages" to "Modifier les pages",
    "Manage project details" to "Gérer les informations du projet",
    "Last saved position: page \${book.lastReadIndex}. Resume reading." to "Dernière position enregistrée : page \${book.lastReadIndex}. Reprendre la lecture.",
    "You have not started reading this book yet." to "Vous n’avez pas encore commencé à lire ce livre.",
    "Undo" to "Annuler",
    "Redo" to "Rétablir",
    "Pages" to "Pages",
    "Page settings" to "Paramètres de la page",
    "Project" to "Projet",
    "Book pages" to "Pages du livre",
    "Apply" to "Appliquer",
    "You can increase or decrease the count. Reducing it removes only the last pages after confirmation." to "Vous pouvez augmenter ou réduire le nombre de pages. La réduction supprimera uniquement les dernières pages après confirmation.",
    "Page \${i+1}" to "Page \${i+1}",
    "Add page" to "Ajouter une page",
    "Upload" to "Importer une image",
    "Import images as pages" to "Importer des images comme pages",
    "Add back cover" to "Ajouter une quatrième de couverture",
    "Page elements" to "Éléments de la page",
    "+ Text" to "+ Texte",
    "+ Rectangle" to "+ Rectangle",
    "+ Circle" to "+ Cercle",
    "+ Line" to "+ Ligne",
    "Delete selected" to "Supprimer la sélection",
    "Copy" to "Copier",
    "Paste" to "Coller",
    "Lock/Unlock" to "Verrouiller/Déverrouiller",
    "Show/Hide" to "Afficher/Masquer",
    "Send back" to "Envoyer à l’arrière",
    "Bring front" to "Mettre au premier plan",
    "Center X" to "Centrer horizontalement",
    "Center Y" to "Centrer verticalement",
    "Group selected" to "Grouper la sélection",
    "Ungroup" to "Dégrouper",
    "Select an element to edit its text" to "Sélectionnez un élément pour modifier son texte",
    "Text" to "Texte",
    "Rectangle" to "Rectangle",
    "Circle" to "Cercle",
    "Line" to "Ligne",
    "Text content" to "Contenu du texte",
    "Font size" to "Taille de police",
    "Element color" to "Couleur de l’élément",
    "Position and size" to "Position et taille",
    "Width" to "Largeur",
    "Height" to "Hauteur",
    "Page title / description" to "Titre / description de la page",
    "Content" to "Contenu",
    "Fit image" to "Ajuster l’image",
    "Fill page" to "Remplir la page",
    "Rotate 90°" to "Pivoter de 90°",
    "Remove image" to "Supprimer l’image",
    "Move up ↑" to "Déplacer vers le haut ↑",
    "Move down ↓" to "Déplacer vers le bas ↓",
    "Duplicate" to "Dupliquer",
    "Delete page" to "Supprimer la page",
    "Page background" to "Arrière-plan de la page",
    "Book orientation" to "Orientation du livre",
    "Portrait" to "Portrait",
    "Landscape" to "Paysage",
    "Export project" to "Exporter le projet",
    "You can import a Maktabati JSON project using the system document picker." to "Vous pouvez importer un projet Ma bibliothèque au format JSON à l’aide du sélecteur de fichiers.",
    "Current page preview" to "Aperçu de la page actuelle",
    "Reset" to "Réinitialiser",
    "Previous" to "Précédent",
    "Page" to "Page",
    "Go" to "Aller",
    "Next" to "Suivant",
    "Reduce page count?" to "Réduire le nombre de pages ?",
    "Only the last \${book.pages.size-pendingPageCount} pages will be removed. Remaining pages will not change. Continue?" to "Seules les \${book.pages.size-pendingPageCount} dernières pages seront supprimées. Les autres pages resteront inchangées. Continuer ?",
    "Remove last pages" to "Supprimer les dernières pages",
    "Storage & backup" to "Stockage et sauvegarde",
    "Library overview" to "Aperçu de la bibliothèque",
    "Books: " to "Livres : ",
    "In trash: " to "Dans la corbeille : ",
    "App data storage used: " to "Espace utilisé par l’application : ",
    "Backup" to "Sauvegarde",
    "Export a JSON backup containing books, pages and embedded images. Keep it somewhere safe." to "Exportez une sauvegarde JSON contenant les livres, les pages et les images intégrées. Conservez-la en lieu sûr.",
    "Create backup" to "Créer une sauvegarde",
    "Restore backup" to "Restaurer une sauvegarde",
    "Trash is empty." to "La corbeille est vide.",
    "Restore it or delete it permanently." to "Restaurez-le ou supprimez-le définitivement.",
    "Start" to "Début",
    "End" to "Fin",
    "Go to page" to "Aller à la page",
    "Page number (1-\${book.pages.size})" to "Numéro de page (1-\${book.pages.size})",
    "Read later" to "À lire plus tard",
    "Completed" to "Terminé",
    "Currently reading" to "En cours de lecture",
    "Other books" to "Autres livres",
    " | Book Creation Studio" to " | Studio de création de livres",
    "Backup created" to "Sauvegarde créée",
    "Backup creation failed" to "Échec de la création de la sauvegarde",
    "Backup restored" to "Sauvegarde restaurée",
    "Could not create PDF" to "Impossible de créer le PDF",
    "Could not restore backup" to "Impossible de restaurer la sauvegarde",
    "Could not save trash" to "Impossible d’enregistrer la corbeille",
    "Day" to "Jour",
    "Empty" to "Vide",
    "Empty trash" to "Vider la corbeille",
    "Empty trash?" to "Vider la corbeille ?",
    "Exit full screen" to "Quitter le plein écran",
    "Export failed" to "Échec de l’exportation",
    "Full screen" to "Plein écran",
    "Invalid project file" to "Fichier de projet invalide",
    "Library save failed. Changes were not confirmed saved." to "Échec de l’enregistrement de la bibliothèque. L’enregistrement des modifications n’a pas été confirmé.",
    "Move the selected books to trash? You can restore them later." to "Déplacer les livres sélectionnés vers la corbeille ? Vous pourrez les restaurer plus tard.",
    "Night" to "Nuit",
    "PDF saved" to "PDF enregistré",
    "Page \${index + 1} of \${book.pages.size}" to "Page \${index + 1} sur \${book.pages.size}",
    "Project exported" to "Projet exporté",
    "Project imported" to "Projet importé",
    "Removed items will no longer be available in trash. This cannot be undone." to "Les éléments supprimés ne seront plus disponibles dans la corbeille. Cette action est irréversible.",
    "Restore" to "Restaurer",
    "Show reader controls" to "Afficher les commandes du lecteur",
    "Target page no longer exists; image was not attached" to "La page cible n’existe plus ; l’image n’a pas été associée.",
    "Trash" to "Corbeille",
    "Last saved position: page \${book.lastReadIndex}. Resume reading." to "Dernière position enregistrée : page \${book.lastReadIndex + 1}. Reprendre la lecture.",
    "Only the last \${book.pages.size-pendingPageCount} pages will be removed. Remaining pages will not change. Continue?" to "Seules les \${book.pages.size-pendingPageCount} dernières pages seront supprimées. Les autres pages resteront inchangées. Continuer ?",
    "Page \${i+1}" to "Page \${i+1}",
    "Page \${index + 1} of \${book.pages.size}" to "Page \${index + 1} sur \${book.pages.size}",
    "Page number (1-\${book.pages.size})" to "Numéro de page (1-\${book.pages.size})",
    "Could not complete moving books to trash; check storage before continuing." to "Impossible de déplacer les livres vers la corbeille. Vérifiez le stockage avant de continuer.",
    "Could not complete restoring the book; check storage before continuing." to "Impossible de restaurer le livre. Vérifiez le stockage avant de continuer.",
    "Move this book to trash? You can restore it later." to "Déplacer ce livre vers la corbeille ? Vous pourrez le restaurer plus tard."
)
private fun normalizeSearchText(value: String): String = value.lowercase(Locale.ROOT)
    .replace(Regex("[\u064B-\u065F\u0670\u0640\u200B-\u200F\uFEFF]"), "")
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    .replace('ٱ', 'ا').replace('ى', 'ي').replace('ؤ', 'و').replace('ئ', 'ي')
    .replace(Regex("[\\p{Punct}،؛؟«»“”‘’…]+"), " ")
    .replace(Regex("\\s+"), " ")
    .trim()

private fun searchMatchesNormalized(normalizedText: String, normalizedQuery: String): Boolean {
    if (normalizedQuery.isBlank()) return true
    if (normalizedText.contains(normalizedQuery)) return true
    val words = normalizedQuery.split(Regex("\\s+")).filter { it.isNotBlank() }
    return words.isNotEmpty() && words.all { normalizedText.contains(it) }
}

private fun searchMatches(text: String, query: String): Boolean =
    searchMatchesNormalized(normalizeSearchText(text), normalizeSearchText(query))

private fun uiText(ar: Boolean, arabic: String, english: String): String = when {
    ar -> arabic
    activeAppLanguage == "fr" -> frenchUi[english] ?: english
    else -> english
}
private data class PageElement(
    val id: String = UUID.randomUUID().toString(),
    var type: String = "text", // text, rectangle, circle, line
    var text: String = "نص جديد",
    var x: Float = 0.12f,
    var y: Float = 0.12f,
    var width: Float = 0.55f,
    var height: Float = 0.12f,
    var color: Long = 0xFF176044,
    var fontSize: Float = 22f,
    var locked: Boolean = false,
    var visible: Boolean = true,
    var groupId: String = ""
)
private data class BookPage(
    val id: String = UUID.randomUUID().toString(), var type: String = "content", var title: String = "",
    var imagePath: String = "", var fit: String = "contain", var rotation: Int = 0, var bg: Long = 0xFFFFFFFF,
    var widthMm: Float = 0f, var heightMm: Float = 0f, var elements: MutableList<PageElement> = mutableListOf()
)
private data class TrashEntry(val book: Book, val deletedAt: Long = System.currentTimeMillis())
private data class Book(
    val id: String = UUID.randomUUID().toString(), var title: String, var author: String = "", var language: String = "العربية",
    var description: String = "", var size: String = "a5", var orientation: String = "portrait", var pages: MutableList<BookPage>,
    var readingStatus: String = "other", var isFavorite: Boolean = false, var created: Long = System.currentTimeMillis(),
    var updated: Long = System.currentTimeMillis(), var lastReadIndex: Int = 0,
    var categoryIds: MutableList<String> = mutableListOf(), var tags: MutableList<String> = mutableListOf(), var isPinned: Boolean = false,
    var bookmarkedPages: MutableList<Int> = mutableListOf()
)

/** Creates an isolated snapshot safe to serialize on a background thread. */
private fun Book.deepCopy(): Book = copy(
    pages = pages.map { page ->
        page.copy(elements = page.elements.map { element -> element.copy() }.toMutableList())
    }.toMutableList(),
    categoryIds = categoryIds.toMutableList(),
    tags = tags.toMutableList(),
    bookmarkedPages = bookmarkedPages.toMutableList()
)

private fun List<Book>.deepCopyBooks(): List<Book> = map { it.deepCopy() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaktabatiApp() } }
}

@Composable
private fun MaktabatiApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storage = remember { File(context.filesDir, "maktabati") }
    val prefs = remember { context.getSharedPreferences("maktabati_settings", android.content.Context.MODE_PRIVATE) }
    val dbFile = remember { File(storage, "library.json") }
    val trashFile = remember { File(storage, "trash.json") }
    var books by remember { mutableStateOf(mutableListOf<Book>()) }
    var trashEntries by remember { mutableStateOf(mutableListOf<TrashEntry>()) }
    var screen by remember { mutableStateOf("home") }
    var current by remember { mutableStateOf<Book?>(null) }
    var selectedPage by remember { mutableIntStateOf(0) }
    var pendingPageId by remember { mutableStateOf<String?>(null) }
    var settingsReturnScreen by remember { mutableStateOf("home") }
    var languageSearch by remember { mutableStateOf("") }
    var customHue by remember { mutableFloatStateOf(145f) }
    var customSaturation by remember { mutableFloatStateOf(0.65f) }
    var customBrightness by remember { mutableFloatStateOf(0.55f) }
    var readIndex by remember { mutableIntStateOf(0) }
    var storageBytes by remember { mutableLongStateOf(0L) }
    // Respect the device language on first launch; keep an explicit in-app choice on later launches.
    var language by remember {
        mutableStateOf(
            prefs.getString("language", null)
                ?: Locale.getDefault().language.lowercase(Locale.ROOT).let { if (it in setOf("ar", "en", "fr")) it else "en" }
        )
    }
    var primary by remember { mutableLongStateOf(prefs.getLong("primary", GREEN)) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", "system") ?: "system") }
    var filter by remember { mutableStateOf("all") }
    var customCategories by remember { mutableStateOf(mutableListOf<String>()) }
    var searchQuery by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(prefs.getString("sort_mode", "updated") ?: "updated") }
    var gridMode by remember { mutableStateOf(prefs.getBoolean("grid_mode", false)) }
    var selectedBookIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showCreate by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }
    var authorInput by remember { mutableStateOf("") }
    var defaultBookLanguage by remember { mutableStateOf(prefs.getString("default_book_language", "العربية") ?: "العربية") }
    var bookLanguage by remember { mutableStateOf(defaultBookLanguage) }
    var descriptionInput by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var pendingImageTarget by remember { mutableStateOf("page") }
    var createCoverPath by remember { mutableStateOf("") }
    val ar = language == "ar"
    activeAppLanguage = language
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) { copyUri(context, uri, storage) }
                val b = current
                if (path != null) {
                    if (pendingImageTarget == "cover" && showCreate) {
                        createCoverPath = path
                    } else if (b != null) {
                        // Bind the picker result to the page that launched it, not the mutable list index.
                        val targetIndex = pendingPageId?.let { id -> b.pages.indexOfFirst { it.id == id } } ?: -1
                        if (targetIndex >= 0) {
                            val dimensions = withContext(Dispatchers.IO) { imagePageDimensionsMm(path) }
                            val oldPath = b.pages[targetIndex].imagePath
                            b.pages[targetIndex].apply {
                                imagePath = path
                                widthMm = dimensions.first
                                heightMm = dimensions.second
                            }
                            b.updated = System.currentTimeMillis()
                            val snapshot = books.deepCopyBooks()
                            withContext(Dispatchers.IO) { persistBooks(dbFile, snapshot) }
                            if (oldPath.isNotBlank() && oldPath != path) deleteUnreferencedImages(listOf(Book(title="",pages= mutableListOf(BookPage(imagePath=oldPath)))), books, storage)
                            books = books.toMutableList()
                        } else {
                            File(path).delete()
                            toast = uiText(ar, "تعذر العثور على الصفحة المستهدفة؛ لم تُربط الصورة", "Target page no longer exists; image was not attached")
                        }
                    } else {
                        File(path).delete()
                    }
                    pendingPageId = null
                }
            }
        } else {
            pendingPageId = null
        }
    }
    val pickManyImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val targetBookId = current?.id
        if (targetBookId != null && uris.isNotEmpty()) scope.launch {
            val createdPaths = mutableListOf<String>()
            try {
                val importedPages = withContext(Dispatchers.IO) {
                    uris.mapNotNull { uri ->
                        val path = copyUri(context, uri, storage) ?: return@mapNotNull null
                        createdPaths.add(path)
                        val dimensions = imagePageDimensionsMm(path)
                        BookPage(
                            title = uri.lastPathSegment?.substringAfterLast('/') ?: "",
                            imagePath = path,
                            widthMm = dimensions.first,
                            heightMm = dimensions.second
                        )
                    }
                }
                if (importedPages.isEmpty()) error("No images could be imported")
                val updatedBooks = books.map { book ->
                    if (book.id != targetBookId) book.copy(
                        pages = book.pages.map { it.copy(elements = it.elements.map { element -> element.copy() }.toMutableList()) }.toMutableList(),
                        categoryIds = book.categoryIds.toMutableList(), tags = book.tags.toMutableList(),
                        bookmarkedPages = book.bookmarkedPages.toMutableList()
                    ) else book.copy(
                        pages = (book.pages.map { it.copy(elements = it.elements.map { element -> element.copy() }.toMutableList()) } + importedPages).toMutableList(),
                        categoryIds = book.categoryIds.toMutableList(), tags = book.tags.toMutableList(),
                        bookmarkedPages = book.bookmarkedPages.toMutableList(), updated = System.currentTimeMillis()
                    )
                }
                if (updatedBooks.none { it.id == targetBookId }) error("Target book no longer exists")
                withContext(Dispatchers.IO) { persistBooks(dbFile, updatedBooks) }
                books = updatedBooks.toMutableList()
                current = books.firstOrNull { it.id == targetBookId }
                toast = uiText(ar, "تم استيراد ${importedPages.size} صفحة", "Imported ${importedPages.size} pages")
            } catch (_: Exception) {
                withContext(Dispatchers.IO) { createdPaths.forEach { runCatching { File(it).delete() } } }
                toast = uiText(ar, "تعذر استيراد الصور؛ لم تتغير المكتبة", "Could not import images; the library was not changed")
            }
        }
    }
    val importProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            var importedBook: Book? = null
            try {
                val imported = withContext(Dispatchers.IO) { importBook(context, uri, storage) }
                importedBook = imported
                val merged = (books + imported).distinctBy { it.id }.deepCopyBooks()
                withContext(Dispatchers.IO) { persistBooks(dbFile, merged) }
                books = merged.toMutableList()
                toast = uiText(ar, "تم استيراد المشروع", "Project imported")
            } catch (_: Exception) {
                // importBook owns cleanup for parse/decode failures; this handles a later
                // library-persistence failure after the embedded images were already restored.
                importedBook?.let { candidate ->
                    withContext(Dispatchers.IO) { deleteUnreferencedImages(listOf(candidate), books, storage) }
                }
                toast = uiText(ar, "تعذر استيراد المشروع؛ لم تتغير المكتبة", "Could not import project; the library was not changed")
            }
        }
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val b = current
        if (uri != null && b != null) {
            val snapshot = b.deepCopy()
            scope.launch { try { withContext(Dispatchers.IO) { writePdf(context, uri, snapshot) }; toast = uiText(ar, "تم حفظ ملف PDF", "PDF saved") } catch (_: Exception) { toast = uiText(ar, "تعذر إنشاء PDF", "Could not create PDF") } }
        }
    }
    val exportProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val b = current
        if (uri != null && b != null) scope.launch {
            try { withContext(Dispatchers.IO) { exportBook(context, uri, b) }; toast = uiText(ar, "تم تصدير المشروع", "Project exported") }
            catch (_: Exception) { toast = uiText(ar, "تعذر التصدير", "Export failed") }
        }
    }
    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            // Freeze a deep snapshot before background serialization so edits made during export
            // cannot produce a backup containing a mixture of old and new page state.
            val backupSnapshot = books.deepCopyBooks()
            scope.launch {
                try { withContext(Dispatchers.IO) { exportLibraryBackup(context, uri, backupSnapshot) }; toast = uiText(ar, "تم إنشاء النسخة الاحتياطية", "Backup created") }
                catch (_: Exception) { toast = uiText(ar, "فشل إنشاء النسخة الاحتياطية", "Backup creation failed") }
            }
        }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val restored = withContext(Dispatchers.IO) { importLibraryBackup(context, uri, storage) }
                val mergedSnapshot = (books + restored).distinctBy { it.id }.deepCopyBooks()
                // Commit to disk first; only publish the restored library to the UI after success.
                withContext(Dispatchers.IO) { persistBooks(dbFile, mergedSnapshot) }
                books = mergedSnapshot.toMutableList()
                toast = uiText(ar, "تم استيراد النسخة الاحتياطية", "Backup restored")
            } catch (_: Exception) { toast = uiText(ar, "تعذر استعادة النسخة الاحتياطية", "Could not restore backup") }
        }
    }
    LaunchedEffect(screen) {
        if (screen == "storage") storageBytes = withContext(Dispatchers.IO) { withContextStorageSize(storage) }
    }
    LaunchedEffect(Unit) {
        storage.mkdirs()
        books = withContext(Dispatchers.IO) { loadBooks(dbFile, storage) }.toMutableList()
        trashEntries = withContext(Dispatchers.IO) { loadTrash(trashFile) }.toMutableList()
        val saved = prefs.getString("custom_categories", "[]") ?: "[]"
        customCategories = try { val a=JSONArray(saved); MutableList(a.length()){i->a.getString(i)} } catch (_:Exception) { mutableListOf() }
    }
    fun persist() {
        val snapshot = books.deepCopyBooks()
        scope.launch {
            try {
                withContext(Dispatchers.IO) { persistBooks(dbFile, snapshot) }
            } catch (_: Exception) {
                toast = uiText(ar, "تعذر حفظ المكتبة. لم يتم تأكيد الحفظ.", "Library save failed. Changes were not confirmed saved.")
            }
        }
    }
    fun goHome() { screen = "home"; current = null }
    fun persistTrash() {
        val snapshot = trashEntries.map { it.copy(book = it.book.deepCopy()) }
        scope.launch { try { withContext(Dispatchers.IO) { saveTrash(trashFile, snapshot) } } catch (_: Exception) { toast = uiText(ar, "تعذر حفظ سلة المحذوفات", "Could not save trash") } }
    }
    fun moveBooksToTrash(items: List<Book>) {
        if (items.isEmpty()) return
        val ids = items.map { it.id }.toSet()
        books.removeAll { it.id in ids }
        items.forEach { book ->
            trashEntries.removeAll { it.book.id == book.id }
            trashEntries.add(TrashEntry(book))
        }
        books = books.toMutableList()
        trashEntries = trashEntries.toMutableList()
        val librarySnapshot = books.deepCopyBooks()
        val trashSnapshot = trashEntries.map { it.copy(book = it.book.deepCopy()) }
        // Save the recoverable trash copy first. A crash between writes can then at worst leave a duplicate.
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    saveTrash(trashFile, trashSnapshot)
                    persistBooks(dbFile, librarySnapshot)
                }
            } catch (_: Exception) {
                toast = uiText(ar, "تعذر إكمال نقل الكتب إلى السلة؛ تحقق من التخزين قبل المتابعة.", "Could not complete moving books to trash; check storage before continuing.")
            }
        }
        if (current?.id in ids) goHome()
    }
    fun moveToTrash(book: Book) = moveBooksToTrash(listOf(book))
    fun restoreFromTrash(entry: TrashEntry) {
        trashEntries.removeAll { it.book.id == entry.book.id }
        if (books.none { it.id == entry.book.id }) books.add(entry.book)
        books = books.toMutableList()
        trashEntries = trashEntries.toMutableList()
        val librarySnapshot = books.deepCopyBooks()
        val trashSnapshot = trashEntries.map { it.copy(book = it.book.deepCopy()) }
        // Save the restored library entry first; interruption can leave a duplicate in trash, never a lost book.
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    persistBooks(dbFile, librarySnapshot)
                    saveTrash(trashFile, trashSnapshot)
                }
            } catch (_: Exception) {
                toast = uiText(ar, "تعذر إكمال استعادة الكتاب؛ تحقق من التخزين قبل المتابعة.", "Could not complete restoring the book; check storage before continuing.")
            }
        }
    }
    fun openDetails(book: Book) { current = book; screen = "details" }
    fun openEditor(book: Book) { current = book; selectedPage = 0; screen = "editor" }
    fun startReader(book: Book, resume: Boolean) {
        current = book
        readIndex = if (resume && book.pages.isNotEmpty()) book.lastReadIndex.coerceIn(0, book.pages.lastIndex) else 0
        screen = "reader"
    }
    BackHandler(enabled = screen != "home" || showCreate) {
        when { showCreate -> showCreate = false; screen == "app-language" || screen == "book-language" || screen == "theme-color" -> screen = "settings"; screen == "settings" -> screen = settingsReturnScreen; screen == "manage" -> screen = "details"; screen == "reader" -> screen = "details"; screen == "editor" -> { persist(); screen = "details" }; screen == "details" -> goHome(); screen == "storage" -> goHome(); else -> goHome() }
    }
    val systemDark = isSystemInDarkTheme()
    val darkTheme = when (themeMode) { "dark" -> true; "light" -> false; else -> systemDark }
    val bg = if (darkTheme) Color(0xFF101713) else Color(0xFFF1F5F2)
    val ink = if (darkTheme) Color(0xFFE5EEE8) else Color(0xFF172820)
    val muted = if (darkTheme) Color(0xFFA3B2A9) else Color(0xFF718078)
    val green = Color(primary)
    val themeContent = if (green.luminance() > 0.42f) Color(0xFF172820) else Color.White
    val appColors = if (darkTheme) darkColorScheme(primary = green, onPrimary = themeContent, background = bg, surface = Color(0xFF1A241E), onSurface = ink)
                    else lightColorScheme(primary = green, onPrimary = themeContent, background = bg, surface = Color.White, onSurface = ink)
    MaterialTheme(colorScheme = appColors) {
        Scaffold(containerColor = bg, topBar = {
            Row(Modifier.fillMaxWidth().height(62.dp).background(MaterialTheme.colorScheme.primary).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                if (screen != "home") IconButton(onClick = { when(screen){"reader"->screen="details";"editor"->{persist();screen="details"};"manage"->screen="details";"settings"->screen=settingsReturnScreen;"app-language","book-language","theme-color"->screen="settings";"details"->goHome();else->goHome()} }) { Icon(Icons.Default.ArrowBack, null, tint = MaterialTheme.colorScheme.onPrimary) }
                Text(if (language == "ar") "مكتبتي" else if (language == "fr") "Ma bibliothèque" else "My Library", color = MaterialTheme.colorScheme.onPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(uiText(ar, " | استوديو إنشاء الكتب", " | Book Creation Studio"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.78f), fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (screen == "home") { IconButton(onClick = { screen = "storage" }) { Icon(Icons.Default.DriveFileMove, null, tint = MaterialTheme.colorScheme.onPrimary) }; IconButton(onClick = { importProject.launch(arrayOf("application/json", "*/*")) }) { Icon(Icons.Default.Book, null, tint = MaterialTheme.colorScheme.onPrimary) }; IconButton(onClick = { settingsReturnScreen = screen; screen = "settings" }) { Icon(Icons.Default.Settings, null, tint = MaterialTheme.colorScheme.onPrimary) } }
                else if (screen == "editor") IconButton(onClick = { persist(); toast = uiText(ar, "تم الحفظ محليًا", "Saved locally") }) { Icon(Icons.Default.Save, null, tint = MaterialTheme.colorScheme.onPrimary) }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "home" -> HomeScreen(books, filter, ar, green, customCategories, searchQuery, sortMode, gridMode, selectedBookIds,
                        onToggleSelection={id->selectedBookIds=if(id in selectedBookIds) selectedBookIds-id else selectedBookIds+id},
                        onClearSelection={selectedBookIds=emptySet()},
                        onBulkStatus={status->books.filter{it.id in selectedBookIds}.forEach{it.readingStatus=status;it.updated=System.currentTimeMillis()};persist();books=books.toMutableList();selectedBookIds=emptySet()},
                        onBulkCategory={category->books.filter{it.id in selectedBookIds}.forEach{b->if(category !in b.categoryIds)b.categoryIds.add(category);b.updated=System.currentTimeMillis()};persist();books=books.toMutableList();selectedBookIds=emptySet()},
                        onBulkMoveCategory={category->books.filter{it.id in selectedBookIds}.forEach{b->b.categoryIds= mutableListOf(category);b.updated=System.currentTimeMillis()};persist();books=books.toMutableList();selectedBookIds=emptySet()},
                        onBulkDelete={val doomed=books.filter{it.id in selectedBookIds};moveBooksToTrash(doomed);selectedBookIds=emptySet()},
                        onFilter={filter=it}, onSearch={searchQuery=it}, onSort={sortMode=it}, onView={gridMode=it},
                        onCategoriesChanged={customCategories=it.toMutableList();prefs.edit().putString("custom_categories",JSONArray(it).toString()).apply()},
                        onAssignCategories={b,ids->b.categoryIds=ids.toMutableList();b.updated=System.currentTimeMillis();persist();books=books.toMutableList()},
                        onTags={b,tags->b.tags=tags.toMutableList();b.updated=System.currentTimeMillis();persist();books=books.toMutableList()},
                        onPin={b->b.isPinned=!b.isPinned;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onCreate={
                        titleInput="";authorInput="";descriptionInput="";bookLanguage=defaultBookLanguage;languageSearch="";createCoverPath="";showCreate=true
                    }, onOpen={openDetails(it)}, onFavorite={b->b.isFavorite=!b.isFavorite;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onStatus={b,s->b.readingStatus=s;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onDelete={b->moveToTrash(b)})
                    "storage" -> StorageScreen(
                        books = books, trashEntries = trashEntries, ar = ar,
                        storageBytes = storageBytes,
                        onBackup = { exportBackup.launch("Maktabati_Backup.json") },
                        onRestoreBackup = { importBackup.launch(arrayOf("application/json", "*/*")) },
                        onRestore = { restoreFromTrash(it) },
                        onDeleteForever = { entry ->
                            val remaining = trashEntries.filterNot { it.book.id == entry.book.id }
                            deleteUnreferencedImages(listOf(entry.book), books + remaining.map { it.book }, storage)
                            trashEntries = remaining.toMutableList(); persistTrash()
                        },
                        onEmptyTrash = {
                            deleteUnreferencedImages(trashEntries.map { it.book }, books, storage)
                            trashEntries.clear(); persistTrash(); trashEntries = mutableListOf()
                        },
                        onClearCache = {
                            scope.launch(Dispatchers.IO) {
                                runCatching { context.cacheDir.deleteRecursively(); context.cacheDir.mkdirs() }
                                runCatching { context.externalCacheDir?.deleteRecursively(); context.externalCacheDir?.mkdirs() }
                            }
                        },
                        onBack = { screen = "home" }
                    )
                    "details" -> current?.let { DetailsScreen(it, ar, onEdit={openEditor(it)}, onRead={startReader(it,true)}, onManage={screen="manage"}, onDuplicate={ source -> val clone=source.copy(id=UUID.randomUUID().toString(), title=source.title+uiText(ar," - نسخة"," - Copy"), created=System.currentTimeMillis(), updated=System.currentTimeMillis(), pages=source.pages.map { page -> page.copy(id=UUID.randomUUID().toString(), elements=page.elements.map { it.copy(id=UUID.randomUUID().toString()) }.toMutableList()) }.toMutableList(), categoryIds=source.categoryIds.toMutableList(), tags=source.tags.toMutableList(), bookmarkedPages=source.bookmarkedPages.toMutableList()); books.add(clone); persist(); books=books.toMutableList(); current=clone; toast=uiText(ar,"تم نسخ الكتاب","Book duplicated") }) }
                    "manage" -> current?.let { b -> ManageProjectScreen(b, ar, onChangeCover={val cover=b.pages.firstOrNull{it.type=="cover"} ?: BookPage(type="cover",title=uiText(ar,"الغلاف الأمامي","Front cover")).also{b.pages.add(0,it);persist();books=books.toMutableList()};pendingImageTarget="page";pendingPageId=cover.id;pickImage.launch("image/*")}, onSave={title,author,description,lang->b.title=title;b.author=author;b.description=description;b.language=lang;b.updated=System.currentTimeMillis();persist();books=books.toMutableList();screen="details"}, onDelete={moveToTrash(b)}) }
                    "settings" -> SettingsHomeScreen(ar, language, defaultBookLanguage, themeMode, gridMode, sortMode, primary, onLanguage={screen="app-language"}, onBookLanguage={screen="book-language"}, onColor={screen="theme-color"}, onTheme={themeMode=it;prefs.edit().putString("theme_mode",it).apply()}, onGrid={gridMode=it;prefs.edit().putBoolean("grid_mode",it).apply()}, onSort={sortMode=it;prefs.edit().putString("sort_mode",it).apply()}, onBack={screen=settingsReturnScreen})
                    "app-language" -> LanguageSettingsScreen(language, onSelect={language=it;prefs.edit().putString("language",it).apply();screen="settings"}, onBack={screen="settings"})
                    "book-language" -> BookLanguageSettingsScreen(defaultBookLanguage, onSelect={defaultBookLanguage=it;bookLanguage=it;prefs.edit().putString("default_book_language",it).apply();screen="settings"}, onBack={screen="settings"})
                    "theme-color" -> ColorSettingsScreen(primary, customHue, customSaturation, customBrightness, onPreset={primary=it;prefs.edit().putLong("primary",it).apply()}, onHue={customHue=it}, onSat={customSaturation=it}, onBright={customBrightness=it}, onApply={val c=android.graphics.Color.HSVToColor(floatArrayOf(customHue,customSaturation,customBrightness)).toLong() and 0xFFFFFFFFL;primary=c;prefs.edit().putLong("primary",c).apply();screen="settings"}, onBack={screen="settings"})
                    "editor" -> current?.let { b -> EditorScreen(b, selectedPage, ar, green,
                        onSelect={selectedPage=it}, onAdd={b.pages.add(BookPage(title=uiText(ar, "صفحة جديدة", "New page")));selectedPage=b.pages.lastIndex;persist();books=books.toMutableList()},
                        onUpload={pendingImageTarget="page";pendingPageId=b.pages.getOrNull(selectedPage)?.id;pickImage.launch("image/*")}, onImportImages={pickManyImages.launch("image/*")}, onMove={delta->val from=selectedPage;val to=(from+delta).coerceIn(0,b.pages.lastIndex);if(to!=from){val moved=b.pages.removeAt(from);b.pages.add(to,moved);selectedPage=to;persist();books=books.toMutableList()}}, onAddBack={b.pages.add(BookPage(type="back",title=uiText(ar, "الغلاف الخلفي", "Back cover")));selectedPage=b.pages.lastIndex;persist();books=books.toMutableList()}, onDuplicate={val p=b.pages[selectedPage].copy(id=UUID.randomUUID().toString(),title=b.pages[selectedPage].title+uiText(ar, " - نسخة", " - Copy"));b.pages.add(selectedPage+1,p);selectedPage++;persist();books=books.toMutableList()},
                        onDelete={if(b.pages.size>1){val removed=b.pages.removeAt(selectedPage);deleteUnreferencedImages(listOf(Book(title="",pages=mutableListOf(removed))),books,storage);selectedPage=selectedPage.coerceAtMost(b.pages.lastIndex);persist();books=books.toMutableList()}},
                        onChange={persist();books=books.toMutableList()}, onExport={exportProject.launch("${safeName(b.title)}.kutubi.json")}) }
                    "reader" -> current?.let { b -> ReaderScreen(b, readIndex, ar, onIndex={readIndex=it;b.lastReadIndex=it;b.readingStatus=if(it>=b.pages.lastIndex) "completed" else if(it>0) "reading" else b.readingStatus;persist();books=books.toMutableList()}, onBookmark={persist();books=books.toMutableList()}, onPdf={savePdf.launch("${safeName(b.title)}.pdf")}) }
                }
            }
        }
        if (showCreate) AlertDialog(onDismissRequest={showCreate=false}, title={Text(uiText(ar, "إعداد كتاب جديد", "New book settings"))}, text={
            Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(titleInput,{titleInput=it},label={Text(uiText(ar, "عنوان الكتاب *", "Book title *"))},singleLine=true)
                OutlinedTextField(authorInput,{authorInput=it},label={Text(uiText(ar, "اسم المؤلف", "Author"))},singleLine=true)
                OutlinedTextField(descriptionInput,{descriptionInput=it},label={Text(uiText(ar, "وصف الكتاب", "Description"))})
                Text(uiText(ar, "لغة الكتاب", "Book language"),fontWeight=FontWeight.SemiBold)
                OutlinedTextField(value=languageSearch,onValueChange={languageSearch=it},singleLine=true,modifier=Modifier.fillMaxWidth(),leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text(uiText(ar, "ابحث عن لغة", "Search languages"))})
                val bookLanguages = bookLanguageOptions()
                Column(Modifier.heightIn(max=150.dp).verticalScroll(rememberScrollState())) { bookLanguages.filter { languageSearch.isBlank() || it.contains(languageSearch,true) }.forEach { lang -> Row(Modifier.fillMaxWidth().clickable{bookLanguage=lang}.padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=bookLanguage==lang,onClick={bookLanguage=lang});Text(lang)} } }
                Text(
                    uiText(ar, "سيتم تحديد أبعاد كل صفحة تلقائيًا من الصورة التي تضيفها، دون الحاجة لاختيار A4 أو A5 أو إدخال الطول والعرض.", "Each page will automatically use the dimensions and proportions of its selected image. No A4/A5 selection or manual width and height are required."),
                    fontSize=12.sp, color=Color.Gray
                )
                OutlinedButton(onClick={pendingImageTarget="cover";pickImage.launch("image/*")}) { Icon(Icons.Default.Image,null); Text(uiText(ar, "صورة الغلاف (اختياري)", "Optional cover image")) }
            }
        }, confirmButton={TextButton(onClick={
            if(titleInput.isNotBlank()) {
                val coverDimensions = if(createCoverPath.isNotBlank()) imagePageDimensionsMm(createCoverPath) else (0f to 0f)
                val initialPages=mutableListOf(
                    BookPage(type="cover",title=uiText(ar, "الغلاف الأمامي", "Front cover"),imagePath=createCoverPath,widthMm=coverDimensions.first,heightMm=coverDimensions.second),
                    BookPage(title=uiText(ar, "الصفحة الأولى", "Page 1"))
                )
                val b=Book(title=titleInput.trim(),author=authorInput.trim(),language=bookLanguage,description=descriptionInput.trim(),size="a5",orientation="portrait",pages=initialPages)
                books.add(b);persist();showCreate=false;openEditor(b)
            }
        }){Text(uiText(ar, "إنشاء الكتاب", "Create book"))}}, dismissButton={TextButton(onClick={showCreate=false}){Text(uiText(ar, "إلغاء", "Cancel"))}})
        if(toast.isNotBlank()) LaunchedEffect(toast) { kotlinx.coroutines.delay(2400);toast="" }
    }
}

@Composable
private fun StorageScreen(
    books: List<Book>, trashEntries: List<TrashEntry>, ar: Boolean, storageBytes: Long,
    onBackup: () -> Unit, onRestoreBackup: () -> Unit,
    onRestore: (TrashEntry) -> Unit, onDeleteForever: (TrashEntry) -> Unit,
    onEmptyTrash: () -> Unit, onClearCache: () -> Unit, onBack: () -> Unit
) {
    var confirmEmpty by remember { mutableStateOf(false) }
    var cacheCleaned by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(uiText(ar, "التخزين والنسخ الاحتياطي", "Storage & backup"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text(uiText(ar, "رجوع", "Back")) }
        }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(uiText(ar, "ملخص المكتبة", "Library overview"), fontWeight = FontWeight.Bold)
            Text((uiText(ar, "عدد الكتب: ", "Books: ")) + books.size)
            Text((uiText(ar, "في سلة المحذوفات: ", "In trash: ")) + trashEntries.size)
            Text((uiText(ar, "المساحة المستخدمة داخل بيانات التطبيق: ", "App data storage used: ")) + formatBytes(storageBytes))
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(uiText(ar, "النسخ الاحتياطي", "Backup"), fontWeight = FontWeight.Bold)
            Text(uiText(ar, "تصدير نسخة JSON تشمل الكتب والصفحات والصور المضمنة. احتفظ بها في مكان آمن.", "Export a JSON backup containing books, pages and embedded images. Keep it somewhere safe."), style = MaterialTheme.typography.bodySmall)
            Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text(uiText(ar, "إنشاء نسخة احتياطية", "Create backup")) }
            OutlinedButton(onClick = onRestoreBackup, modifier = Modifier.fillMaxWidth()) { Text(uiText(ar, "استعادة نسخة احتياطية", "Restore backup")) }
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(uiText(ar, "الملفات المؤقتة", "Temporary files"), fontWeight = FontWeight.Bold)
            Text(uiText(ar, "احذف الملفات المؤقتة القابلة لإعادة الإنشاء فقط. لن تُحذف الكتب أو صور الصفحات.", "Remove temporary cache files that the app can recreate. Books and page images will not be deleted."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { onClearCache(); cacheCleaned = true }, modifier = Modifier.fillMaxWidth()) { Text(uiText(ar, "تنظيف الملفات المؤقتة", "Clear temporary files")) }
            if (cacheCleaned) Text(uiText(ar, "تم تنظيف الملفات المؤقتة.", "Temporary files cleared."), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(uiText(ar, "سلة المحذوفات", "Trash"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); if (trashEntries.isNotEmpty()) TextButton(onClick = { confirmEmpty = true }) { Text(uiText(ar, "إفراغ السلة", "Empty trash")) } }
            if (trashEntries.isEmpty()) Text(uiText(ar, "سلة المحذوفات فارغة.", "Trash is empty."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            trashEntries.forEach { entry ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(entry.book.title, fontWeight = FontWeight.SemiBold); Text(uiText(ar, "يمكنك استعادته أو حذفه نهائيًا.", "Restore it or delete it permanently."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    TextButton(onClick = { onRestore(entry) }) { Text(uiText(ar, "استعادة", "Restore")) }
                    TextButton(onClick = { onDeleteForever(entry) }) { Text(uiText(ar, "حذف نهائي", "Delete")) }
                }
                Divider()
            }
        } }
    }
    if (confirmEmpty) AlertDialog(onDismissRequest = { confirmEmpty = false }, title = { Text(uiText(ar, "إفراغ سلة المحذوفات؟", "Empty trash?")) }, text = { Text(uiText(ar, "لن تظهر الكتب المحذوفة في السلة بعد ذلك. لا يمكن التراجع عن هذا الإجراء.", "Removed items will no longer be available in trash. This cannot be undone.")) }, confirmButton = { TextButton(onClick = { onEmptyTrash(); confirmEmpty = false }) { Text(uiText(ar, "إفراغ", "Empty")) } }, dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text(uiText(ar, "إلغاء", "Cancel")) } })
}

private fun deleteUnreferencedImages(candidates: List<Book>, retained: List<Book>, storage: File) {
    val retainedPaths = retained.flatMap { it.pages }.map { it.imagePath }.filter { it.isNotBlank() }.toSet()
    val root = try { storage.canonicalFile } catch (_: Exception) { return }
    candidates.flatMap { it.pages }.map { it.imagePath }.filter { it.isNotBlank() && it !in retainedPaths }.distinct().forEach { path ->
        try {
            val file = File(path).canonicalFile
            if (file.parentFile == root && file.isFile) file.delete()
        } catch (_: Exception) { }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(java.util.Locale.US, "%.1f KB", kb)
    return String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
}

private fun withContextStorageSize(dir: File): Long = try { dir.walkTopDown().filter { it.isFile }.fold(0L) { total, file -> total + file.length() } } catch (_: Exception) { 0L }

@Composable
private fun HomeScreen(
    books: List<Book>, filter: String, ar: Boolean, green: Color, categories: List<String>, query: String,
    sortMode: String, gridMode: Boolean, selectedBookIds: Set<String>, onToggleSelection:(String)->Unit, onClearSelection:()->Unit,
    onBulkStatus:(String)->Unit, onBulkCategory:(String)->Unit, onBulkMoveCategory:(String)->Unit, onBulkDelete:()->Unit, onFilter:(String)->Unit, onSearch:(String)->Unit,
    onSort:(String)->Unit, onView:(Boolean)->Unit, onCategoriesChanged:(List<String>)->Unit,
    onAssignCategories:(Book,List<String>)->Unit, onTags:(Book,List<String>)->Unit, onPin:(Book)->Unit,
    onCreate:()->Unit, onOpen:(Book)->Unit, onFavorite:(Book)->Unit, onStatus:(Book,String)->Unit, onDelete:(Book)->Unit
) {
    val keys=listOf("all","favorites","later","completed","reading")
    val labels=if(ar) listOf("الكل","المفضلة","للقراءة لاحقًا","تمت القراءة","قيد القراءة") else if(activeAppLanguage=="fr") listOf("Tout","Favoris","À lire plus tard","Terminés","En cours") else listOf("All","Favorites","Read later","Completed","Reading")
    var manageCategories by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf("") }
    var editingBook by remember { mutableStateOf<Book?>(null) }
    var tagInput by remember { mutableStateOf("") }
    var categorySelection by remember(editingBook?.id) { mutableStateOf(editingBook?.categoryIds?.toSet() ?: emptySet()) }
    var bulkStatusExpanded by remember { mutableStateOf(false) }
    var bulkCategoryExpanded by remember { mutableStateOf(false) }
    var confirmBulkDelete by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Book?>(null) }
    var searchField by remember { mutableStateOf("title") }
    // Build normalized searchable fields once per library snapshot instead of normalizing
    // every book again on each keystroke/recomposition.
    val normalizedQuery = remember(query) { normalizeSearchText(query) }
    // Book is mutable and the library often publishes a shallow list copy. Use a value
    // fingerprint so Compose invalidates these caches when searchable/filterable fields change.
    val libraryContentKey = books.map { book ->
        listOf(
            book.id, book.title, book.author, book.description, book.tags.toList(),
            book.isFavorite, book.readingStatus, book.categoryIds.toList(), book.isPinned,
            book.updated, book.created, book.pages.size
        )
    }
    val searchIndex = remember(libraryContentKey) {
        books.associate { book ->
            book.id to Triple(
                normalizeSearchText(book.title),
                normalizeSearchText(book.author),
                normalizeSearchText((listOf(book.description) + book.tags).joinToString(" "))
            )
        }
    }
    val filtered = remember(libraryContentKey, filter, normalizedQuery, sortMode, searchField, searchIndex) {
        books.filter { b ->
            val matchesFilter = when {
                filter == "all" -> true
                filter == "favorites" -> b.isFavorite
                filter in listOf("later", "completed", "reading") -> b.readingStatus == filter
                else -> filter.removePrefix("cat:") in b.categoryIds
            }
            val indexedFields = searchIndex[b.id]
            val searchableText = when (searchField) {
                "author" -> indexedFields?.second.orEmpty()
                "description" -> indexedFields?.third.orEmpty()
                else -> indexedFields?.first.orEmpty()
            }
            matchesFilter && searchMatchesNormalized(searchableText, normalizedQuery)
        }.sortedWith(compareByDescending<Book> { it.isPinned }.then(when (sortMode) {
            "title" -> compareBy<Book> { it.title.lowercase(Locale.ROOT) }
            "created" -> compareByDescending<Book> { it.created }
            "pages" -> compareByDescending<Book> { it.pages.size }
            else -> compareByDescending<Book> { it.updated }
        }))
    }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text(uiText(ar, "مكتبتك", "Your Library"),fontSize=25.sp,fontWeight=FontWeight.Bold,color=Color(0xFF172820))
        Text(uiText(ar, "نظّم كتبك وابحث عنها بسهولة.", "Organize and find your books easily."),color=Color(0xFF718078),fontSize=13.sp)
        Button(onClick=onCreate,modifier=Modifier.fillMaxWidth().padding(vertical=12.dp),colors=ButtonDefaults.buttonColors(containerColor=green),shape=RoundedCornerShape(11.dp)){Icon(Icons.Default.Add,null);Text(uiText(ar, "إنشاء كتاب جديد", "Create new book"))}
        OutlinedTextField(
            value=query, onValueChange=onSearch, modifier=Modifier.fillMaxWidth(), singleLine=true,
            leadingIcon={Icon(Icons.Default.Search,null)},
            placeholder={Text(when(searchField) {
                "author" -> uiText(ar, "ابحث باسم المؤلف", "Search in author name")
                "description" -> uiText(ar, "ابحث في وصف الكتاب أو فكرته العامة أو الوسوم", "Search in description and tags")
                else -> uiText(ar, "ابحث باسم الكتاب", "Search in book title")
            })}
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            FilterChip(selected=searchField=="title", onClick={searchField="title"}, label={Text(uiText(ar,"اسم الكتاب","Book title"))})
            FilterChip(selected=searchField=="author", onClick={searchField="author"}, label={Text(uiText(ar,"اسم المؤلف","Author name"))})
            FilterChip(selected=searchField=="description", onClick={searchField="description"}, label={Text(uiText(ar,"الوصف / الفكرة العامة","Description / idea"))})
        }
        Text(uiText(ar, "تُطابق النتائج كل كلمات البحث، ويمكنك تغيير مجال البحث من التصنيفات أعلاه.", "Search results match all entered words. Choose a field above to narrow your search."), fontSize=11.sp, color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                keys.forEachIndexed{i,k->FilterChip(selected=filter==k,onClick={onFilter(k)},label={Text(labels[i])})}
                categories.forEach { c->FilterChip(selected=filter=="cat:$c",onClick={onFilter(if(filter=="cat:$c") "all" else "cat:$c")},label={Text(c)}) }
            }
            IconButton(onClick={manageCategories=true}){Icon(Icons.Default.Label,uiText(ar, "إدارة التصنيفات", "Manage categories"))}
        }
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
            Row(verticalAlignment=Alignment.CenterVertically){Text("${filtered.size} ${uiText(ar, "كتاب", "books")}",fontSize=12.sp,color=Color.Gray);Spacer(Modifier.width(8.dp));var sortExpanded by remember{mutableStateOf(false)};Box{TextButton(onClick={sortExpanded=true}){Icon(Icons.Default.Sort,null);Text(uiText(ar, "ترتيب", "Sort"))};DropdownMenu(sortExpanded,{sortExpanded=false}){listOf("updated","title","created","pages").forEach{v->DropdownMenuItem(text={Text(when(v){"title"->uiText(ar, "العنوان", "Title");"created"->uiText(ar, "الأحدث إنشاءً", "Newest created");"pages"->uiText(ar, "عدد الصفحات", "Page count");else->uiText(ar, "آخر تعديل", "Recently updated")})},onClick={onSort(v);sortExpanded=false})}}}}
            Row(verticalAlignment=Alignment.CenterVertically){TextButton(onClick={if(selectedBookIds.isEmpty()) filtered.forEach{onToggleSelection(it.id)} else onClearSelection()}){Icon(Icons.Default.Checklist,null);Text(if(selectedBookIds.isEmpty()){uiText(ar, "تحديد", "Select")}else{uiText(ar, "إلغاء التحديد", "Clear")})};IconButton(onClick={onView(!gridMode)}){Icon(if(gridMode) Icons.Default.ViewList else Icons.Default.GridView,if(gridMode) "List view" else "Grid view")}}
        }
        if(selectedBookIds.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
            Text("${selectedBookIds.size} ${uiText(ar, "محدد", "selected")}",fontSize=12.sp,color=green)
            Box { TextButton(onClick={bulkStatusExpanded=true}){Icon(Icons.Default.DriveFileMove,null);Text(uiText(ar, "نقل إلى قائمة", "Move to list"))};DropdownMenu(bulkStatusExpanded,{bulkStatusExpanded=false}){listOf("later","reading","completed","other").forEach{st->DropdownMenuItem(text={Text(statusName(st,ar))},onClick={onBulkStatus(st);bulkStatusExpanded=false})}} }
            Box { TextButton(onClick={bulkCategoryExpanded=true}){Icon(Icons.Default.Label,null);Text(uiText(ar, "التصنيفات", "Categories"))};DropdownMenu(bulkCategoryExpanded,{bulkCategoryExpanded=false}){categories.forEach{c->DropdownMenuItem(text={Text((uiText(ar, "إضافة إلى: ", "Add to: "))+c)},onClick={onBulkCategory(c);bulkCategoryExpanded=false});DropdownMenuItem(text={Text((uiText(ar, "نقل إلى: ", "Move to: "))+c)},onClick={onBulkMoveCategory(c);bulkCategoryExpanded=false})}} }
            TextButton(onClick={confirmBulkDelete=true}){Icon(Icons.Default.Delete,null,tint=Color.Red);Text(uiText(ar, "حذف", "Delete"),color=Color.Red)}
        }
        if(filtered.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(if(books.isEmpty()){uiText(ar, "لا توجد كتب بعد.", "No books yet.")}else{uiText(ar, "لا توجد نتائج مطابقة.", "No matching books.")},color=Color.Gray,textAlign=TextAlign.Center)}
        else if(gridMode) LazyVerticalGrid(columns=GridCells.Fixed(2),modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            gridItems(filtered,key={it.id}){b->Column { Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=b.id in selectedBookIds,onCheckedChange={onToggleSelection(b.id)});Text(uiText(ar, "تحديد", "Select"),fontSize=11.sp,color=Color.Gray)};BookGridCard(b,green,ar,onOpen,onFavorite,onPin,onManage={editingBook=b;categorySelection=b.categoryIds.toSet();tagInput=b.tags.joinToString(", ")},onDelete={deleteTarget=b},onStatus=onStatus) } }
        } else LazyColumn(modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(filtered,key={it.id}){b->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=b.id in selectedBookIds,onCheckedChange={onToggleSelection(b.id)});Box(Modifier.weight(1f)){BookListCard(b,green,ar,onOpen,onFavorite,onPin,onManage={editingBook=b;categorySelection=b.categoryIds.toSet();tagInput=b.tags.joinToString(", ")},onDelete={deleteTarget=b},onStatus=onStatus)} }}
        }
    }
    if(confirmBulkDelete) AlertDialog(onDismissRequest={confirmBulkDelete=false},title={Text(uiText(ar, "تأكيد حذف الكتب", "Confirm book deletion"))},text={Text(uiText(ar, "هل تريد نقل الكتب المحددة إلى سلة المحذوفات؟ يمكنك استعادتها لاحقًا.", "Move the selected books to trash? You can restore them later."))},confirmButton={TextButton(onClick={onBulkDelete();confirmBulkDelete=false}){Text(uiText(ar, "حذف", "Delete"),color=Color.Red)}},dismissButton={TextButton(onClick={confirmBulkDelete=false}){Text(uiText(ar, "إلغاء", "Cancel"))}})
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(uiText(ar, "تأكيد حذف الكتاب", "Confirm book deletion")) },
            text = { Text(uiText(ar, "هل تريد نقل هذا الكتاب إلى سلة المحذوفات؟ يمكنك استعادته لاحقًا.", "Move this book to trash? You can restore it later.")) },
            confirmButton = { TextButton(onClick = { onDelete(target); deleteTarget = null }) { Text(uiText(ar, "نقل إلى السلة", "Move to trash"), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text(uiText(ar, "إلغاء", "Cancel")) } }
        )
    }
    if(manageCategories) AlertDialog(onDismissRequest={manageCategories=false},title={Text(uiText(ar, "إدارة التصنيفات", "Manage categories"))},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(newCategory,{newCategory=it},singleLine=true,label={Text(uiText(ar, "اسم التصنيف الجديد", "New category name"))})
        Button(onClick={if(newCategory.isNotBlank() && newCategory.trim() !in categories){onCategoriesChanged(categories+newCategory.trim());newCategory=""}},modifier=Modifier.fillMaxWidth()){Text(uiText(ar, "إضافة تصنيف", "Add category"))}
        categories.forEach{c->Row(verticalAlignment=Alignment.CenterVertically){Text(c,Modifier.weight(1f));TextButton(onClick={onCategoriesChanged(categories-c);books.filter{c in it.categoryIds}.forEach{b->onAssignCategories(b,b.categoryIds-c)}}){Text(uiText(ar, "حذف", "Remove"),color=Color.Red)}}}
    }},confirmButton={TextButton(onClick={manageCategories=false}){Text(uiText(ar, "إغلاق", "Close"))}})
    editingBook?.let{b->AlertDialog(onDismissRequest={editingBook=null},title={Text(uiText(ar, "تصنيفات ووسوم الكتاب", "Book categories & tags"))},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text(uiText(ar, "التصنيفات (يمكن اختيار أكثر من تصنيف)", "Categories (select multiple)"))
        categories.forEach{c->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=c in categorySelection,onCheckedChange={checked->categorySelection=if(checked)categorySelection+c else categorySelection-c});Text(c)}}
        OutlinedTextField(tagInput,{tagInput=it},label={Text(uiText(ar, "الوسوم، افصل بينها بفواصل", "Tags, comma separated"))})
    }},confirmButton={TextButton(onClick={onAssignCategories(b,categorySelection.toList());onTags(b,tagInput.split(",").map{it.trim()}.filter{it.isNotBlank()}.distinct());editingBook=null}){Text(uiText(ar, "حفظ", "Save"))}},dismissButton={TextButton(onClick={editingBook=null}){Text(uiText(ar, "إلغاء", "Cancel"))}})}
}

@Composable private fun BookListCard(b:Book,green:Color,ar:Boolean,onOpen:(Book)->Unit,onFavorite:(Book)->Unit,onPin:(Book)->Unit,onManage:()->Unit,onDelete:(Book)->Unit,onStatus:(Book,String)->Unit){
    Card(Modifier.fillMaxWidth().clickable{onOpen(b)},shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){BookCover(b,Modifier.size(78.dp,104.dp),green);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){
            Text(b.title,fontWeight=FontWeight.Bold,fontSize=16.sp);Text("${b.pages.size} ${uiText(ar, "صفحة", "pages")} · ${b.author.ifBlank{uiText(ar, "مؤلف غير محدد", "Unknown author")}}",fontSize=11.sp,color=Color.Gray)
            if(b.categoryIds.isNotEmpty())Text(b.categoryIds.joinToString("، "),fontSize=10.sp,color=green,maxLines=1)
            if(b.tags.isNotEmpty())Text(b.tags.joinToString(" · "),fontSize=10.sp,color=Color.Gray,maxLines=1)
            Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={onFavorite(b)}){Icon(if(b.isFavorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(b.isFavorite)Color.Red else green)};IconButton(onClick={onPin(b)}){Icon(Icons.Default.PushPin,null,tint=if(b.isPinned)green else Color.Gray)};TextButton(onClick=onManage){Text(uiText(ar, "تنظيم", "Organize"))};TextButton(onClick={onOpen(b)}){Text(uiText(ar, "فتح", "Open"))};IconButton(onClick={onDelete(b)}){Icon(Icons.Default.Delete,null,tint=Color.Red)}}
            var statusExpanded by remember { mutableStateOf(false) }
            Box { TextButton(onClick={statusExpanded=true}){Text(statusName(b.readingStatus,ar),fontSize=11.sp)};DropdownMenu(statusExpanded,{statusExpanded=false}){listOf("other","later","reading","completed").forEach{st->DropdownMenuItem(text={Text(statusName(st,ar))},onClick={statusExpanded=false;onStatus(b,st)})}} }
        }}
    }
}
@Composable private fun BookGridCard(b:Book,green:Color,ar:Boolean,onOpen:(Book)->Unit,onFavorite:(Book)->Unit,onPin:(Book)->Unit,onManage:()->Unit,onDelete:(Book)->Unit,onStatus:(Book,String)->Unit){
    Card(Modifier.fillMaxWidth().clickable{onOpen(b)},shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
        Column(Modifier.padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){BookCover(b,Modifier.fillMaxWidth().height(145.dp),green);Text(b.title,fontWeight=FontWeight.Bold,maxLines=2,minLines=1);Text("${b.pages.size} ${uiText(ar, "صفحة", "pages")}",fontSize=11.sp,color=Color.Gray);Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={onFavorite(b)}){Icon(if(b.isFavorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(b.isFavorite)Color.Red else green)};IconButton(onClick={onPin(b)}){Icon(Icons.Default.PushPin,null,tint=if(b.isPinned)green else Color.Gray)};IconButton(onClick=onManage){Icon(Icons.Default.Label,null)};IconButton(onClick={onDelete(b)}){Icon(Icons.Default.Delete,null,tint=Color.Red)}};var statusExpanded by remember{mutableStateOf(false)};Box{TextButton(onClick={statusExpanded=true}){Text(statusName(b.readingStatus,ar),fontSize=10.sp)};DropdownMenu(statusExpanded,{statusExpanded=false}){listOf("other","later","reading","completed").forEach{st->DropdownMenuItem(text={Text(statusName(st,ar))},onClick={statusExpanded=false;onStatus(b,st)})}}}}
    }
}

@Composable private fun BookCover(book: Book, modifier: Modifier=Modifier, green: Color=Color(GREEN)) {
    val path = book.pages.firstOrNull { it.type == "cover" }?.imagePath.orEmpty()
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = path) {
        value = if (path.isBlank()) null else withContext(Dispatchers.IO) { decodePageBitmap(path, 512) }
    }
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(if(path.isBlank()) green else Color.White),contentAlignment=Alignment.Center){
        if(bitmap!=null) Image(bitmap!!.asImageBitmap(),null,Modifier.fillMaxSize()) else Text("م",fontSize=40.sp,fontWeight=FontWeight.Black,color=Color(0xFFEAF4ED))
    }
}

@Composable
private fun SettingsHomeScreen(
    ar: Boolean, language: String, defaultBookLanguage: String, themeMode: String, gridMode: Boolean, sortMode: String, primary: Long,
    onLanguage:()->Unit, onBookLanguage:()->Unit, onColor:()->Unit, onTheme:(String)->Unit, onGrid:(Boolean)->Unit,
    onSort:(String)->Unit, onBack:()->Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(uiText(ar, "الإعدادات", "Settings"), style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text(uiText(ar, "خصص تجربة استخدام مكتبتي.", "Customize your Maktabati experience."), color=MaterialTheme.colorScheme.onSurfaceVariant)
        Card(Modifier.fillMaxWidth().clickable(onClick=onLanguage)) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Language,null); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(uiText(ar, "لغة التطبيق", "App language"),fontWeight=FontWeight.SemiBold);Text(when(language){"ar"->"العربية";"fr"->"Français";else->"English"},style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Icon(Icons.Default.ChevronRight,null) } }
        Card(Modifier.fillMaxWidth().clickable(onClick=onBookLanguage)) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Book,null); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(uiText(ar, "لغة الكتاب الافتراضية", "Default book language"),fontWeight=FontWeight.SemiBold);Text(defaultBookLanguage,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Icon(Icons.Default.ChevronRight,null) } }
        Card(Modifier.fillMaxWidth().clickable(onClick=onColor)) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Palette,null); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(uiText(ar, "اللون الأساسي", "Primary color"),fontWeight=FontWeight.SemiBold);Text(uiText(ar, "ألوان جاهزة أو لون مخصص", "Presets or custom color"),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Box(Modifier.size(28.dp).clip(CircleShape).background(Color(primary)));Icon(Icons.Default.ChevronRight,null) } }
        Text(uiText(ar, "المظهر", "Appearance"),fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("system" to (uiText(ar, "النظام", "System")),"light" to (uiText(ar, "فاتح", "Light")),"dark" to (uiText(ar, "داكن", "Dark"))).forEach{(v,l)->FilterChip(selected=themeMode==v,onClick={onTheme(v)},label={Text(l)})}}
        Text(uiText(ar, "طريقة عرض المكتبة", "Library layout"),fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=!gridMode,onClick={onGrid(false)},label={Text(uiText(ar, "قائمة", "List"))});FilterChip(selected=gridMode,onClick={onGrid(true)},label={Text(uiText(ar, "شبكة", "Grid"))})}
        Text(uiText(ar, "الترتيب الافتراضي", "Default sorting"),fontWeight=FontWeight.Bold)
        listOf("updated" to (uiText(ar, "آخر تعديل", "Recently updated")),"title" to (uiText(ar, "العنوان", "Title")),"created" to (uiText(ar, "تاريخ الإنشاء", "Date created"))).forEach{(v,l)->Row(Modifier.fillMaxWidth().clickable{onSort(v)},verticalAlignment=Alignment.CenterVertically){RadioButton(selected=sortMode==v,onClick={onSort(v)});Text(l)}}
        OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth()){Text(uiText(ar, "عودة", "Back"))}
    }
}

@Composable
private fun LanguageSettingsScreen(language:String,onSelect:(String)->Unit,onBack:()->Unit){
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text(if(language=="ar") "لغة التطبيق" else if(language=="fr") "Langue de l’application" else "App language",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        listOf(Triple("ar","🇸🇦","العربية"),Triple("en","🇬🇧","English"),Triple("fr","🇫🇷","Français")).forEach{(code,flag,label)->Card(Modifier.fillMaxWidth().clickable{onSelect(code)}){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(flag,fontSize=24.sp);Spacer(Modifier.width(12.dp));Text(label,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);if(language==code)Icon(Icons.Default.Checklist,null,tint=MaterialTheme.colorScheme.primary)}}}
        OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth()){Text(if(language=="ar") "عودة" else if(language=="fr") "Retour" else "Back")}
    }
}

@Composable
private fun BookLanguageSettingsScreen(selected:String,onSelect:(String)->Unit,onBack:()->Unit){
    var query by remember { mutableStateOf("") }
    val languages=bookLanguageOptions()
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text(if(activeAppLanguage=="ar") "لغة الكتاب" else if(activeAppLanguage=="fr") "Langue du livre" else "Book language",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text(if(activeAppLanguage=="ar") "ابحث باسم اللغة أو اسمها الأصلي" else if(activeAppLanguage=="fr") "Rechercher par nom anglais ou natif" else "Search in native or English language names")})
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())){languages.filter{query.isBlank()||it.contains(query,true)}.forEach{lang->Row(Modifier.fillMaxWidth().clickable{onSelect(lang)}.padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=selected==lang,onClick={onSelect(lang)});Text(lang)}}}
        OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth()){Text(if(activeAppLanguage=="ar") "عودة" else if(activeAppLanguage=="fr") "Retour" else "Back")}
    }
}

@Composable
private fun ColorSettingsScreen(primary:Long,hue:Float,saturation:Float,brightness:Float,onPreset:(Long)->Unit,onHue:(Float)->Unit,onSat:(Float)->Unit,onBright:(Float)->Unit,onApply:()->Unit,onBack:()->Unit){
    val presets=listOf(0xFF176044,0xFF2457A6,0xFF7041A6,0xFFA64B35,0xFFB17A18,0xFF00796B,0xFFAD1457,0xFF344054,0xFF2563EB,0xFF64748B)
    val custom=android.graphics.Color.HSVToColor(floatArrayOf(hue,saturation,brightness)).toLong() and 0xFFFFFFFFL
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text(if(activeAppLanguage=="ar") "اللون الأساسي" else if(activeAppLanguage=="fr") "Couleur principale" else "Primary color",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text(if(activeAppLanguage=="fr") "10 couleurs prédéfinies" else if(activeAppLanguage=="ar") "10 ألوان جاهزة" else "10 preset colors",fontWeight=FontWeight.SemiBold)
        Column(verticalArrangement=Arrangement.spacedBy(12.dp)){presets.chunked(5).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){row.forEach{c->Box(Modifier.size(42.dp).clip(CircleShape).background(Color(c)).border(if(primary==c)3.dp else 1.dp,MaterialTheme.colorScheme.onSurface.copy(alpha=.35f),CircleShape).clickable{onPreset(c)})}}}}
        Divider()
        Text(if(activeAppLanguage=="fr") "Couleur personnalisée" else if(activeAppLanguage=="ar") "لون مخصص" else "Custom color",fontWeight=FontWeight.SemiBold)
        Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center) {
            Canvas(Modifier.size(224.dp).pointerInput(Unit) { detectTapGestures { point ->
                val centerX = size.width / 2f; val centerY = size.height / 2f
                val dx = point.x - centerX; val dy = point.y - centerY
                if (kotlin.math.sqrt(dx*dx + dy*dy) > minOf(size.width, size.height) * 0.24f) {
                    val angle = ((atan2(dy.toDouble(), dx.toDouble()) * 180.0 / PI) + 360.0).rem(360.0).toFloat()
                    onHue(angle)
                }
            } }) {
                val radius = size.minDimension / 2f
                drawCircle(Brush.sweepGradient(listOf(Color.Red,Color.Yellow,Color.Green,Color.Cyan,Color.Blue,Color.Magenta,Color.Red)),radius=radius)
                drawCircle(color=Color(custom),radius=radius*0.52f)
            }
        }
        Text(if(activeAppLanguage=="fr") "Nuancier de teintes" else if(activeAppLanguage=="ar") "دائرة الألوان" else "Hue wheel",fontWeight=FontWeight.Medium)
        Text(if(activeAppLanguage=="fr") "Saturation" else if(activeAppLanguage=="ar") "التشبع" else "Saturation",fontWeight=FontWeight.Medium);Slider(value=saturation,onValueChange=onSat,valueRange=0f..1f)
        Text(if(activeAppLanguage=="fr") "Luminosité" else if(activeAppLanguage=="ar") "السطوع" else "Brightness",fontWeight=FontWeight.Medium);Slider(value=brightness,onValueChange=onBright,valueRange=0f..1f)
        Button(onClick=onApply,modifier=Modifier.fillMaxWidth()){Text(if(activeAppLanguage=="fr") "Appliquer la couleur" else if(activeAppLanguage=="ar") "تطبيق اللون" else "Apply custom color")}
        OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth()){Text(if(activeAppLanguage=="ar") "عودة" else if(activeAppLanguage=="fr") "Retour" else "Back")}
    }
}

@Composable
private fun ManageProjectScreen(book:Book,ar:Boolean,onChangeCover:()->Unit,onSave:(String,String,String,String)->Unit,onDelete:()->Unit){
    var title by remember(book.id){mutableStateOf(book.title)}
    var author by remember(book.id){mutableStateOf(book.author)}
    var description by remember(book.id){mutableStateOf(book.description)}
    var bookLanguage by remember(book.id){mutableStateOf(book.language)}
    var search by remember{mutableStateOf("")}
    var confirmDelete by remember{mutableStateOf(false)}
    val languages=bookLanguageOptions()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
        Text(uiText(ar, "إدارة المشروع", "Project management"),style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        OutlinedTextField(title,{title=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text(uiText(ar, "اسم الكتاب", "Book title"))})
        OutlinedTextField(author,{author=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text(uiText(ar, "المؤلف", "Author"))})
        OutlinedTextField(description,{description=it},modifier=Modifier.fillMaxWidth(),minLines=3,label={Text(uiText(ar, "الوصف", "Description"))})
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            BookCover(book, Modifier.size(width=76.dp,height=104.dp))
            Column(Modifier.weight(1f)) {
                Text(if(ar) "صورة الغلاف" else if(activeAppLanguage=="fr") "Image de couverture" else "Cover image",fontWeight=FontWeight.SemiBold)
                OutlinedButton(onClick=onChangeCover) { Text(if(ar) "تغيير صورة الغلاف" else if(activeAppLanguage=="fr") "Modifier la couverture" else "Change cover image") }
            }
        }
        Text(uiText(ar, "لغة الكتاب", "Book language"),fontWeight=FontWeight.SemiBold)
        OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text(uiText(ar, "ابحث عن لغة", "Search language"))})
        Column(Modifier.heightIn(max=190.dp).verticalScroll(rememberScrollState())){languages.filter{search.isBlank()||it.contains(search,true)}.forEach{lang->Row(Modifier.fillMaxWidth().clickable{bookLanguage=lang}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=bookLanguage==lang,onClick={bookLanguage=lang});Text(lang)}}}
        Button(onClick={if(title.isNotBlank())onSave(title.trim(),author.trim(),description.trim(),bookLanguage)},modifier=Modifier.fillMaxWidth(),enabled=title.isNotBlank()){Text(uiText(ar, "حفظ التعديلات", "Save changes"))}
        OutlinedButton(onClick={confirmDelete=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.error)){Icon(Icons.Default.Delete,null);Text(uiText(ar, "نقل المشروع إلى سلة المحذوفات", "Move project to trash"))}
    }
    if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text(uiText(ar, "حذف المشروع؟", "Delete project?"))},text={Text(uiText(ar, "سيُنقل المشروع إلى سلة المحذوفات ويمكنك استعادته لاحقًا.", "The project will move to trash and can be restored later."))},confirmButton={TextButton(onClick=onDelete){Text(uiText(ar, "نقل إلى السلة", "Move to trash"))}},dismissButton={TextButton(onClick={confirmDelete=false}){Text(uiText(ar, "إلغاء", "Cancel"))}})
}

@Composable private fun DetailsScreen(book: Book, ar: Boolean, onEdit:()->Unit, onRead:()->Unit, onManage:()->Unit, onDuplicate:(Book)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        BookCover(book,Modifier.size(width=205.dp,height=290.dp))
        Spacer(Modifier.height(22.dp));Text(book.title,fontSize=27.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
        Text("${book.author.ifBlank{uiText(ar, "مؤلف غير محدد", "Unknown author")}} · ${book.pages.size} ${uiText(ar, "صفحة", "pages")} · ${book.language}",color=Color.Gray,textAlign=TextAlign.Center)
        if(book.description.isNotBlank()) Text(book.description,Modifier.padding(top=12.dp),textAlign=TextAlign.Center)
        Spacer(Modifier.height(20.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onRead){Text(uiText(ar, "◉ قراءة الكتاب", "◉ Read book"))};OutlinedButton(onClick=onEdit){Text(uiText(ar, "تحرير الصفحات", "Edit pages"))}};OutlinedButton(onClick=onManage,modifier=Modifier.fillMaxWidth().padding(top=8.dp)){Icon(Icons.Default.Edit,null);Text(uiText(ar, "إدارة المشروع وتعديل بياناته", "Manage project details"))};OutlinedButton(onClick={onDuplicate(book)},modifier=Modifier.fillMaxWidth()){Text(uiText(ar,"نسخ الكتاب","Duplicate book"))}
        Text(if(book.lastReadIndex>0){uiText(ar, "آخر موضع قراءة محفوظ: الصفحة ${book.lastReadIndex + 1}. يمكنك المتابعة من حيث توقفت.", "Last saved position: page ${book.lastReadIndex}. Resume reading.")}else{uiText(ar, "لم تبدأ قراءة هذا الكتاب بعد.", "You have not started reading this book yet.")},Modifier.padding(top=18.dp).fillMaxWidth().background(Color(0xFFEDF5EF),RoundedCornerShape(11.dp)).padding(14.dp),color=Color(0xFF315D45),textAlign=TextAlign.Center,fontSize=13.sp)
    }
}

@Composable private fun EditorScreen(book: Book, selected: Int, ar: Boolean, green: Color, onSelect:(Int)->Unit, onAdd:()->Unit, onUpload:()->Unit, onImportImages:()->Unit, onMove:(Int)->Unit, onAddBack:()->Unit, onDuplicate:()->Unit, onDelete:()->Unit, onChange:()->Unit, onExport:()->Unit) {
    val page=book.pages.getOrNull(selected) ?: return
    var tab by remember { mutableStateOf("pages") }
    var pageCountInput by remember(book.id) { mutableStateOf(book.pages.size.toString()) }
    LaunchedEffect(book.pages.size) { pageCountInput=book.pages.size.toString() }
    var showPageCountConfirm by remember { mutableStateOf(false) }
    var pendingPageCount by remember { mutableIntStateOf(book.pages.size) }
    var previewZoom by remember(book.id, selected) { mutableFloatStateOf(1f) }
    var pageJumpInput by remember(book.id) { mutableStateOf((selected + 1).toString()) }
    var editingElementId by remember(book.id, selected) { mutableStateOf("") }
    var copiedElement by remember(book.id) { mutableStateOf<PageElement?>(null) }
    var selectedElementIds by remember(book.id, selected) { mutableStateOf(setOf<String>()) }
    var selectedPageIds by remember(book.id) { mutableStateOf(setOf<String>()) }
    LaunchedEffect(selected) { pageJumpInput=(selected+1).toString() }
    val history = remember(book.id) { mutableStateListOf(bookToJson(book, false).toString()) }
    var historyIndex by remember(book.id) { mutableIntStateOf(0) }
    var historyChars by remember(book.id) { mutableIntStateOf(history.firstOrNull()?.length ?: 0) }
    val maxHistoryEntries = 40
    val maxHistoryChars = 8_000_000
    fun restoreSnapshot(raw: String) {
        val restored = objToBook(JSONObject(raw))
        book.title = restored.title; book.author = restored.author; book.language = restored.language
        book.description = restored.description; book.size = restored.size; book.orientation = restored.orientation
        book.pages = restored.pages; book.readingStatus = restored.readingStatus; book.isFavorite = restored.isFavorite
        book.created = restored.created; book.updated = restored.updated; book.lastReadIndex = restored.lastReadIndex
        book.categoryIds = restored.categoryIds; book.tags = restored.tags; book.isPinned = restored.isPinned; book.bookmarkedPages = restored.bookmarkedPages
        onSelect(selected.coerceIn(0, (book.pages.size - 1).coerceAtLeast(0)))
    }
    fun commitChange() {
        val snapshot = bookToJson(book, false).toString()
        if (history.getOrNull(historyIndex) != snapshot) {
            while (history.lastIndex > historyIndex) {
                historyChars -= history.removeAt(history.lastIndex).length
            }
            history.add(snapshot)
            historyChars += snapshot.length
            // Keep both the number and total size of snapshots bounded. Large books can
            // otherwise make a 40-entry full-document history consume excessive memory.
            while (history.size > 1 && (history.size > maxHistoryEntries || historyChars > maxHistoryChars)) {
                historyChars -= history.removeAt(0).length
                historyIndex = (historyIndex - 1).coerceAtLeast(0)
            }
            historyIndex = history.lastIndex
        }
        onChange()
    }
    fun undoChange() { if (historyIndex > 0) { historyIndex--; restoreSnapshot(history[historyIndex]); onChange() } }
    fun redoChange() { if (historyIndex < history.lastIndex) { historyIndex++; restoreSnapshot(history[historyIndex]); onChange() } }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={undoChange()}, enabled=historyIndex>0) { Icon(Icons.Default.Undo, contentDescription=uiText(ar, "تراجع", "Undo")) }
            IconButton(onClick={redoChange()}, enabled=historyIndex<history.lastIndex) { Icon(Icons.Default.Redo, contentDescription=uiText(ar, "إعادة", "Redo")) }
            listOf("pages" to uiText(ar, "الصفحات", "Pages"),"design" to uiText(ar, "إعدادات الصفحة", "Page settings"),"export" to uiText(ar, "المشروع", "Project")).forEach{(k,v)->FilterChip(selected=tab==k,onClick={tab=k},label={Text(v,fontSize=12.sp)})}
        }
        when(tab){
            "pages" -> {
                Text("${uiText(ar, "صفحات الكتاب", "Book pages")} (${book.pages.size})",fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically) {
                    OutlinedTextField(value=pageCountInput, onValueChange={pageCountInput=it.filter { ch -> ch.isDigit() }.take(3)}, label={Text(uiText(ar, "عدد الصفحات", "Page count"))}, singleLine=true, modifier=Modifier.weight(1f))
                    Button(onClick={
                        val target=pageCountInput.toIntOrNull()?.coerceIn(1,500)
                        if(target != null && target != book.pages.size) {
                            if(target < book.pages.size) { pendingPageCount=target; showPageCountConfirm=true }
                            else { repeat(target-book.pages.size) { book.pages.add(BookPage(title=uiText(ar, "صفحة جديدة", "New page"))) }; pageCountInput=target.toString(); commitChange() }
                        } else pageCountInput=book.pages.size.toString()
                    }) { Text(uiText(ar, "تطبيق", "Apply")) }
                }
                Text(uiText(ar, "يمكنك زيادة العدد أو تقليله. عند التقليل ستُحذف الصفحات الأخيرة فقط بعد التأكيد.", "You can increase or decrease the count. Reducing it removes only the last pages after confirmation."), fontSize=11.sp, color=Color.Gray)
                Row(Modifier.fillMaxWidth().height(138.dp).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) { book.pages.forEachIndexed{i,p->Column(Modifier.width(92.dp).clip(RoundedCornerShape(9.dp)).background(if(p.id in selectedPageIds) Color(0xFFFFF2D8) else if(i==selected) Color(0xFFE7F1EB) else Color.White).border(if(i==selected)2.dp else 1.dp,if(i==selected)green else Color(0xFFDfe8e1),RoundedCornerShape(9.dp)).clickable{onSelect(i);pageJumpInput=(i+1).toString()}.padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally){PageThumbnail(p,Modifier.weight(1f).fillMaxWidth());Text(p.title.ifBlank{uiText(ar, "صفحة ${i+1}", "Page ${i+1}")},fontSize=10.sp,maxLines=1);Checkbox(checked=p.id in selectedPageIds,onCheckedChange={checked->selectedPageIds=if(checked)selectedPageIds+p.id else selectedPageIds-p.id})} } }
                if(selectedPageIds.isNotEmpty()) Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("${selectedPageIds.size} ${uiText(ar, "صفحات محددة", "pages selected")}",modifier=Modifier.weight(1f),fontSize=12.sp);TextButton(onClick={selectedPageIds=emptySet()}){Text(uiText(ar, "إلغاء التحديد", "Clear"))};TextButton(onClick={val removable=book.pages.filter{it.id in selectedPageIds};if(book.pages.size-removable.size>=1){book.pages.removeAll{it.id in selectedPageIds};selectedPageIds=emptySet();onSelect(selected.coerceAtMost(book.pages.lastIndex));commitChange()}},enabled=book.pages.size-selectedPageIds.size>=1){Text(uiText(ar, "حذف المحدد", "Delete selected"),color=MaterialTheme.colorScheme.error)}}
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={onAdd();commitChange()},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Text(uiText(ar, "إضافة صفحة", "Add page"),fontSize=11.sp)};OutlinedButton(onClick=onUpload,modifier=Modifier.weight(1f)){Icon(Icons.Default.Image,null);Text(uiText(ar, "رفع صورة", "Upload"),fontSize=11.sp)}}
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick=onImportImages,modifier=Modifier.weight(1f)){Text(uiText(ar, "استيراد صور كصفحات", "Import images as pages"),fontSize=10.sp)};OutlinedButton(onClick={onAddBack();commitChange()},modifier=Modifier.weight(1f)){Text(uiText(ar, "إضافة غلاف خلفي", "Add back cover"),fontSize=10.sp)}}
            }
            "design" -> {
                Text(uiText(ar, "إعدادات الصفحة", "Page settings"),fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
                val editingElement = page.elements.firstOrNull { it.id == editingElementId }
                var elementTextDraft by remember(book.id, selected, editingElementId) { mutableStateOf(editingElement?.text.orEmpty()) }
                var elementTextDirty by remember(book.id, selected, editingElementId) { mutableStateOf(false) }
                var pageTitleDraft by remember(book.id, selected, page.id) { mutableStateOf(page.title) }
                var pageTitleDirty by remember(book.id, selected, page.id) { mutableStateOf(false) }
                LaunchedEffect(page.id, page.title) {
                    if (!pageTitleDirty) pageTitleDraft = page.title
                }
                LaunchedEffect(editingElementId, editingElement?.text) {
                    if (!elementTextDirty) elementTextDraft = editingElement?.text.orEmpty()
                }
                fun flushElementTextDraft() {
                    val target = page.elements.firstOrNull { it.id == editingElementId }
                    if (target != null && elementTextDirty) {
                        target.text = elementTextDraft
                        elementTextDirty = false
                        commitChange()
                    }
                }
                fun flushPageTitleDraft() {
                    if (pageTitleDirty) {
                        page.title = pageTitleDraft
                        pageTitleDirty = false
                        commitChange()
                    }
                }
                Text(uiText(ar, "عناصر الصفحة", "Page elements"), fontWeight=FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick={ page.elements.add(PageElement()); commitChange() }, modifier=Modifier.weight(1f)) { Text(uiText(ar, "+ نص", "+ Text")) }
                    OutlinedButton(onClick={ page.elements.add(PageElement(type="rectangle",text="",x=0.18f,y=0.35f,width=0.42f,height=0.12f)); commitChange() }, modifier=Modifier.weight(1f)) { Text(uiText(ar, "+ مستطيل", "+ Rectangle")) }
                    OutlinedButton(onClick={ page.elements.add(PageElement(type="circle",text="",x=0.25f,y=0.5f,width=0.2f,height=0.2f)); commitChange() }, modifier=Modifier.weight(1f)) { Text(uiText(ar, "+ دائرة", "+ Circle")) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick={ page.elements.add(PageElement(type="line",text="",x=0.12f,y=0.68f,width=0.7f,height=0.015f)); commitChange() }, modifier=Modifier.weight(1f)) { Text(uiText(ar, "+ خط", "+ Line")) }
                    OutlinedButton(onClick={ if(editingElement!=null){page.elements.removeAll{it.id==editingElementId};editingElementId="";commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "حذف العنصر المحدد", "Delete selected")) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={ if(editingElement!=null){copiedElement=editingElement.copy(id=UUID.randomUUID().toString());} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "نسخ", "Copy")) }
                    OutlinedButton(onClick={ copiedElement?.let { c -> val clone=c.copy(id=UUID.randomUUID().toString(),x=(c.x+0.04f).coerceAtMost((1f-c.width).coerceAtLeast(0f)),y=(c.y+0.04f).coerceAtMost((1f-c.height).coerceAtLeast(0f)),locked=false,groupId="");page.elements.add(clone);editingElementId=clone.id;commitChange() } }, enabled=copiedElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "لصق", "Paste")) }
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.locked=!editingElement.locked;commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "قفل/فتح", "Lock/Unlock")) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.visible=!editingElement.visible;commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "إظهار/إخفاء", "Show/Hide")) }
                    OutlinedButton(onClick={ if(editingElement!=null){val i=page.elements.indexOfFirst{it.id==editingElementId};if(i>0){val e=page.elements.removeAt(i);page.elements.add(i-1,e);commitChange()} } }, enabled=editingElement!=null && page.elements.indexOfFirst{it.id==editingElementId}>0, modifier=Modifier.weight(1f)) { Text(uiText(ar, "للخلف", "Send back")) }
                    OutlinedButton(onClick={ if(editingElement!=null){val i=page.elements.indexOfFirst{it.id==editingElementId};if(i>=0 && i<page.elements.lastIndex){val e=page.elements.removeAt(i);page.elements.add(i+1,e);commitChange()} } }, enabled=editingElement!=null && page.elements.indexOfFirst{it.id==editingElementId} in 0 until (page.elements.lastIndex.coerceAtLeast(0)), modifier=Modifier.weight(1f)) { Text(uiText(ar, "للأمام", "Bring front")) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.x=((1f-editingElement.width)/2f).coerceAtLeast(0f);commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "توسيط أفقي", "Center X")) }
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.y=((1f-editingElement.height)/2f).coerceAtLeast(0f);commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "توسيط رأسي", "Center Y")) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={
                        val targets=page.elements.filter{it.id in selectedElementIds}
                        if(targets.size>=2){val gid=UUID.randomUUID().toString();targets.forEach{it.groupId=gid};commitChange()}
                        else if(editingElement!=null){val gid=editingElement.groupId;if(gid.isBlank())editingElement.groupId=UUID.randomUUID().toString() else editingElement.groupId="";commitChange()}
                    }, enabled=selectedElementIds.size>=2 || editingElement!=null, modifier=Modifier.weight(1f)) { Text(uiText(ar, "تجميع المحدد", "Group selected")) }
                    OutlinedButton(onClick={
                        val targets=page.elements.filter{it.id in selectedElementIds};val groups=targets.map{it.groupId}.filter{it.isNotBlank()}.toSet()
                        if(groups.isNotEmpty()){page.elements.filter{it.groupId in groups}.forEach{it.groupId=""};commitChange()}
                    }, enabled=page.elements.any{it.id in selectedElementIds && it.groupId.isNotBlank()}, modifier=Modifier.weight(1f)) { Text(uiText(ar, "فك التجميع", "Ungroup")) }
                }
                if (page.elements.isNotEmpty()) {
                    Text(uiText(ar, "اختر عنصرًا لتعديل نصه", "Select an element to edit its text"), fontSize=11.sp, color=Color.Gray)
                    page.elements.forEach { element ->
                        Row(Modifier.fillMaxWidth().clickable { editingElementId=element.id }.background(if(editingElementId==element.id) Color(0xFFE7F1EB) else Color.Transparent).padding(5.dp), verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(checked=element.id in selectedElementIds, onCheckedChange={ checked -> selectedElementIds=if(checked) selectedElementIds+element.id else selectedElementIds-element.id })
                            Text(when(element.type){"text"->uiText(ar, "نص", "Text");"rectangle"->uiText(ar, "مستطيل", "Rectangle");"circle"->uiText(ar, "دائرة", "Circle");else->uiText(ar, "خط", "Line")}, modifier=Modifier.weight(1f), fontSize=12.sp)
                            Text((if(element.locked) "🔒 " else "") + (if(element.visible) "● " else "○ ") + if(element.type=="text") element.text else "•", maxLines=1, fontSize=11.sp)
                        }
                    }
                }
                if (editingElement != null) {
                    if (editingElement.type == "text") {
                        OutlinedTextField(
                            value = elementTextDraft,
                            onValueChange = { elementTextDraft = it; elementTextDirty = true },
                            enabled = !editingElement.locked,
                            label = { Text(uiText(ar, "محتوى النص", "Text content")) },
                            modifier = Modifier.fillMaxWidth().onFocusChanged { if (!it.isFocused) flushElementTextDraft() }
                        )
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(uiText(ar, "حجم الخط", "Font size"), fontSize=12.sp)
                            Slider(value=editingElement.fontSize, onValueChange={editingElement.fontSize=it}, onValueChangeFinished={commitChange()}, valueRange=10f..48f, modifier=Modifier.weight(1f))
                            Text("${editingElement.fontSize.toInt()}", fontSize=11.sp)
                        }
                    }
                    Text(uiText(ar, "لون العنصر", "Element color"), fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        listOf(0xFF176044,0xFF172820,0xFF2563EB,0xFFDC2626,0xFFF59E0B,0xFF9333EA,0xFFFFFFFF).forEach { c ->
                            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(c)).border(1.dp,Color.LightGray,CircleShape).clickable { editingElement.color=c; commitChange() })
                        }
                    }
                    Text(uiText(ar, "الموضع والحجم", "Position and size"), fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("X", fontSize=11.sp); Slider(value=editingElement.x.coerceIn(0f,0.95f), onValueChange={editingElement.x=it}, onValueChangeFinished={commitChange()}, valueRange=0f..0.95f, modifier=Modifier.weight(1f))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("Y", fontSize=11.sp); Slider(value=editingElement.y.coerceIn(0f,0.95f), onValueChange={editingElement.y=it}, onValueChangeFinished={commitChange()}, valueRange=0f..0.95f, modifier=Modifier.weight(1f))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(uiText(ar, "العرض", "Width"), fontSize=11.sp); Slider(value=editingElement.width.coerceIn(0.03f,1f), onValueChange={editingElement.width=it}, onValueChangeFinished={commitChange()}, valueRange=0.03f..1f, modifier=Modifier.weight(1f))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(uiText(ar, "الارتفاع", "Height"), fontSize=11.sp); Slider(value=editingElement.height.coerceIn(0.01f,1f), onValueChange={editingElement.height=it}, onValueChangeFinished={commitChange()}, valueRange=0.01f..1f, modifier=Modifier.weight(1f))
                    }
                }
                OutlinedTextField(
                    value = pageTitleDraft,
                    onValueChange = { pageTitleDraft = it; pageTitleDirty = true },
                    label = { Text(uiText(ar, "اسم / وصف الصفحة", "Page title / description")) },
                    modifier = Modifier.fillMaxWidth().onFocusChanged { if (!it.isFocused) flushPageTitleDraft() }
                )
                Text(
                    if(ar) {
                        if(page.imagePath.isNotBlank()) "أبعاد الصفحة مأخوذة تلقائيًا من الصورة المضافة، مع الحفاظ على تناسبها. لتغييرها اختر ملفًا آخر."
                        else "لم تتم إضافة صورة لهذه الصفحة بعد. أضف صورة وسيتم تحديد أبعاد الصفحة تلقائيًا من أبعادها."
                    } else if(activeAppLanguage=="fr") {
                        if(page.imagePath.isNotBlank()) "Les dimensions de la page ont été détectées automatiquement à partir de l’image sélectionnée. Choisissez une autre image pour les modifier."
                        else "Aucune image n’a encore été ajoutée à cette page. Ajoutez une image pour détecter automatiquement ses dimensions."
                    } else {
                        if(page.imagePath.isNotBlank()) "Page dimensions were detected automatically from the selected image. Choose another file to change them."
                        else "No image has been added to this page. Add an image and its dimensions will be detected automatically."
                    },
                    fontSize=11.sp, color=Color.Gray
                )
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=page.type=="cover",onClick={page.type="cover";commitChange()},label={Text(uiText(ar, "الغلاف الأمامي", "Front cover"))});FilterChip(selected=page.type=="back",onClick={page.type="back";commitChange()},label={Text(uiText(ar, "الغلاف الخلفي", "Back cover"))});FilterChip(selected=page.type=="content",onClick={page.type="content";commitChange()},label={Text(uiText(ar, "داخلية", "Content"))})}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=page.fit=="contain",onClick={page.fit="contain";commitChange()},label={Text(uiText(ar, "ملاءمة الصورة", "Fit image"))});FilterChip(selected=page.fit=="cover",onClick={page.fit="cover";commitChange()},label={Text(uiText(ar, "ملء الصفحة", "Fill page"))})}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedButton(onClick={page.rotation=(page.rotation+90)%360;commitChange()}){Text(uiText(ar, "تدوير 90°", "Rotate 90°"))};OutlinedButton(onClick={page.imagePath="";commitChange()}){Text(uiText(ar, "إزالة الصورة", "Remove image"))};OutlinedButton(onClick=onUpload){Text(uiText(ar, "رفع صورة", "Upload"))}}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedButton(onClick={onMove(-1);commitChange()},enabled=selected>0){Text(uiText(ar, "تحريك لأعلى ↑", "Move up ↑"))};OutlinedButton(onClick={onMove(1);commitChange()},enabled=selected<book.pages.lastIndex){Text(uiText(ar, "تحريك لأسفل ↓", "Move down ↓"))};OutlinedButton(onClick=onDuplicate){Text(uiText(ar, "نسخ", "Duplicate"))}}
                Button(onClick={onDelete();commitChange()},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFC84450))){Text(uiText(ar, "حذف الصفحة", "Delete page"))}
                Spacer(Modifier.height(10.dp));Text(uiText(ar, "لون خلفية الصفحة", "Page background"),fontWeight=FontWeight.SemiBold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(0xFFFFFFFF,0xFFFFFDF7,0xFFF2F5F3,0xFFEAF0F8,0xFFFFF0E6).forEach{c->Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c)).border(1.dp,Color.LightGray,CircleShape).clickable{page.bg=c;commitChange()})}}
                Spacer(Modifier.height(10.dp));Text(uiText(ar, "اتجاه الكتاب", "Book orientation"));Row{FilterChip(selected=book.orientation=="portrait",onClick={book.orientation="portrait";commitChange()},label={Text(uiText(ar, "طولي", "Portrait"))});FilterChip(selected=book.orientation=="landscape",onClick={book.orientation="landscape";commitChange()},label={Text(uiText(ar, "عرضي", "Landscape"))})}
            }
            else -> { Text(uiText(ar, "إدارة المشروع", "Project management"),fontWeight=FontWeight.Bold);Button(onClick=onExport){Icon(Icons.Default.Share,null);Text(uiText(ar, "تصدير المشروع", "Export project"))};Text(uiText(ar, "يمكنك فتح ملف مشروع مكتبتي بصيغة JSON من تطبيق الملفات.", "You can import a Maktabati JSON project using the system document picker.")) }
        }
        Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(uiText(ar, "معاينة الصفحة الحالية", "Current page preview"),fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));TextButton(onClick={previewZoom=(previewZoom-0.1f).coerceAtLeast(0.5f)}){Text("−")};Text("${(previewZoom*100).toInt()}%",fontSize=11.sp);TextButton(onClick={previewZoom=(previewZoom+0.1f).coerceAtMost(2f)}){Text("+")};TextButton(onClick={previewZoom=1f}){Text(uiText(ar, "إعادة", "Reset"))}}
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp).background(Color(0xFFE6EEE8),RoundedCornerShape(15.dp)).padding(12.dp),contentAlignment=Alignment.Center){
            val aspect=pageAspectRatio(page,book)
            PageDisplay(
                page,
                Modifier.fillMaxHeight().widthIn(max=420.dp).aspectRatio(aspect).graphicsLayer(scaleX=previewZoom,scaleY=previewZoom),
                onElementMoveEnd = { id, x, y ->
                    val moved = page.elements.firstOrNull { it.id == id }
                    if(moved != null) {
                        val dx=x-moved.x; val dy=y-moved.y; val gid=moved.groupId
                        if(gid.isNotBlank()) page.elements.filter{it.groupId==gid}.forEach{it.x=(it.x+dx).coerceIn(0f,(1f-it.width).coerceAtLeast(0f));it.y=(it.y+dy).coerceIn(0f,(1f-it.height).coerceAtLeast(0f))}
                        else { moved.x=x; moved.y=y }
                    }
                    commitChange()
                },
                selectedElementId = editingElementId,
                onElementTap = { id -> editingElementId=id; selectedElementIds=selectedElementIds+id }
            )
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick={if(selected>0){onSelect(selected-1);pageJumpInput=selected.toString()}},enabled=selected>0){Text(uiText(ar, "السابق", "Previous"))}
            OutlinedTextField(value=pageJumpInput,onValueChange={pageJumpInput=it.filter { ch->ch.isDigit() }.take(3)},label={Text(uiText(ar, "رقم الصفحة", "Page"))},singleLine=true,modifier=Modifier.weight(1f))
            TextButton(onClick={val target=pageJumpInput.toIntOrNull()?.minus(1);if(target!=null && target in book.pages.indices)onSelect(target) else pageJumpInput=(selected+1).toString()}){Text(uiText(ar, "انتقال", "Go"))}
            TextButton(onClick={if(selected<book.pages.lastIndex){onSelect(selected+1);pageJumpInput=(selected+2).toString()}},enabled=selected<book.pages.lastIndex){Text(uiText(ar, "التالي", "Next"))}
        }
    }
    if(showPageCountConfirm) AlertDialog(onDismissRequest={showPageCountConfirm=false;pageCountInput=book.pages.size.toString()},title={Text(uiText(ar, "تقليل عدد الصفحات؟", "Reduce page count?"))},text={Text(uiText(ar, "سيتم حذف آخر ${book.pages.size-pendingPageCount} صفحة فقط. لن تتغير الصفحات المتبقية. هل تريد المتابعة؟", "Only the last ${book.pages.size-pendingPageCount} pages will be removed. Remaining pages will not change. Continue?"))},confirmButton={TextButton(onClick={
        while(book.pages.size>pendingPageCount) book.pages.removeAt(book.pages.lastIndex)
        onSelect(selected.coerceAtMost(book.pages.lastIndex));pageCountInput=pendingPageCount.toString();showPageCountConfirm=false;commitChange()
    }){Text(uiText(ar, "حذف الصفحات الأخيرة", "Remove last pages"))}},dismissButton={TextButton(onClick={showPageCountConfirm=false;pageCountInput=book.pages.size.toString()}){Text(uiText(ar, "إلغاء", "Cancel"))}})
}

private object PageBitmapCache {
    // Keep the cache proportional to the device heap, with a conservative upper bound.
    private val maxCacheKilobytes = (Runtime.getRuntime().maxMemory() / 1024L / 8L)
        .coerceIn(8L * 1024L, 48L * 1024L).toInt()
    private val cache = object : LruCache<String, Bitmap>(maxCacheKilobytes) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }
    @Synchronized fun get(key: String): Bitmap? = cache.get(key)
    @Synchronized fun put(key: String, bitmap: Bitmap) { cache.put(key, bitmap) }
}

private fun decodePageBitmap(path: String, maxDimension: Int): Bitmap? {
    if (path.isBlank()) return null
    val sourceFile = File(path)
    if (!sourceFile.isFile) return null
    // Include source metadata so replacing an image at the same path cannot return stale pixels.
    val cacheKey = "$path#${sourceFile.length()}#${sourceFile.lastModified()}#$maxDimension"
    PageBitmapCache.get(cacheKey)?.let { return it }
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth / (sample * 2), bounds.outHeight / (sample * 2)) >= maxDimension) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeFile(path, options)?.also { PageBitmapCache.put(cacheKey, it) }
    } catch (_: OutOfMemoryError) { null } catch (_: Exception) { null }
}

@Composable private fun PageThumbnail(page: BookPage, modifier: Modifier=Modifier){PageDisplay(page,modifier.background(Color.White),320)}
@Composable private fun PageDisplay(
    page: BookPage,
    modifier: Modifier=Modifier,
    maxBitmapDimension: Int=1600,
    onElementMoveEnd: ((String, Float, Float) -> Unit)? = null,
    selectedElementId: String = "",
    onElementTap: ((String) -> Unit)? = null
){
    val density = LocalDensity.current
    val bmp by produceState<Bitmap?>(initialValue=null, page.imagePath, maxBitmapDimension) {
        value = if (page.imagePath.isNotBlank()) withContext(Dispatchers.IO) { decodePageBitmap(page.imagePath, maxBitmapDimension) } else null
    }
    BoxWithConstraints(modifier.background(Color(page.bg))) {
        if(bmp!=null) Image(bmp!!.asImageBitmap(),null,Modifier.fillMaxSize().graphicsLayer(rotationZ=page.rotation.toFloat()),contentScale=if(page.fit=="cover") androidx.compose.ui.layout.ContentScale.Crop else androidx.compose.ui.layout.ContentScale.Fit)
        else Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { Text(page.title.ifBlank{"▧"},color=Color.Gray,textAlign=TextAlign.Center) }
        page.elements.filter { it.visible }.forEach { element ->
            var dragOffset by remember(page.id, element.id) { mutableStateOf(Offset.Zero) }
            val elementModifier = Modifier
                .offset(x=maxWidth*element.x + with(density) { dragOffset.x.toDp() }, y=maxHeight*element.y + with(density) { dragOffset.y.toDp() })
                .width(maxWidth*element.width).height(maxHeight*element.height)
                .then(if(element.id==selectedElementId) Modifier.border(1.dp, Color(0xFF2563EB)) else Modifier)
                .then(if(onElementTap!=null) Modifier.clickable { onElementTap.invoke(element.id) } else Modifier)
                .then(if(onElementMoveEnd != null && !element.locked) Modifier.pointerInput(page.id, element.id, maxWidth, maxHeight) {
                    detectDragGestures(
                        onDragEnd = {
                            val pageWidthPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
                            val pageHeightPx = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)
                            val nextX = (element.x + dragOffset.x / pageWidthPx).coerceIn(0f, (1f-element.width).coerceAtLeast(0f))
                            val nextY = (element.y + dragOffset.y / pageHeightPx).coerceIn(0f, (1f-element.height).coerceAtLeast(0f))
                            dragOffset = Offset.Zero
                            onElementMoveEnd.invoke(element.id, nextX, nextY)
                        }
                    ) { change, amount -> change.consume(); dragOffset += amount }
                } else Modifier)
            when(element.type) {
                "text" -> Box(elementModifier, contentAlignment=Alignment.CenterStart) { Text(element.text, color=Color(element.color), fontSize=element.fontSize.sp, lineHeight=(element.fontSize*1.2f).sp) }
                "rectangle" -> Box(elementModifier.border(2.dp, Color(element.color)))
                "circle" -> Box(elementModifier.border(2.dp, Color(element.color), CircleShape))
                "line" -> Box(elementModifier.height(2.dp).background(Color(element.color)))
            }
        }
    }
}

@Composable private fun ReaderScreen(book: Book, index: Int, ar: Boolean, onIndex:(Int)->Unit, onBookmark:()->Unit, onPdf:()->Unit){
    val page = book.pages.getOrNull(index)
    var drag by remember(index) { mutableFloatStateOf(0f) }
    var nightMode by remember { mutableStateOf(false) }
    var readerZoom by remember(book.id) { mutableFloatStateOf(1f) }
    val isBookmarked = index in book.bookmarkedPages
    var immersive by remember { mutableStateOf(false) }
    var controlsVisible by remember { mutableStateOf(true) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var jumpValue by remember(index) { mutableStateOf((index + 1).toString()) }
    val view = androidx.compose.ui.platform.LocalView.current

    // Immersive reader mode hides Android system bars and restores them on exit.
    SideEffect {
        view.systemUiVisibility = if (immersive) {
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    DisposableEffect(view) {
        onDispose { view.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE }
    }

    val total = book.pages.size.coerceAtLeast(1)
    val progress = (index + 1).toFloat() / total.toFloat()
    val foreground = if (nightMode) Color(0xFFE8E8E8) else MaterialTheme.colorScheme.onSurface
    val readerBackground = if (nightMode) Color(0xFF101214) else MaterialTheme.colorScheme.surface
    val stageBackground = if (nightMode) Color(0xFF050607) else Color(0xFF0D2118)

    Column(Modifier.fillMaxSize().background(readerBackground).padding(if (immersive) 4.dp else 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (!immersive || controlsVisible) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(book.title, fontWeight = FontWeight.Bold, color = foreground, modifier = Modifier.weight(1f), maxLines = 1)
                TextButton(onClick = { if (isBookmarked) book.bookmarkedPages.remove(index) else book.bookmarkedPages.add(index); book.bookmarkedPages.sort(); onBookmark() }) { Icon(if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = uiText(ar, "علامة مرجعية", "Bookmark")); Text(if (isBookmarked) uiText(ar, "محفوظة", "Saved") else uiText(ar, "حفظ الصفحة", "Bookmark")) }
                TextButton(onClick = { nightMode = !nightMode }) { Text(if (nightMode) (uiText(ar, "وضع النهار", "Day")) else (uiText(ar, "الوضع الليلي", "Night"))) }
                TextButton(onClick = { immersive = !immersive }) { Text(if (immersive) (uiText(ar, "إنهاء ملء الشاشة", "Exit full screen")) else (uiText(ar, "ملء الشاشة", "Full screen"))) }
                TextButton(onClick = onPdf) { Text("PDF") }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(uiText(ar, "الصفحة ${index + 1} من ${book.pages.size}", "Page ${index + 1} of ${book.pages.size}"), color = foreground, fontSize = 13.sp, modifier = Modifier.weight(1f)); TextButton(onClick = { readerZoom = (readerZoom - 0.1f).coerceAtLeast(0.7f) }) { Text("−") }; Text("${(readerZoom * 100).toInt()}%", color = foreground, fontSize = 11.sp); TextButton(onClick = { readerZoom = (readerZoom + 0.1f).coerceAtMost(2f) }) { Text("+") }; TextButton(onClick = { readerZoom = 1f }) { Text(uiText(ar, "إعادة", "Reset")) } }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), color = if (nightMode) Color(0xFF9BC8AD) else MaterialTheme.colorScheme.primary)
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)
                .background(stageBackground, RoundedCornerShape(12.dp)).padding(8.dp)
                .pointerInput(index, immersive) {
                    detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                        if (drag < -40f && index < book.pages.lastIndex) onIndex(index + 1)
                        else if (drag > 40f && index > 0) onIndex(index - 1)
                        drag = 0f
                    })
                },
            contentAlignment = Alignment.Center
        ) {
            PageDisplay(page ?: BookPage(), Modifier.fillMaxHeight().fillMaxWidth(.96f).aspectRatio(page?.let { pageAspectRatio(it, book) } ?: defaultPageAspectRatio(book)).graphicsLayer(scaleX = readerZoom, scaleY = readerZoom))
            if (immersive && !controlsVisible) {
                TextButton(onClick = { controlsVisible = true }, modifier = Modifier.align(Alignment.BottomCenter)) {
                    Text(uiText(ar, "إظهار أدوات القراءة", "Show reader controls"), color = Color.White)
                }
            }
        }

        if (!immersive || controlsVisible) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { if (index > 0) onIndex(index - 1) }, enabled = index > 0, modifier = Modifier.weight(1f)) {
                    Text(uiText(ar, "السابقة", "Previous"))
                }
                OutlinedButton(onClick = { jumpValue = (index + 1).toString(); showJumpDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(uiText(ar, "انتقال", "Go to page"))
                }
                Button(onClick = { if (index < book.pages.lastIndex) onIndex(index + 1) }, enabled = index < book.pages.lastIndex, modifier = Modifier.weight(1f)) {
                    Text(uiText(ar, "التالية", "Next"))
                }
            }
            if (total > 1) {
                Slider(
                    value = (index + 1).toFloat(),
                    onValueChange = { value -> onIndex(value.toInt().coerceIn(1, total) - 1) },
                    valueRange = 1f..total.toFloat(),
                    steps = (total - 2).coerceAtLeast(0),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(uiText(ar, "البداية", "Start"), color = foreground, fontSize = 11.sp)
                Text("${(progress * 100).toInt()}%", color = foreground, fontSize = 11.sp)
                Text(uiText(ar, "النهاية", "End"), color = foreground, fontSize = 11.sp)
            }
        }
    }

    if (showJumpDialog) {
        AlertDialog(
            onDismissRequest = { showJumpDialog = false },
            title = { Text(uiText(ar, "الانتقال إلى صفحة", "Go to page")) },
            text = {
                OutlinedTextField(
                    value = jumpValue,
                    onValueChange = { jumpValue = it.filter(Char::isDigit).take(5) },
                    label = { Text(uiText(ar, "رقم الصفحة (1-${book.pages.size})", "Page number (1-${book.pages.size})")) },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val target = jumpValue.toIntOrNull()
                    if (target != null && target in 1..book.pages.size) { onIndex(target - 1); showJumpDialog = false }
                }) { Text(uiText(ar, "انتقال", "Go")) }
            },
            dismissButton = { TextButton(onClick = { showJumpDialog = false }) { Text(uiText(ar, "إلغاء", "Cancel")) } }
        )
    }
}

private fun bookLanguageOptions(): List<String> {
    val english = java.util.Locale.ENGLISH
    val options = java.util.Locale.getISOLanguages().mapNotNull { code ->
        val locale = java.util.Locale.forLanguageTag(code)
        val englishName = locale.getDisplayLanguage(english).trim()
        val nativeName = locale.getDisplayLanguage(locale).trim()
        if (englishName.isBlank() || englishName.equals("und", true)) null
        else if (nativeName.isNotBlank() && !nativeName.equals(englishName, true)) "$nativeName — $englishName" else englishName
    }.toMutableSet()
    options.addAll(listOf("العربية", "English", "Français"))
    return options.sortedBy { it.lowercase(java.util.Locale.ROOT) }
}

/**
 * Derives a page size from an image file without asking the user to classify it as A4/A5.
 * Image files generally expose pixel dimensions rather than a reliable physical paper size,
 * so we preserve the exact aspect ratio and normalize the longest edge to at most 297 mm.
 */
private fun imagePageDimensionsMm(path: String): Pair<Float, Float> {
    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, options)
    val pixelWidth = options.outWidth
    val pixelHeight = options.outHeight
    if (pixelWidth <= 0 || pixelHeight <= 0) return 148f to 210f
    val scale = 297f / maxOf(pixelWidth, pixelHeight).toFloat()
    val width = (pixelWidth * scale).coerceAtLeast(10f)
    val height = (pixelHeight * scale).coerceAtLeast(10f)
    return width to height
}

private fun defaultPageDimensionsMm(book:Book):Pair<Float,Float>{
    val base=when(book.size.lowercase()){"a4"->210f to 297f;"a6"->105f to 148f;else->148f to 210f}
    return if(book.orientation=="landscape") base.second to base.first else base
}
private fun pageDimensionsMm(page:BookPage,book:Book):Pair<Float,Float>{
    return if(page.widthMm in 10f..1000f && page.heightMm in 10f..1000f) page.widthMm to page.heightMm else defaultPageDimensionsMm(book)
}
private fun defaultPageAspectRatio(book:Book):Float{val d=defaultPageDimensionsMm(book);return d.first/d.second}
private fun pageAspectRatio(page:BookPage,book:Book):Float{val d=pageDimensionsMm(page,book);return (d.first/d.second).coerceIn(0.2f,5f)}

private fun statusName(s:String,ar:Boolean)=if(ar) when(s){"later"->"للقراءة لاحقًا";"completed"->"تمت القراءة";"reading"->"ما زلت أقرأ";else->"باقي الكتب"} else if(activeAppLanguage=="fr") when(s){"later"->"À lire plus tard";"completed"->"Terminé";"reading"->"En cours de lecture";else->"Autres livres"} else when(s){"later"->"Read later";"completed"->"Completed";"reading"->"Currently reading";else->"Other books"}
private fun safeName(s:String)=(s.ifBlank{"book"}.replace(Regex("[\\\\/:*?\"<>|]"),"_").take(60))
private fun copyUri(context:android.content.Context,uri:Uri,dir:File):String? {
    var file: File? = null
    return try {
        dir.mkdirs()
        val input = context.contentResolver.openInputStream(uri) ?: return null
        file = File(dir, "img_${UUID.randomUUID()}.bin")
        input.use { source -> file!!.outputStream().use { target -> source.copyTo(target) } }
        if (!file!!.isFile || file!!.length() <= 0L) { file!!.delete(); null } else file!!.absolutePath
    } catch (_: Exception) { file?.delete(); null }
}
private fun loadTrash(file: File): List<TrashEntry> {
    fun read(source: File): List<TrashEntry> {
        if (!source.exists()) return emptyList()
        val array = JSONArray(source.readText(Charsets.UTF_8))
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val book = item.optJSONObject("book") ?: return@mapNotNull null
            runCatching { TrashEntry(objToBook(book), item.optLong("deletedAt", System.currentTimeMillis())) }.getOrNull()
        }
    }
    return runCatching { read(file) }.getOrElse { runCatching { read(File(file.parentFile, file.name + ".bak")) }.getOrDefault(emptyList()) }
}

/** Replace a JSON file without deleting the last known-good copy before the new file is ready. */
private fun replaceJsonFile(file: File, temp: File, backup: File? = null) {
    if (file.exists() && backup != null) {
        val backupTemp = File(file.parentFile, backup.name + ".tmp")
        file.copyTo(backupTemp, overwrite = true)
        if (backup.exists() && !backup.delete()) throw java.io.IOException("Cannot rotate backup")
        if (!backupTemp.renameTo(backup)) {
            backupTemp.copyTo(backup, overwrite = true)
            backupTemp.delete()
        }
    }
    if (file.exists() && !file.delete()) throw java.io.IOException("Cannot replace ${file.name}")
    if (!temp.renameTo(file)) {
        try {
            temp.copyTo(file, overwrite = true)
            temp.delete()
        } catch (error: Exception) {
            if (backup?.exists() == true) backup.copyTo(file, overwrite = true)
            throw error
        }
    }
}

private fun saveTrash(file: File, entries: List<TrashEntry>) {
    file.parentFile?.mkdirs()
    val array = JSONArray()
    entries.forEach { entry -> array.put(JSONObject().put("deletedAt", entry.deletedAt).put("book", bookToJson(entry.book, false))) }
    val temp = File(file.parentFile, file.name + ".tmp")
    java.io.FileOutputStream(temp).use { stream -> stream.write(array.toString().toByteArray(Charsets.UTF_8)); stream.fd.sync() }
    replaceJsonFile(file, temp, File(file.parentFile, file.name + ".bak"))
}

private fun exportLibraryBackup(context: android.content.Context, uri: Uri, books: List<Book>) {
    val root = JSONObject().put("format", "maktabati-backup").put("version", 1).put("createdAt", System.currentTimeMillis())
    val array = JSONArray()
    books.forEach { array.put(bookToJson(it, true)) }
    root.put("books", array)
    context.contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray(Charsets.UTF_8)) } ?: error("Cannot open backup destination")
}

private fun importLibraryBackup(context: android.content.Context, uri: Uri, dir: File): List<Book> {
    val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Empty backup")
    val root = JSONObject(raw)
    if (root.optString("format") != "maktabati-backup") error("Unsupported backup format")
    if (root.optInt("version", -1) != 1) error("Unsupported backup version")
    val array = root.optJSONArray("books") ?: error("Backup has no books")
    if (array.length() == 0) error("Backup contains no books")
    dir.mkdirs()
    val createdImages = mutableListOf<File>()
    try {
        val imported = mutableListOf<Book>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            obj.put("id", UUID.randomUUID().toString())
            val pages = obj.optJSONArray("pages") ?: JSONArray()
            for (j in 0 until pages.length()) {
                val page = pages.getJSONObject(j)
                val encoded = page.optString("imageBase64")
                if (encoded.isNotBlank()) {
                    // Reject implausibly large individual images before allocating their decoded byte array.
                    if (encoded.length > 80_000_000) error("Backup image is too large")
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    if (bytes.isEmpty()) error("Backup contains an empty image")
                    val image = File(dir, "img_${UUID.randomUUID()}.bin")
                    java.io.FileOutputStream(image).use { stream -> stream.write(bytes); stream.fd.sync() }
                    if (!image.isFile || image.length() != bytes.size.toLong()) error("Could not restore image")
                    createdImages.add(image)
                    page.put("imagePath", image.absolutePath)
                }
                page.remove("imageBase64")
            }
            imported.add(objToBook(obj).also { it.updated = System.currentTimeMillis() })
        }
        return imported
    } catch (error: Exception) {
        createdImages.forEach { runCatching { it.delete() } }
        throw error
    }
}

private fun loadBooks(file: File, dir: File): List<Book> {
    fun read(source: File): List<Book> {
        val array = JSONArray(source.readText(Charsets.UTF_8))
        return (0 until array.length()).map { index -> objToBook(array.getJSONObject(index)) }
    }
    if (file.exists()) {
        runCatching { return read(file) }
    }
    val backup = File(file.parentFile, "${file.name}.bak")
    val recovered = runCatching { read(backup) }.getOrElse { return emptyList() }
    // Restore the known-good snapshot so the next save cannot rotate a corrupt primary over it.
    runCatching {
        file.parentFile?.mkdirs()
        backup.copyTo(file, overwrite = true)
    }
    return recovered
}
private fun persistBooks(file:File,books:List<Book>){
    synchronized(file.absolutePath.intern()) {
        file.parentFile?.mkdirs()
        val arr=JSONArray();books.forEach{arr.put(bookToJson(it,false))}
        val temp=File(file.parentFile,"${file.name}.tmp")
        val backup=File(file.parentFile,"${file.name}.bak")
        java.io.FileOutputStream(temp).use{stream->stream.write(arr.toString().toByteArray(Charsets.UTF_8));stream.fd.sync()}
        replaceJsonFile(file, temp, backup)
    }
}
private fun bookToJson(b:Book,embed:Boolean):JSONObject=JSONObject().apply{
    put("id",b.id);put("title",b.title);put("author",b.author);put("language",b.language);put("description",b.description);put("size",b.size);put("orientation",b.orientation);put("readingStatus",b.readingStatus);put("isFavorite",b.isFavorite);put("created",b.created);put("updated",b.updated);put("lastReadIndex",b.lastReadIndex);put("categoryIds",JSONArray(b.categoryIds));put("tags",JSONArray(b.tags));put("isPinned",b.isPinned);put("bookmarkedPages",JSONArray(b.bookmarkedPages))
    val a=JSONArray();b.pages.forEach{p->a.put(JSONObject().apply{put("id",p.id);put("type",p.type);put("title",p.title);put("fit",p.fit);put("rotation",p.rotation);put("bg",p.bg);put("widthMm",p.widthMm);put("heightMm",p.heightMm);put("elements", JSONArray().apply { p.elements.forEach { e -> put(JSONObject().apply { put("id",e.id);put("type",e.type);put("text",e.text);put("x",e.x);put("y",e.y);put("width",e.width);put("height",e.height);put("color",e.color);put("fontSize",e.fontSize);put("locked",e.locked);put("visible",e.visible);put("groupId",e.groupId) }) } });if(embed&&p.imagePath.isNotBlank()){val f=File(p.imagePath);if(!f.isFile)error("Missing page image: ${p.title}");put("imageBase64",android.util.Base64.encodeToString(f.readBytes(),android.util.Base64.NO_WRAP))}else put("imagePath",p.imagePath)})};put("pages",a)
}
private fun objToBook(o:JSONObject):Book{val pages=mutableListOf<BookPage>();val a=o.optJSONArray("pages")?:JSONArray();for(i in 0 until a.length()){val p=a.getJSONObject(i);val elements=mutableListOf<PageElement>();val ea=p.optJSONArray("elements")?:JSONArray();for(j in 0 until ea.length()){val e=ea.getJSONObject(j);elements.add(PageElement(e.optString("id",UUID.randomUUID().toString()),e.optString("type","text"),e.optString("text"),e.optDouble("x",0.12).toFloat(),e.optDouble("y",0.12).toFloat(),e.optDouble("width",0.55).toFloat(),e.optDouble("height",0.12).toFloat(),e.optLong("color",0xFF176044),e.optDouble("fontSize",22.0).toFloat(),e.optBoolean("locked",false),e.optBoolean("visible",true),e.optString("groupId","")))};pages.add(BookPage(p.optString("id",UUID.randomUUID().toString()),p.optString("type","content"),p.optString("title"),p.optString("imagePath"),p.optString("fit","contain"),p.optInt("rotation"),p.optLong("bg",0xFFFFFFFF),p.optDouble("widthMm",0.0).toFloat(),p.optDouble("heightMm",0.0).toFloat(),elements))};val cats=o.optJSONArray("categoryIds")?:JSONArray();val tags=o.optJSONArray("tags")?:JSONArray();return Book(o.optString("id",UUID.randomUUID().toString()),o.optString("title","Untitled"),o.optString("author"),o.optString("language","العربية"),o.optString("description"),o.optString("size","a5"),o.optString("orientation","portrait"),pages,o.optString("readingStatus","other"),o.optBoolean("isFavorite"),o.optLong("created"),o.optLong("updated"),o.optInt("lastReadIndex"),MutableList(cats.length()){i->cats.getString(i)},MutableList(tags.length()){i->tags.getString(i)},o.optBoolean("isPinned"), (o.optJSONArray("bookmarkedPages") ?: JSONArray()).let { marks -> MutableList(marks.length()) { i -> marks.optInt(i).coerceAtLeast(0) } })}
private fun exportBook(context:android.content.Context,uri:Uri,b:Book){
    // Serialize a detached snapshot: the editor may continue changing the live book while export runs.
    val snapshot = b.deepCopy()
    val bytes = bookToJson(snapshot,true).toString().toByteArray(Charsets.UTF_8)
    val descriptor = context.contentResolver.openFileDescriptor(uri,"w") ?: error("Cannot open destination")
    descriptor.use { parcel ->
        java.io.FileOutputStream(parcel.fileDescriptor).use { output -> output.write(bytes); output.flush(); output.fd.sync() }
    }
}

private fun importBook(context:android.content.Context,uri:Uri,dir:File):Book {
    val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: error("Empty project")
    if (raw.length > 120_000_000) error("Project file is too large")
    val source = JSONObject(raw)
    val pages = source.optJSONArray("pages") ?: error("Project has no pages array")
    if (pages.length() > 5000) error("Project contains too many pages")
    dir.mkdirs()
    val createdImages = mutableListOf<File>()
    try {
        // Validate and restore all embedded images before returning a book to the caller.
        for (i in 0 until pages.length()) {
            val page = pages.optJSONObject(i) ?: error("Invalid page at index $i")
            val encoded = page.optString("imageBase64")
            if (encoded.isNotBlank()) {
                if (encoded.length > 80_000_000) error("Embedded image is too large")
                val bytes = android.util.Base64.decode(encoded,android.util.Base64.DEFAULT)
                if (bytes.isEmpty()) error("Empty embedded image")
                val image = File(dir,"img_${UUID.randomUUID()}.bin")
                java.io.FileOutputStream(image).use { stream -> stream.write(bytes); stream.fd.sync() }
                if (!image.isFile || image.length() != bytes.size.toLong()) error("Could not restore embedded image")
                createdImages.add(image)
                page.put("imagePath",image.absolutePath)
            }
            page.remove("imageBase64")
        }
        // Imported project IDs must never collide with existing local entities.
        source.put("id",UUID.randomUUID().toString())
        for (i in 0 until pages.length()) {
            val page = pages.getJSONObject(i)
            page.put("id",UUID.randomUUID().toString())
            val elements = page.optJSONArray("elements") ?: JSONArray()
            for (j in 0 until elements.length()) elements.optJSONObject(j)?.put("id",UUID.randomUUID().toString())
        }
        val imported = objToBook(source)
        if (imported.title.isBlank()) imported.title = "Imported book"
        imported.lastReadIndex = imported.lastReadIndex.coerceIn(0,(imported.pages.size - 1).coerceAtLeast(0))
        imported.bookmarkedPages = imported.bookmarkedPages.filter { it in imported.pages.indices }.distinct().sorted().toMutableList()
        imported.updated = System.currentTimeMillis()
        return imported
    } catch (error: Exception) {
        createdImages.forEach { runCatching { it.delete() } }
        throw error
    }
}
private fun writePdf(context:android.content.Context,uri:Uri,b:Book){
    val pdf=PdfDocument()
    try {
    b.pages.forEachIndexed{i,p->
        val dims=pageDimensionsMm(p,b)
        val w=(dims.first*72f/25.4f).toInt().coerceIn(72,4000)
        val h=(dims.second*72f/25.4f).toInt().coerceIn(72,4000)
        val info=PdfDocument.PageInfo.Builder(w,h,i+1).create();val page=pdf.startPage(info);val c=page.canvas;c.drawColor(p.bg.toInt());val bmp=if(p.imagePath.isNotBlank())decodePageBitmap(p.imagePath,minOf(maxOf(w,h)*2,3200)) else null
        if(bmp!=null){val source=RectF(0f,0f,bmp.width.toFloat(),bmp.height.toFloat());val target=RectF(20f,20f,(w-20).toFloat(),(h-20).toFloat());val ratio=if(p.fit=="cover")maxOf(target.width()/source.width(),target.height()/source.height()) else minOf(target.width()/source.width(),target.height()/source.height());val dw=source.width()*ratio;val dh=source.height()*ratio;val dst=RectF((w-dw)/2,(h-dh)/2,(w+dw)/2,(h+dh)/2);c.save();c.rotate(p.rotation.toFloat(),w/2f,h/2f);c.drawBitmap(bmp,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG));c.restore()}
        else{val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.DKGRAY;textSize=24f;textAlign=Paint.Align.CENTER};c.drawText(p.title.ifBlank{" "},w/2f,h/2f,paint)}
        p.elements.filter { it.visible }.forEach { e ->
            val left=e.x*w; val top=e.y*h; val right=(e.x+e.width)*w; val bottom=(e.y+e.height)*h
            val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=e.color.toInt();style=Paint.Style.STROKE;strokeWidth=3f}
            when(e.type){
                "text" -> {
                    val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = e.color.toInt()
                        textSize = (e.fontSize * 2f).coerceIn(8f, 240f)
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
                    }
                    val textWidth = (right - left).toInt().coerceAtLeast(1)
                    val text = e.text
                    if (text.isNotEmpty()) {
                        // StaticLayout performs line wrapping and Android's bidirectional text shaping,
                        // which is essential for Arabic and mixed Arabic/Latin paragraphs in PDF output.
                        val layout = StaticLayout.Builder.obtain(text, 0, text.length, textPaint, textWidth)
                            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
                            .setIncludePad(false)
                            .setLineSpacing(0f, 1.2f)
                            .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
                            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                            .build()
                        c.save()
                        c.clipRect(left, top, right, bottom)
                        c.translate(left, top)
                        layout.draw(c)
                        c.restore()
                    }
                }
                "rectangle"->c.drawRect(left,top,right,bottom,paint)
                "circle"->c.drawOval(left,top,right,bottom,paint)
                "line"->c.drawLine(left,top,right,bottom,paint)
            }
        }
        pdf.finishPage(page)}
    context.contentResolver.openOutputStream(uri)?.use{pdf.writeTo(it)} ?: error("Cannot write PDF")
    } finally { pdf.close() }
}
