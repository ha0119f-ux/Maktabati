# Maktabati V1.2.0 – Phase 2 Regression Test Plan

This checklist is intended for the first Android Studio / GitHub Actions build and a real-device pass. It is not marked as passed until actually executed.

## Build and install
- [ ] Run `assembleDebug` with Gradle 8.9, AGP 8.7.3, JDK 17.
- [ ] Install over the previous version (same application ID, higher versionCode).
- [ ] Confirm Android retains the existing app's private data after update.

## Library and persistence
- [ ] Open a library containing Arabic, English, and French book metadata.
- [ ] Search by title, author, description, and tags; test multiple words and Arabic diacritics.
- [ ] Edit metadata and rapidly switch screens; force-stop and reopen; verify latest changes persist.
- [ ] Favorite, pin, change reading status, assign categories, and perform bulk operations.
- [ ] Move books to trash, restore them, and permanently delete a trashed book.
- [ ] Verify all page images still open after each operation.

## Editor and reader
- [ ] Add, edit, move, group, ungroup, duplicate, and delete page elements.
- [ ] Change page order, background, image fit, and rotation.
- [ ] Close and reopen the editor; verify text and element positions.
- [ ] Read from the beginning and resume from a saved position.
- [ ] Add and remove bookmarks; verify bookmark persistence.

## PDF export (important Phase 2 validation)
- [ ] Export a page containing Arabic text and confirm letters are connected and ordered correctly.
- [ ] Export mixed Arabic/Latin text, punctuation, numbers, and multiple paragraphs.
- [ ] Confirm long text wraps within the element width and does not paint outside its bounds.
- [ ] Export pages with images, rotation, contain/cover fit, shapes, and colored backgrounds.
- [ ] Export a large multi-page book and monitor memory use and completion time.
- [ ] Compare the PDF against the editor preview; report any expected layout differences.

## Import, export, and backup
- [ ] Export and re-import a single project; verify IDs do not collide and page images are restored.
- [ ] Export and restore a library backup; verify all books, page elements, and bookmarks.
- [ ] Test malformed or oversized project files; the library must remain unchanged on failure.
- [ ] Verify temporary-cache cleanup does not delete library images or book data.

## Devices and performance
- [ ] Test on Android 6+ (minimum supported API 23) and a recent Android version.
- [ ] Test on a low-memory device and a device with a large image-heavy library.
- [ ] Check scrolling, screen transitions, image loading, startup time, and memory behavior.

## Current verification state
- Source review: performed for Phase 2 changes.
- Kotlin syntax scan: no parser-style diagnostics observed; standalone compilation is blocked by absent Android/Compose dependencies.
- Android Gradle build: not completed in this environment because Gradle 8.9 could not be downloaded (`services.gradle.org` DNS/network unavailable).
- Real-device and PDF rendering tests: pending.

## Editor responsiveness (Phase 3 additions)
- [ ] Type a long text block; confirm the editor remains responsive while typing.
- [ ] Tap outside the text field; confirm the text is committed and remains visible in preview.
- [ ] Change pages/elements while editing; confirm the last draft is not lost.
- [ ] Use undo and redo after editing text and page titles; confirm the restored text appears in the fields.
- [ ] Make more than 40 edits in a large book; confirm undo remains functional and memory use stays bounded.
- [ ] Undo several edits, make a new edit, and confirm redo history is correctly discarded.
