# Maktabati — Native Android

This is a native Android reimplementation of the supplied **مكتبتي | استوديو إنشاء الكتب** project. The application is written in Kotlin and uses Jetpack Compose and Android system APIs. It does not contain a WebView, HTML, CSS, JavaScript, or a website runtime.

## Included functionality

- Arabic and English application interface, with persistent language and primary-color preferences.
- Local private library storage, book creation, details, editing, deletion, favorites, and reading-status shelves.
- Book metadata: author, language, description, A4/A5/A6/custom page-size selection, and portrait/landscape orientation.
- Front cover, content pages, back cover, add/duplicate/delete, page-type/title/background settings, image fit/fill/rotation/removal, and page reordering.
- Import one image or multiple images as pages using Android's system document/photo picker.
- Single-page reader with previous/next buttons, horizontal swipe navigation, saved reading position, and return-to-cover control.
- Export/import of a portable `.kutubi.json` project. Images are embedded in exported project files so the project can be moved between devices.
- PDF generation through Android's system save-document picker.
- App data is stored in the app-private files directory. Imported image content is copied into that private directory; no broad storage permission is requested.

## Build locally or in the cloud

Requirements: JDK 17 and Android SDK platform/build-tools 35. No Android Studio is required for command-line builds.

```bash
./gradlew assembleDebug
```

The debug APK is created at:

`app/build/outputs/apk/debug/app-debug.apk`

The included Gradle bootstrap wrapper downloads Gradle 8.9 on first use if it is not already cached. The GitHub Actions workflow installs Gradle 8.9 and JDK 17 directly, then runs the same `assembleDebug` task.

## Build the APK using GitHub Actions from a phone

1. Extract this ZIP archive.
2. Create a new repository on GitHub.
3. Upload the **contents** of the extracted `MaktabatiNative` folder to the repository root (the `.github` folder must also be uploaded).
4. Open the repository's **Actions** tab and select **Android APK Build**.
5. If the workflow has not run automatically, choose **Run workflow**.
6. Open the completed workflow run. Under **Artifacts**, download `maktabati-debug-apk`.
7. Extract the artifact ZIP to obtain `app-debug.apk`, then install it on the Android phone. Android may ask you to allow installation from the browser or file manager.

## Technical configuration

- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- Compile SDK 35 / Target SDK 35 / Minimum SDK 23
- Jetpack Compose Material 3

## Important verification note

The source project was inspected and reimplemented as native Compose screens and Android document/PDF flows. This environment does not contain an Android SDK installation and cannot reach the Gradle distribution/dependency repositories, so an actual Android compilation or emulator/device run could not be performed here. The included GitHub Actions workflow is provided to perform the real cloud build. Please treat the first successful Actions run as the final compilation check.
