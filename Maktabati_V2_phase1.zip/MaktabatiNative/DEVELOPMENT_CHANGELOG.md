# Maktabati development changelog

## Full modernization – initial implementation pass

### Completed in this pass
- Added a memoized library search index for normalized title, author, description, and tags. Search normalization is now computed once per library content snapshot rather than repeatedly for every book during each recomposition.
- Memoized the filtered and sorted library result set so unrelated Compose recompositions do not repeat filtering and sorting work.
- Added a value-based library cache key. This is important because `Book` is mutable and the app frequently publishes shallow list copies; relying only on list identity/equality could otherwise leave a cached search index stale after edits.
- Made the page bitmap cache size proportional to the available runtime heap, with conservative lower and upper bounds.
- Included image file size and modification time in bitmap cache keys and skipped decoding missing files, preventing stale cached pixels when an image is replaced at the same path.
- Preserved existing JSON formats, book fields, application ID, version code, and version name. No migration or destructive data rewrite was introduced.

### Verification performed
- Parsed all Android XML resources and the manifest successfully.
- Checked the updated Kotlin file with the Kotlin compiler parser; no Kotlin syntax/parser diagnostics were reported. Full symbol/type checking was not possible because Android and Compose dependencies are unavailable locally.
- Attempted `./gradlew --offline :app:assembleDebug`. The wrapper distribution (Gradle 8.9) is not cached and the environment cannot resolve `services.gradle.org`; therefore no APK build is claimed.
- Device-level behavior, performance benchmarks, and data migration/regression tests remain to be run in an Android build environment.

### Next recommended implementation steps
1. Add focused automated tests for Arabic/English/French search normalization and matching.
2. Introduce a serialized library persistence coordinator to prevent overlapping asynchronous snapshots from racing, after mapping every existing write path.
3. Split the large activity into feature and data modules incrementally, preserving the existing on-disk schema.
4. Expand editor and reader capabilities only after establishing regression tests for existing project files.

## Phase 2 – snapshot integrity and PDF text rendering

### Completed in this pass
- Added a single deep-copy helper for books, pages, page elements, categories, tags, and bookmarks. Background persistence, backup, restore, and PDF operations now use detached snapshots rather than shallow page copies.
- Fixed a data-consistency risk where mutable page elements could still change while a background JSON write was serializing a supposedly detached snapshot.
- Ensured the imported-project merge is deep-copied before background persistence.
- Improved PDF text rendering with Android `StaticLayout`, automatic line wrapping, paragraph direction detection, and Android bidirectional shaping. This is particularly important for Arabic and mixed Arabic/Latin text.
- Added clipping to each text element's defined bounds so PDF text cannot spill into neighboring elements.
- Capped the maximum decoded page bitmap dimension used during PDF export to reduce peak memory pressure on high-resolution page images while retaining high-resolution output.
- Incremented the Android version to `versionCode 3` / `versionName 1.2.0` while preserving the application ID and existing JSON schema.

### Verification
- Source-level review performed for deep-copy coverage and PDF layout behavior.
- XML/manifest parsing, Kotlin parser diagnostics, and ZIP integrity are checked before packaging.
- Full Android compilation and device-level PDF validation remain pending because the Gradle 8.9 distribution and Android dependency artifacts are not available in the offline build environment.

## Phase 3 – editor responsiveness and bounded history

### Completed in this pass
- Removed full-book JSON snapshot creation and persistence from every character typed into the editor's text-content and page-title fields. Drafts now update interactively and are committed when the field loses focus.
- Kept draft text synchronized when the selected page/element changes or when undo/redo restores an earlier document state.
- Bounded undo/redo history by both entry count (40) and total serialized snapshot size (8 million characters), preventing large books from retaining an unbounded amount of snapshot data in memory.
- Corrected history accounting when redo entries are discarded after a new edit.
- Preserved the existing editor data model and JSON representation; no book migration is required.
- Incremented Android version to `versionCode 4` / `versionName 1.3.0`.

### Verification
- Source review performed for text-draft commit paths and undo-history accounting.
- Kotlin parser-style scan, XML parsing, and ZIP integrity checks are repeated before packaging.
- Full Android compilation and device-level editor interaction tests remain pending for the same unavailable Gradle distribution / Android dependency environment.

## Launcher icon update
- Replaced the launcher artwork with the supplied complete Maktabati illustration.
- Added safe-area padding to the adaptive foreground so Android circular/squircle launcher masks do not crop the books illustration.
- Updated legacy density launcher icons and kept the cream adaptive background.
- Fixed project root name to `Maktabati_V2` and display version to `1.1.1` as requested; application ID and data format remain unchanged.

## Review Phase 1 – low-risk UI/robustness fixes (versionName stays 1.1.1)

### Changed (MainActivity.kt, themes, manifest, README)
- Success/failure messages are now actually displayed (Scaffold `SnackbarHost`); `toast` was previously set but never rendered.
- Editor controls are scrollable; preview has a fixed height, so lower page-settings controls are reachable on phones.
- Editor page thumbnails use `LazyRow` instead of composing every page at once.
- Layout direction follows the in-app language (RTL for Arabic, LTR otherwise); back/undo/redo/list icons auto-mirror.
- Top bar respects the status-bar inset (Android 15 edge-to-edge); content respects the keyboard inset.
- Dark theme: cards, home title and editor selections use theme colors; day/night window theme added (`values/themes.xml`, `values-night/themes.xml`).
- French translations for interpolated strings (page n of m, pages selected, etc.) now resolve via template matching.
- "Last saved position" shows a one-based page number in English/French (matches Arabic).
- Bulk selection is cleared when the filter or search changes; removing the active category resets the filter.
- Book-language list is computed once per composition scope instead of on every recomposition.
- README version corrected to 1.1.1 / versionCode 4.

### Not changed
- No data format, storage, import/export or persistence logic touched.

### Verification
- NOT compiled and NOT run: no Gradle distribution, Android SDK or Kotlin compiler available here. Source-level review and brace-balance comparison only.
