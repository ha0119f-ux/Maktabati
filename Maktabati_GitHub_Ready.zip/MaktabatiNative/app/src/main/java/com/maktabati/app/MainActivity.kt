package com.maktabati.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.RectF
import android.util.LruCache
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.isSystemInDarkTheme
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

private const val GREEN = 0xFF176044
private data class PageElement(
    val id: String = UUID.randomUUID().toString(),
    var type: String = "text", // text, rectangle, circle, line
    var text: String = "نص جديد",
    var x: Float = 0.12f,
    var y: Float = 0.12f,
    var width: Float = 0.55f,
    var height: Float = 0.12f,
    var color: Long = 0xFF176044,
    var fontSize: Float = 22f,
    var locked: Boolean = false,
    var visible: Boolean = true,
    var groupId: String = ""
)
private data class BookPage(
    val id: String = UUID.randomUUID().toString(), var type: String = "content", var title: String = "",
    var imagePath: String = "", var fit: String = "contain", var rotation: Int = 0, var bg: Long = 0xFFFFFFFF,
    var widthMm: Float = 0f, var heightMm: Float = 0f, var elements: MutableList<PageElement> = mutableListOf()
)
private data class TrashEntry(val book: Book, val deletedAt: Long = System.currentTimeMillis())
private data class Book(
    val id: String = UUID.randomUUID().toString(), var title: String, var author: String = "", var language: String = "العربية",
    var description: String = "", var size: String = "a5", var orientation: String = "portrait", var pages: MutableList<BookPage>,
    var readingStatus: String = "other", var isFavorite: Boolean = false, var created: Long = System.currentTimeMillis(),
    var updated: Long = System.currentTimeMillis(), var lastReadIndex: Int = 0,
    var categoryIds: MutableList<String> = mutableListOf(), var tags: MutableList<String> = mutableListOf(), var isPinned: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaktabatiApp() } }
}

@Composable
private fun MaktabatiApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storage = remember { File(context.filesDir, "maktabati") }
    val prefs = remember { context.getSharedPreferences("maktabati_settings", android.content.Context.MODE_PRIVATE) }
    val dbFile = remember { File(storage, "library.json") }
    val trashFile = remember { File(storage, "trash.json") }
    var books by remember { mutableStateOf(mutableListOf<Book>()) }
    var trashEntries by remember { mutableStateOf(mutableListOf<TrashEntry>()) }
    var screen by remember { mutableStateOf("home") }
    var current by remember { mutableStateOf<Book?>(null) }
    var selectedPage by remember { mutableIntStateOf(0) }
    var readIndex by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf(prefs.getString("language", "ar") ?: "ar") }
    var primary by remember { mutableLongStateOf(prefs.getLong("primary", GREEN)) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", "system") ?: "system") }
    var filter by remember { mutableStateOf("all") }
    var customCategories by remember { mutableStateOf(mutableListOf<String>()) }
    var searchQuery by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(prefs.getString("sort_mode", "updated") ?: "updated") }
    var gridMode by remember { mutableStateOf(prefs.getBoolean("grid_mode", false)) }
    var selectedBookIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showCreate by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }
    var authorInput by remember { mutableStateOf("") }
    var bookLanguage by remember { mutableStateOf("العربية") }
    var descriptionInput by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var pendingImageTarget by remember { mutableStateOf("page") }
    var createCoverPath by remember { mutableStateOf("") }
    val ar = language == "ar"
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) { copyUri(context, uri, storage) }
                val b = current
                if (path != null) {
                    if (pendingImageTarget == "cover" && showCreate) {
                        createCoverPath = path
                    } else if (b != null && selectedPage in b.pages.indices) {
                        val dimensions = withContext(Dispatchers.IO) { imageDimensionsMm(path) }
                        b.pages[selectedPage].apply {
                            imagePath = path
                            widthMm = dimensions.first
                            heightMm = dimensions.second
                        }
                        b.updated = System.currentTimeMillis(); persistBooks(dbFile, books)
                        books = books.toMutableList()
                    }
                }
            }
        }
    }
    val pickManyImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val b = current
        if (b != null && uris.isNotEmpty()) scope.launch {
            val importedPages = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri ->
                    val path = copyUri(context, uri, storage) ?: return@mapNotNull null
                    val dimensions = imagePageDimensionsMm(path)
                    BookPage(
                        title = uri.lastPathSegment?.substringAfterLast('/') ?: "",
                        imagePath = path,
                        widthMm = dimensions.first,
                        heightMm = dimensions.second
                    )
                }
            }
            b.pages.addAll(importedPages)
            b.updated = System.currentTimeMillis(); persistBooks(dbFile, books); books = books.toMutableList()
        }
    }
    val importProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val imported = withContext(Dispatchers.IO) { importBook(context, uri, storage) }
                books = (books + imported).toMutableList(); persistBooks(dbFile, books); toast = if (ar) "تم استيراد المشروع" else "Project imported"
            } catch (_: Exception) { toast = if (ar) "الملف غير صالح" else "Invalid project file" }
        }
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val b = current
        if (uri != null && b != null) scope.launch { try { withContext(Dispatchers.IO) { writePdf(context, uri, b) }; toast = if (ar) "تم حفظ ملف PDF" else "PDF saved" } catch (_: Exception) { toast = if (ar) "تعذر إنشاء PDF" else "Could not create PDF" } }
    }
    val exportProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val b = current
        if (uri != null && b != null) scope.launch {
            try { withContext(Dispatchers.IO) { exportBook(context, uri, b) }; toast = if (ar) "تم تصدير المشروع" else "Project exported" }
            catch (_: Exception) { toast = if (ar) "تعذر التصدير" else "Export failed" }
        }
    }
    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try { withContext(Dispatchers.IO) { exportLibraryBackup(context, uri, books) }; toast = if (ar) "تم إنشاء النسخة الاحتياطية" else "Backup created" }
            catch (_: Exception) { toast = if (ar) "فشل إنشاء النسخة الاحتياطية" else "Backup creation failed" }
        }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val restored = withContext(Dispatchers.IO) { importLibraryBackup(context, uri, storage) }
                books = (books + restored).distinctBy { it.id }.toMutableList()
                withContext(Dispatchers.IO) { persistBooks(dbFile, books) }
                toast = if (ar) "تم استيراد النسخة الاحتياطية" else "Backup restored"
            } catch (_: Exception) { toast = if (ar) "تعذر استعادة النسخة الاحتياطية" else "Could not restore backup" }
        }
    }
    LaunchedEffect(Unit) {
        storage.mkdirs()
        books = withContext(Dispatchers.IO) { loadBooks(dbFile, storage) }.toMutableList()
        trashEntries = withContext(Dispatchers.IO) { loadTrash(trashFile) }.toMutableList()
        val saved = prefs.getString("custom_categories", "[]") ?: "[]"
        customCategories = try { val a=JSONArray(saved); MutableList(a.length()){i->a.getString(i)} } catch (_:Exception) { mutableListOf() }
    }
    fun persist() {
        val snapshot = books.map { book ->
            book.copy(
                pages = book.pages.map { it.copy() }.toMutableList(),
                categoryIds = book.categoryIds.toMutableList(),
                tags = book.tags.toMutableList()
            )
        }
        scope.launch {
            try {
                withContext(Dispatchers.IO) { persistBooks(dbFile, snapshot) }
            } catch (_: Exception) {
                toast = if (ar) "تعذر حفظ المكتبة. لم يتم تأكيد الحفظ." else "Library save failed. Changes were not confirmed saved."
            }
        }
    }
    fun goHome() { screen = "home"; current = null }
    fun persistTrash() {
        val snapshot = trashEntries.toList()
        scope.launch { try { withContext(Dispatchers.IO) { saveTrash(trashFile, snapshot) } } catch (_: Exception) { toast = if (ar) "تعذر حفظ سلة المحذوفات" else "Could not save trash" } }
    }
    fun moveBooksToTrash(items: List<Book>) {
        if (items.isEmpty()) return
        val ids = items.map { it.id }.toSet()
        books.removeAll { it.id in ids }
        items.forEach { book ->
            trashEntries.removeAll { it.book.id == book.id }
            trashEntries.add(TrashEntry(book))
        }
        persist(); persistTrash(); books = books.toMutableList(); trashEntries = trashEntries.toMutableList()
        if (current?.id in ids) goHome()
    }
    fun moveToTrash(book: Book) = moveBooksToTrash(listOf(book))
    fun restoreFromTrash(entry: TrashEntry) {
        trashEntries.removeAll { it.book.id == entry.book.id }
        if (books.none { it.id == entry.book.id }) books.add(entry.book)
        persist(); persistTrash(); books = books.toMutableList(); trashEntries = trashEntries.toMutableList()
    }
    fun openDetails(book: Book) { current = book; screen = "details" }
    fun openEditor(book: Book) { current = book; selectedPage = 0; screen = "editor" }
    fun startReader(book: Book, resume: Boolean) { current = book; readIndex = if (resume) book.lastReadIndex.coerceIn(0, book.pages.lastIndex) else 0; screen = "reader" }
    BackHandler(enabled = screen != "home" || showCreate || showSettings) {
        when { showSettings -> showSettings = false; showCreate -> showCreate = false; screen == "reader" -> screen = "details"; screen == "editor" -> { persist(); screen = "details" }; screen == "details" -> goHome(); screen == "storage" -> goHome(); else -> goHome() }
    }
    val systemDark = isSystemInDarkTheme()
    val darkTheme = when (themeMode) { "dark" -> true; "light" -> false; else -> systemDark }
    val bg = if (darkTheme) Color(0xFF101713) else Color(0xFFF1F5F2)
    val ink = if (darkTheme) Color(0xFFE5EEE8) else Color(0xFF172820)
    val muted = if (darkTheme) Color(0xFFA3B2A9) else Color(0xFF718078)
    val green = Color(primary)
    val themeContent = if (green.luminance() > 0.42f) Color(0xFF172820) else Color.White
    val appColors = if (darkTheme) darkColorScheme(primary = green, onPrimary = themeContent, background = bg, surface = Color(0xFF1A241E), onSurface = ink)
                    else lightColorScheme(primary = green, onPrimary = themeContent, background = bg, surface = Color.White, onSurface = ink)
    MaterialTheme(colorScheme = appColors) {
        Scaffold(containerColor = bg, topBar = {
            Row(Modifier.fillMaxWidth().height(62.dp).background(MaterialTheme.colorScheme.primary).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                if (screen != "home") IconButton(onClick = { when(screen){"reader"->screen="details";"editor"->{persist();screen="details"};"details"->goHome();else->goHome()} }) { Icon(Icons.Default.ArrowBack, null, tint = MaterialTheme.colorScheme.onPrimary) }
                Text("مكتبتي", color = MaterialTheme.colorScheme.onPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(if (ar) " | استوديو إنشاء الكتب" else " | Book Creation Studio", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.78f), fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (screen == "home") { IconButton(onClick = { screen = "storage" }) { Icon(Icons.Default.DriveFileMove, null, tint = MaterialTheme.colorScheme.onPrimary) }; IconButton(onClick = { importProject.launch(arrayOf("application/json", "*/*")) }) { Icon(Icons.Default.Book, null, tint = MaterialTheme.colorScheme.onPrimary) }; IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, null, tint = MaterialTheme.colorScheme.onPrimary) } }
                else if (screen == "editor") IconButton(onClick = { persist(); toast = if(ar) "تم الحفظ محليًا" else "Saved locally" }) { Icon(Icons.Default.Save, null, tint = MaterialTheme.colorScheme.onPrimary) }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "home" -> HomeScreen(books, filter, ar, green, customCategories, searchQuery, sortMode, gridMode, selectedBookIds,
                        onToggleSelection={id->selectedBookIds=if(id in selectedBookIds) selectedBookIds-id else selectedBookIds+id},
                        onClearSelection={selectedBookIds=emptySet()},
                        onBulkStatus={status->books.filter{it.id in selectedBookIds}.forEach{it.readingStatus=status;it.updated=System.currentTimeMillis()};persist();books=books.toMutableList();selectedBookIds=emptySet()},
                        onBulkCategory={category->books.filter{it.id in selectedBookIds}.forEach{b->if(category !in b.categoryIds)b.categoryIds.add(category);b.updated=System.currentTimeMillis()};persist();books=books.toMutableList();selectedBookIds=emptySet()},
                        onBulkMoveCategory={category->books.filter{it.id in selectedBookIds}.forEach{b->b.categoryIds= mutableListOf(category);b.updated=System.currentTimeMillis()};persist();books=books.toMutableList();selectedBookIds=emptySet()},
                        onBulkDelete={val doomed=books.filter{it.id in selectedBookIds};moveBooksToTrash(doomed);selectedBookIds=emptySet()},
                        onFilter={filter=it}, onSearch={searchQuery=it}, onSort={sortMode=it}, onView={gridMode=it},
                        onCategoriesChanged={customCategories=it.toMutableList();prefs.edit().putString("custom_categories",JSONArray(it).toString()).apply()},
                        onAssignCategories={b,ids->b.categoryIds=ids.toMutableList();b.updated=System.currentTimeMillis();persist();books=books.toMutableList()},
                        onTags={b,tags->b.tags=tags.toMutableList();b.updated=System.currentTimeMillis();persist();books=books.toMutableList()},
                        onPin={b->b.isPinned=!b.isPinned;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onCreate={
                        titleInput="";authorInput="";descriptionInput="";bookLanguage="العربية";createCoverPath="";showCreate=true
                    }, onOpen={openDetails(it)}, onFavorite={b->b.isFavorite=!b.isFavorite;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onStatus={b,s->b.readingStatus=s;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onDelete={b->moveToTrash(b)})
                    "storage" -> StorageScreen(
                        books = books, trashEntries = trashEntries, ar = ar,
                        storageBytes = withContextStorageSize(storage),
                        onBackup = { exportBackup.launch("Maktabati_Backup.json") },
                        onRestoreBackup = { importBackup.launch(arrayOf("application/json", "*/*")) },
                        onRestore = { restoreFromTrash(it) },
                        onDeleteForever = { entry ->
                            val remaining = trashEntries.filterNot { it.book.id == entry.book.id }
                            deleteUnreferencedImages(listOf(entry.book), books + remaining.map { it.book }, storage)
                            trashEntries = remaining.toMutableList(); persistTrash()
                        },
                        onEmptyTrash = {
                            deleteUnreferencedImages(trashEntries.map { it.book }, books, storage)
                            trashEntries.clear(); persistTrash(); trashEntries = mutableListOf()
                        },
                        onBack = { screen = "home" }
                    )
                    "details" -> current?.let { DetailsScreen(it, ar, onEdit={openEditor(it)}, onRead={startReader(it,true)}) }
                    "editor" -> current?.let { b -> EditorScreen(b, selectedPage, ar, green,
                        onSelect={selectedPage=it}, onAdd={b.pages.add(BookPage(title=if(ar) "صفحة جديدة" else "New page"));selectedPage=b.pages.lastIndex;persist();books=books.toMutableList()},
                        onUpload={pendingImageTarget="page";pickImage.launch("image/*")}, onImportImages={pickManyImages.launch("image/*")}, onMove={delta->val from=selectedPage;val to=(from+delta).coerceIn(0,b.pages.lastIndex);if(to!=from){val moved=b.pages.removeAt(from);b.pages.add(to,moved);selectedPage=to;persist();books=books.toMutableList()}}, onAddBack={b.pages.add(BookPage(type="back",title=if(ar) "الغلاف الخلفي" else "Back cover"));selectedPage=b.pages.lastIndex;persist();books=books.toMutableList()}, onDuplicate={val p=b.pages[selectedPage].copy(id=UUID.randomUUID().toString(),title=b.pages[selectedPage].title+if(ar) " - نسخة" else " - Copy");b.pages.add(selectedPage+1,p);selectedPage++;persist();books=books.toMutableList()},
                        onDelete={if(b.pages.size>1){b.pages.removeAt(selectedPage);selectedPage=selectedPage.coerceAtMost(b.pages.lastIndex);persist();books=books.toMutableList()}},
                        onChange={persist();books=books.toMutableList()}, onExport={exportProject.launch("${safeName(b.title)}.kutubi.json")}) }
                    "reader" -> current?.let { b -> ReaderScreen(b, readIndex, ar, onIndex={readIndex=it;b.lastReadIndex=it;b.readingStatus=if(it>=b.pages.lastIndex) "completed" else if(it>0) "reading" else b.readingStatus;persist();books=books.toMutableList()}, onPdf={savePdf.launch("${safeName(b.title)}.pdf")}) }
                }
            }
        }
        if (showCreate) AlertDialog(onDismissRequest={showCreate=false}, title={Text(if(ar) "إعداد كتاب جديد" else "New book settings")}, text={
            Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(titleInput,{titleInput=it},label={Text(if(ar) "عنوان الكتاب *" else "Book title *")},singleLine=true)
                OutlinedTextField(authorInput,{authorInput=it},label={Text(if(ar) "اسم المؤلف" else "Author")},singleLine=true)
                OutlinedTextField(descriptionInput,{descriptionInput=it},label={Text(if(ar) "وصف الكتاب" else "Description")})
                Text(if(ar) "لغة الكتاب" else "Book language",fontWeight=FontWeight.SemiBold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf("العربية","English","Français","أخرى").forEach { FilterChip(selected=bookLanguage==it,onClick={bookLanguage=it},label={Text(it)}) } }
                Text(
                    if(ar) "سيتم تحديد أبعاد كل صفحة تلقائيًا من الصورة التي تضيفها، دون الحاجة لاختيار A4 أو A5 أو إدخال الطول والعرض."
                    else "Each page will automatically use the dimensions and proportions of its selected image. No A4/A5 selection or manual width and height are required.",
                    fontSize=12.sp, color=Color.Gray
                )
                OutlinedButton(onClick={pendingImageTarget="cover";pickImage.launch("image/*")}) { Icon(Icons.Default.Image,null); Text(if(ar) "صورة الغلاف (اختياري)" else "Optional cover image") }
            }
        }, confirmButton={TextButton(onClick={
            if(titleInput.isNotBlank()) {
                val coverDimensions = if(createCoverPath.isNotBlank()) imagePageDimensionsMm(createCoverPath) else (0f to 0f)
                val initialPages=mutableListOf(
                    BookPage(type="cover",title=if(ar) "الغلاف الأمامي" else "Front cover",imagePath=createCoverPath,widthMm=coverDimensions.first,heightMm=coverDimensions.second),
                    BookPage(title=if(ar) "الصفحة الأولى" else "Page 1")
                )
                val b=Book(title=titleInput.trim(),author=authorInput.trim(),language=bookLanguage,description=descriptionInput.trim(),size="a5",orientation="portrait",pages=initialPages)
                books.add(b);persist();showCreate=false;openEditor(b)
            }
        }){Text(if(ar) "إنشاء الكتاب" else "Create book")}}, dismissButton={TextButton(onClick={showCreate=false}){Text(if(ar) "إلغاء" else "Cancel")}})
        if(showSettings) AlertDialog(
            onDismissRequest={showSettings=false},
            title={Text(if(ar) "الإعدادات" else "Settings", fontWeight=FontWeight.Bold)},
            text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(13.dp)){
                Text(if(ar) "لغة التطبيق" else "App language",fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected=ar,onClick={language="ar"},label={Text("العربية")})
                    FilterChip(selected=!ar,onClick={language="en"},label={Text("English")})
                }
                Divider()
                Text(if(ar) "مظهر التطبيق" else "App appearance",fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected=themeMode=="light",onClick={themeMode="light"},label={Text(if(ar) "فاتح" else "Light")})
                    FilterChip(selected=themeMode=="dark",onClick={themeMode="dark"},label={Text(if(ar) "داكن" else "Dark")})
                    FilterChip(selected=themeMode=="system",onClick={themeMode="system"},label={Text(if(ar) "حسب النظام" else "System")})
                }
                Divider()
                Text(if(ar) "اللون الأساسي" else "Accent color",fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){
                    listOf(0xFF176044,0xFF2457A6,0xFF7041A6,0xFFA64B35,0xFFB17A18,0xFF344054,0xFF00796B,0xFFAD1457).forEach { c ->
                        Box(Modifier.size(32.dp).clip(CircleShape).background(Color(c)).border(if(primary==c)3.dp else 1.dp,if(primary==c) MaterialTheme.colorScheme.onSurface else Color.Gray,CircleShape).clickable{primary=c})
                    }
                }
                Divider()
                Text(if(ar) "عرض المكتبة افتراضيًا" else "Default library layout",fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected=!gridMode,onClick={gridMode=false},label={Text(if(ar) "قائمة" else "List")},leadingIcon={Icon(Icons.Default.ViewList,null)})
                    FilterChip(selected=gridMode,onClick={gridMode=true},label={Text(if(ar) "شبكة" else "Grid")},leadingIcon={Icon(Icons.Default.GridView,null)})
                }
                Divider()
                Text(if(ar) "ترتيب الكتب الافتراضي" else "Default book sorting",fontWeight=FontWeight.Bold)
                Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
                    listOf("updated" to (if(ar) "آخر تعديل" else "Recently updated"), "title" to (if(ar) "العنوان" else "Title"), "created" to (if(ar) "تاريخ الإنشاء" else "Date created")).forEach { (key,label) ->
                        Row(Modifier.fillMaxWidth().clickable{sortMode=key}.padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically) {
                            RadioButton(selected=sortMode==key,onClick={sortMode=key})
                            Text(label)
                        }
                    }
                }
                Text(if(ar) "تُحفظ هذه التفضيلات على هذا الجهاز." else "These preferences are saved on this device.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
            }},
            confirmButton={TextButton(onClick={
                prefs.edit().putString("language",language).putLong("primary",primary)
                    .putString("theme_mode",themeMode).putBoolean("grid_mode",gridMode)
                    .putString("sort_mode",sortMode).apply()
                showSettings=false
            }){Text(if(ar) "حفظ الإعدادات" else "Save settings")}},
            dismissButton={TextButton(onClick={showSettings=false}){Text(if(ar) "إلغاء" else "Cancel")}}
        )
        if(toast.isNotBlank()) LaunchedEffect(toast) { kotlinx.coroutines.delay(2400);toast="" }
    }
}

@Composable
private fun StorageScreen(
    books: List<Book>, trashEntries: List<TrashEntry>, ar: Boolean, storageBytes: Long,
    onBackup: () -> Unit, onRestoreBackup: () -> Unit,
    onRestore: (TrashEntry) -> Unit, onDeleteForever: (TrashEntry) -> Unit,
    onEmptyTrash: () -> Unit, onBack: () -> Unit
) {
    var confirmEmpty by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (ar) "التخزين والنسخ الاحتياطي" else "Storage & backup", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text(if (ar) "رجوع" else "Back") }
        }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(if (ar) "ملخص المكتبة" else "Library overview", fontWeight = FontWeight.Bold)
            Text((if (ar) "عدد الكتب: " else "Books: ") + books.size)
            Text((if (ar) "في سلة المحذوفات: " else "In trash: ") + trashEntries.size)
            Text((if (ar) "المساحة المستخدمة داخل بيانات التطبيق: " else "App data storage used: ") + formatBytes(storageBytes))
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (ar) "النسخ الاحتياطي" else "Backup", fontWeight = FontWeight.Bold)
            Text(if (ar) "تصدير نسخة JSON تشمل الكتب والصفحات والصور المضمنة. احتفظ بها في مكان آمن." else "Export a JSON backup containing books, pages and embedded images. Keep it somewhere safe.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text(if (ar) "إنشاء نسخة احتياطية" else "Create backup") }
            OutlinedButton(onClick = onRestoreBackup, modifier = Modifier.fillMaxWidth()) { Text(if (ar) "استعادة نسخة احتياطية" else "Restore backup") }
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(if (ar) "سلة المحذوفات" else "Trash", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); if (trashEntries.isNotEmpty()) TextButton(onClick = { confirmEmpty = true }) { Text(if (ar) "إفراغ السلة" else "Empty trash") } }
            if (trashEntries.isEmpty()) Text(if (ar) "سلة المحذوفات فارغة." else "Trash is empty.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            trashEntries.forEach { entry ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(entry.book.title, fontWeight = FontWeight.SemiBold); Text(if (ar) "يمكنك استعادته أو حذفه نهائيًا." else "Restore it or delete it permanently.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    TextButton(onClick = { onRestore(entry) }) { Text(if (ar) "استعادة" else "Restore") }
                    TextButton(onClick = { onDeleteForever(entry) }) { Text(if (ar) "حذف نهائي" else "Delete") }
                }
                Divider()
            }
        } }
    }
    if (confirmEmpty) AlertDialog(onDismissRequest = { confirmEmpty = false }, title = { Text(if (ar) "إفراغ سلة المحذوفات؟" else "Empty trash?") }, text = { Text(if (ar) "لن تظهر الكتب المحذوفة في السلة بعد ذلك. لا يمكن التراجع عن هذا الإجراء." else "Removed items will no longer be available in trash. This cannot be undone.") }, confirmButton = { TextButton(onClick = { onEmptyTrash(); confirmEmpty = false }) { Text(if (ar) "إفراغ" else "Empty") } }, dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text(if (ar) "إلغاء" else "Cancel") } })
}

private fun deleteUnreferencedImages(candidates: List<Book>, retained: List<Book>, storage: File) {
    val retainedPaths = retained.flatMap { it.pages }.map { it.imagePath }.filter { it.isNotBlank() }.toSet()
    val root = try { storage.canonicalFile } catch (_: Exception) { return }
    candidates.flatMap { it.pages }.map { it.imagePath }.filter { it.isNotBlank() && it !in retainedPaths }.distinct().forEach { path ->
        try {
            val file = File(path).canonicalFile
            if (file.parentFile == root && file.isFile) file.delete()
        } catch (_: Exception) { }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(java.util.Locale.US, "%.1f KB", kb)
    return String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
}

private fun withContextStorageSize(dir: File): Long = try { dir.walkTopDown().filter { it.isFile }.fold(0L) { total, file -> total + file.length() } } catch (_: Exception) { 0L }

@Composable
private fun HomeScreen(
    books: List<Book>, filter: String, ar: Boolean, green: Color, categories: List<String>, query: String,
    sortMode: String, gridMode: Boolean, selectedBookIds: Set<String>, onToggleSelection:(String)->Unit, onClearSelection:()->Unit,
    onBulkStatus:(String)->Unit, onBulkCategory:(String)->Unit, onBulkMoveCategory:(String)->Unit, onBulkDelete:()->Unit, onFilter:(String)->Unit, onSearch:(String)->Unit,
    onSort:(String)->Unit, onView:(Boolean)->Unit, onCategoriesChanged:(List<String>)->Unit,
    onAssignCategories:(Book,List<String>)->Unit, onTags:(Book,List<String>)->Unit, onPin:(Book)->Unit,
    onCreate:()->Unit, onOpen:(Book)->Unit, onFavorite:(Book)->Unit, onStatus:(Book,String)->Unit, onDelete:(Book)->Unit
) {
    val keys=listOf("all","favorites","later","completed","reading")
    val labels=if(ar) listOf("الكل","المفضلة","للقراءة لاحقًا","تمت القراءة","قيد القراءة") else listOf("All","Favorites","Read later","Completed","Reading")
    var manageCategories by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf("") }
    var editingBook by remember { mutableStateOf<Book?>(null) }
    var tagInput by remember { mutableStateOf("") }
    var categorySelection by remember(editingBook?.id) { mutableStateOf(editingBook?.categoryIds?.toSet() ?: emptySet()) }
    var bulkStatusExpanded by remember { mutableStateOf(false) }
    var bulkCategoryExpanded by remember { mutableStateOf(false) }
    var confirmBulkDelete by remember { mutableStateOf(false) }
    val filtered = books.filter { b ->
        val matchesFilter = when {
            filter=="all" -> true
            filter=="favorites" -> b.isFavorite
            filter in listOf("later","completed","reading") -> b.readingStatus==filter
            else -> filter.removePrefix("cat:") in b.categoryIds
        }
        val q=query.trim().lowercase()
        val matchesQuery=q.isBlank() || listOf(b.title,b.author,b.description,b.language).any{it.lowercase().contains(q)} || b.tags.any{it.lowercase().contains(q)}
        matchesFilter && matchesQuery
    }.sortedWith(compareByDescending<Book>{it.isPinned}.then(when(sortMode){
        "title" -> compareBy<Book>{it.title.lowercase()}
        "created" -> compareByDescending<Book>{it.created}
        "pages" -> compareByDescending<Book>{it.pages.size}
        else -> compareByDescending<Book>{it.updated}
    }))
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text(if(ar) "مكتبتك" else "Your Library",fontSize=25.sp,fontWeight=FontWeight.Bold,color=Color(0xFF172820))
        Text(if(ar) "نظّم كتبك وابحث عنها بسهولة." else "Organize and find your books easily.",color=Color(0xFF718078),fontSize=13.sp)
        Button(onClick=onCreate,modifier=Modifier.fillMaxWidth().padding(vertical=12.dp),colors=ButtonDefaults.buttonColors(containerColor=green),shape=RoundedCornerShape(11.dp)){Icon(Icons.Default.Add,null);Text(if(ar) "إنشاء كتاب جديد" else "Create new book")}
        OutlinedTextField(value=query,onValueChange=onSearch,modifier=Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text(if(ar) "ابحث بالعنوان أو المؤلف أو الوسوم..." else "Search title, author, description or tags...")})
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                keys.forEachIndexed{i,k->FilterChip(selected=filter==k,onClick={onFilter(k)},label={Text(labels[i])})}
                categories.forEach { c->FilterChip(selected=filter=="cat:$c",onClick={onFilter(if(filter=="cat:$c") "all" else "cat:$c")},label={Text(c)}) }
            }
            IconButton(onClick={manageCategories=true}){Icon(Icons.Default.Label,if(ar) "إدارة التصنيفات" else "Manage categories")}
        }
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
            Row(verticalAlignment=Alignment.CenterVertically){Text("${filtered.size} ${if(ar) "كتاب" else "books"}",fontSize=12.sp,color=Color.Gray);Spacer(Modifier.width(8.dp));var sortExpanded by remember{mutableStateOf(false)};Box{TextButton(onClick={sortExpanded=true}){Icon(Icons.Default.Sort,null);Text(if(ar) "ترتيب" else "Sort")};DropdownMenu(sortExpanded,{sortExpanded=false}){listOf("updated","title","created","pages").forEach{v->DropdownMenuItem(text={Text(when(v){"title"->if(ar)"العنوان" else "Title";"created"->if(ar)"الأحدث إنشاءً" else "Newest created";"pages"->if(ar)"عدد الصفحات" else "Page count";else->if(ar)"آخر تعديل" else "Recently updated"})},onClick={onSort(v);sortExpanded=false})}}}}
            Row(verticalAlignment=Alignment.CenterVertically){TextButton(onClick={if(selectedBookIds.isEmpty()) filtered.forEach{onToggleSelection(it.id)} else onClearSelection()}){Icon(Icons.Default.Checklist,null);Text(if(selectedBookIds.isEmpty()){if(ar)"تحديد" else "Select"}else{if(ar)"إلغاء التحديد" else "Clear"})};IconButton(onClick={onView(!gridMode)}){Icon(if(gridMode) Icons.Default.ViewList else Icons.Default.GridView,if(gridMode) "List view" else "Grid view")}}
        }
        if(selectedBookIds.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
            Text("${selectedBookIds.size} ${if(ar)"محدد" else "selected"}",fontSize=12.sp,color=green)
            Box { TextButton(onClick={bulkStatusExpanded=true}){Icon(Icons.Default.DriveFileMove,null);Text(if(ar)"نقل إلى قائمة" else "Move to list")};DropdownMenu(bulkStatusExpanded,{bulkStatusExpanded=false}){listOf("later","reading","completed","other").forEach{st->DropdownMenuItem(text={Text(statusName(st,ar))},onClick={onBulkStatus(st);bulkStatusExpanded=false})}} }
            Box { TextButton(onClick={bulkCategoryExpanded=true}){Icon(Icons.Default.Label,null);Text(if(ar)"التصنيفات" else "Categories")};DropdownMenu(bulkCategoryExpanded,{bulkCategoryExpanded=false}){categories.forEach{c->DropdownMenuItem(text={Text((if(ar)"إضافة إلى: " else "Add to: ")+c)},onClick={onBulkCategory(c);bulkCategoryExpanded=false});DropdownMenuItem(text={Text((if(ar)"نقل إلى: " else "Move to: ")+c)},onClick={onBulkMoveCategory(c);bulkCategoryExpanded=false})}} }
            TextButton(onClick={confirmBulkDelete=true}){Icon(Icons.Default.Delete,null,tint=Color.Red);Text(if(ar)"حذف" else "Delete",color=Color.Red)}
        }
        if(filtered.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(if(books.isEmpty()){if(ar)"لا توجد كتب بعد." else "No books yet."}else{if(ar)"لا توجد نتائج مطابقة." else "No matching books."},color=Color.Gray,textAlign=TextAlign.Center)}
        else if(gridMode) LazyVerticalGrid(columns=GridCells.Fixed(2),modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            gridItems(filtered,key={it.id}){b->Column { Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=b.id in selectedBookIds,onCheckedChange={onToggleSelection(b.id)});Text(if(ar)"تحديد" else "Select",fontSize=11.sp,color=Color.Gray)};BookGridCard(b,green,ar,onOpen,onFavorite,onPin,onManage={editingBook=b;categorySelection=b.categoryIds.toSet();tagInput=b.tags.joinToString(", ")},onDelete=onDelete,onStatus=onStatus) } }
        } else LazyColumn(modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(filtered,key={it.id}){b->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=b.id in selectedBookIds,onCheckedChange={onToggleSelection(b.id)});Box(Modifier.weight(1f)){BookListCard(b,green,ar,onOpen,onFavorite,onPin,onManage={editingBook=b;categorySelection=b.categoryIds.toSet();tagInput=b.tags.joinToString(", ")},onDelete=onDelete,onStatus=onStatus)} }}
        }
    }
    if(confirmBulkDelete) AlertDialog(onDismissRequest={confirmBulkDelete=false},title={Text(if(ar)"تأكيد حذف الكتب" else "Confirm book deletion")},text={Text(if(ar)"هل تريد نقل الكتب المحددة إلى سلة المحذوفات؟ يمكنك استعادتها لاحقًا." else "Move the selected books to trash? You can restore them later.")},confirmButton={TextButton(onClick={onBulkDelete();confirmBulkDelete=false}){Text(if(ar)"حذف" else "Delete",color=Color.Red)}},dismissButton={TextButton(onClick={confirmBulkDelete=false}){Text(if(ar)"إلغاء" else "Cancel")}})
    if(manageCategories) AlertDialog(onDismissRequest={manageCategories=false},title={Text(if(ar)"إدارة التصنيفات" else "Manage categories")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(newCategory,{newCategory=it},singleLine=true,label={Text(if(ar)"اسم التصنيف الجديد" else "New category name")})
        Button(onClick={if(newCategory.isNotBlank() && newCategory.trim() !in categories){onCategoriesChanged(categories+newCategory.trim());newCategory=""}},modifier=Modifier.fillMaxWidth()){Text(if(ar)"إضافة تصنيف" else "Add category")}
        categories.forEach{c->Row(verticalAlignment=Alignment.CenterVertically){Text(c,Modifier.weight(1f));TextButton(onClick={onCategoriesChanged(categories-c);books.filter{c in it.categoryIds}.forEach{b->onAssignCategories(b,b.categoryIds-c)}}){Text(if(ar)"حذف" else "Remove",color=Color.Red)}}}
    }},confirmButton={TextButton(onClick={manageCategories=false}){Text(if(ar)"إغلاق" else "Close")}})
    editingBook?.let{b->AlertDialog(onDismissRequest={editingBook=null},title={Text(if(ar)"تصنيفات ووسوم الكتاب" else "Book categories & tags")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text(if(ar)"التصنيفات (يمكن اختيار أكثر من تصنيف)" else "Categories (select multiple)")
        categories.forEach{c->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=c in categorySelection,onCheckedChange={checked->categorySelection=if(checked)categorySelection+c else categorySelection-c});Text(c)}}
        OutlinedTextField(tagInput,{tagInput=it},label={Text(if(ar)"الوسوم، افصل بينها بفواصل" else "Tags, comma separated")})
    }},confirmButton={TextButton(onClick={onAssignCategories(b,categorySelection.toList());onTags(b,tagInput.split(",").map{it.trim()}.filter{it.isNotBlank()}.distinct());editingBook=null}){Text(if(ar)"حفظ" else "Save")}},dismissButton={TextButton(onClick={editingBook=null}){Text(if(ar)"إلغاء" else "Cancel")}})}
}

@Composable private fun BookListCard(b:Book,green:Color,ar:Boolean,onOpen:(Book)->Unit,onFavorite:(Book)->Unit,onPin:(Book)->Unit,onManage:()->Unit,onDelete:(Book)->Unit,onStatus:(Book,String)->Unit){
    Card(Modifier.fillMaxWidth().clickable{onOpen(b)},shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){BookCover(b,Modifier.size(78.dp,104.dp),green);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){
            Text(b.title,fontWeight=FontWeight.Bold,fontSize=16.sp);Text("${b.pages.size} ${if(ar)"صفحة" else "pages"} · ${b.author.ifBlank{if(ar)"مؤلف غير محدد" else "Unknown author"}}",fontSize=11.sp,color=Color.Gray)
            if(b.categoryIds.isNotEmpty())Text(b.categoryIds.joinToString("، "),fontSize=10.sp,color=green,maxLines=1)
            if(b.tags.isNotEmpty())Text(b.tags.joinToString(" · "),fontSize=10.sp,color=Color.Gray,maxLines=1)
            Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={onFavorite(b)}){Icon(if(b.isFavorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(b.isFavorite)Color.Red else green)};IconButton(onClick={onPin(b)}){Icon(Icons.Default.PushPin,null,tint=if(b.isPinned)green else Color.Gray)};TextButton(onClick=onManage){Text(if(ar)"تنظيم" else "Organize")};TextButton(onClick=onOpen(b)){Text(if(ar)"فتح" else "Open")};IconButton(onClick={onDelete(b)}){Icon(Icons.Default.Delete,null,tint=Color.Red)}}
            var statusExpanded by remember { mutableStateOf(false) }
            Box { TextButton(onClick={statusExpanded=true}){Text(statusName(b.readingStatus,ar),fontSize=11.sp)};DropdownMenu(statusExpanded,{statusExpanded=false}){listOf("other","later","reading","completed").forEach{st->DropdownMenuItem(text={Text(statusName(st,ar))},onClick={statusExpanded=false;onStatus(b,st)})}} }
        }}
    }
}
@Composable private fun BookGridCard(b:Book,green:Color,ar:Boolean,onOpen:(Book)->Unit,onFavorite:(Book)->Unit,onPin:(Book)->Unit,onManage:()->Unit,onDelete:(Book)->Unit,onStatus:(Book,String)->Unit){
    Card(Modifier.fillMaxWidth().clickable{onOpen(b)},shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
        Column(Modifier.padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){BookCover(b,Modifier.fillMaxWidth().height(145.dp),green);Text(b.title,fontWeight=FontWeight.Bold,maxLines=2,minLines=1);Text("${b.pages.size} ${if(ar)"صفحة" else "pages"}",fontSize=11.sp,color=Color.Gray);Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={onFavorite(b)}){Icon(if(b.isFavorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(b.isFavorite)Color.Red else green)};IconButton(onClick={onPin(b)}){Icon(Icons.Default.PushPin,null,tint=if(b.isPinned)green else Color.Gray)};IconButton(onClick=onManage){Icon(Icons.Default.Label,null)};IconButton(onClick={onDelete(b)}){Icon(Icons.Default.Delete,null,tint=Color.Red)}};var statusExpanded by remember{mutableStateOf(false)};Box{TextButton(onClick={statusExpanded=true}){Text(statusName(b.readingStatus,ar),fontSize=10.sp)};DropdownMenu(statusExpanded,{statusExpanded=false}){listOf("other","later","reading","completed").forEach{st->DropdownMenuItem(text={Text(statusName(st,ar))},onClick={statusExpanded=false;onStatus(b,st)})}}}}
    }
}

@Composable private fun BookCover(book: Book, modifier: Modifier=Modifier, green: Color=Color(GREEN)) {
    val path=book.pages.firstOrNull{it.type=="cover"}?.imagePath.orEmpty()
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(if(path.isBlank()) green else Color.White),contentAlignment=Alignment.Center){
        val bmp=remember(path){if(path.isNotBlank()) BitmapFactory.decodeFile(path) else null}
        if(bmp!=null) Image(bmp.asImageBitmap(),null,Modifier.fillMaxSize()) else Text("م",fontSize=40.sp,fontWeight=FontWeight.Black,color=Color(0xFFEAF4ED))
    }
}

@Composable private fun DetailsScreen(book: Book, ar: Boolean, onEdit:()->Unit, onRead:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        BookCover(book,Modifier.size(width=205.dp,height=290.dp))
        Spacer(Modifier.height(22.dp));Text(book.title,fontSize=27.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
        Text("${book.author.ifBlank{if(ar) "مؤلف غير محدد" else "Unknown author"}} · ${book.pages.size} ${if(ar) "صفحة" else "pages"} · ${book.language}",color=Color.Gray,textAlign=TextAlign.Center)
        if(book.description.isNotBlank()) Text(book.description,Modifier.padding(top=12.dp),textAlign=TextAlign.Center)
        Spacer(Modifier.height(20.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick=onEdit){Text(if(ar) "✎ تعديل الكتاب" else "✎ Edit book")};OutlinedButton(onClick=onRead){Text(if(ar) "◉ قراءة الكتاب" else "◉ Read book")}}
        Text(if(book.lastReadIndex>0){if(ar) "آخر موضع قراءة محفوظ: الصفحة ${book.lastReadIndex}. يمكنك المتابعة من حيث توقفت." else "Last saved position: page ${book.lastReadIndex}. Resume reading."}else{if(ar) "لم تبدأ قراءة هذا الكتاب بعد." else "You have not started reading this book yet."},Modifier.padding(top=18.dp).fillMaxWidth().background(Color(0xFFEDF5EF),RoundedCornerShape(11.dp)).padding(14.dp),color=Color(0xFF315D45),textAlign=TextAlign.Center,fontSize=13.sp)
    }
}

@Composable private fun EditorScreen(book: Book, selected: Int, ar: Boolean, green: Color, onSelect:(Int)->Unit, onAdd:()->Unit, onUpload:()->Unit, onImportImages:()->Unit, onMove:(Int)->Unit, onAddBack:()->Unit, onDuplicate:()->Unit, onDelete:()->Unit, onChange:()->Unit, onExport:()->Unit) {
    val page=book.pages.getOrNull(selected) ?: return
    var tab by remember { mutableStateOf("pages") }
    var pageCountInput by remember(book.id) { mutableStateOf(book.pages.size.toString()) }
    LaunchedEffect(book.pages.size) { pageCountInput=book.pages.size.toString() }
    var showPageCountConfirm by remember { mutableStateOf(false) }
    var pendingPageCount by remember { mutableIntStateOf(book.pages.size) }
    var previewZoom by remember(book.id, selected) { mutableFloatStateOf(1f) }
    var pageJumpInput by remember(book.id) { mutableStateOf((selected + 1).toString()) }
    var editingElementId by remember(book.id, selected) { mutableStateOf("") }
    var copiedElement by remember(book.id) { mutableStateOf<PageElement?>(null) }
    var selectedElementIds by remember(book.id, selected) { mutableStateOf(setOf<String>()) }
    LaunchedEffect(selected) { pageJumpInput=(selected+1).toString() }
    val history = remember(book.id) { mutableStateListOf(bookToJson(book, false).toString()) }
    var historyIndex by remember(book.id) { mutableIntStateOf(0) }
    fun restoreSnapshot(raw: String) {
        val restored = objToBook(JSONObject(raw))
        book.title = restored.title; book.author = restored.author; book.language = restored.language
        book.description = restored.description; book.size = restored.size; book.orientation = restored.orientation
        book.pages = restored.pages; book.readingStatus = restored.readingStatus; book.isFavorite = restored.isFavorite
        book.created = restored.created; book.updated = restored.updated; book.lastReadIndex = restored.lastReadIndex
        book.categoryIds = restored.categoryIds; book.tags = restored.tags; book.isPinned = restored.isPinned
        onSelect(selected.coerceIn(0, (book.pages.size - 1).coerceAtLeast(0)))
    }
    fun commitChange() {
        val snapshot = bookToJson(book, false).toString()
        if (history.getOrNull(historyIndex) != snapshot) {
            while (history.lastIndex > historyIndex) history.removeAt(history.lastIndex)
            history.add(snapshot)
            if (history.size > 40) history.removeAt(0)
            historyIndex = history.lastIndex
        }
        onChange()
    }
    fun undoChange() { if (historyIndex > 0) { historyIndex--; restoreSnapshot(history[historyIndex]); onChange() } }
    fun redoChange() { if (historyIndex < history.lastIndex) { historyIndex++; restoreSnapshot(history[historyIndex]); onChange() } }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={undoChange()}, enabled=historyIndex>0) { Icon(Icons.Default.Undo, contentDescription=if(ar) "تراجع" else "Undo") }
            IconButton(onClick={redoChange()}, enabled=historyIndex<history.lastIndex) { Icon(Icons.Default.Redo, contentDescription=if(ar) "إعادة" else "Redo") }
            listOf("pages" to if(ar) "الصفحات" else "Pages","design" to if(ar) "إعدادات الصفحة" else "Page settings","export" to if(ar) "المشروع" else "Project").forEach{(k,v)->FilterChip(selected=tab==k,onClick={tab=k},label={Text(v,fontSize=12.sp)})}
        }
        when(tab){
            "pages" -> {
                Text("${if(ar) "صفحات الكتاب" else "Book pages"} (${book.pages.size})",fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically) {
                    OutlinedTextField(value=pageCountInput, onValueChange={pageCountInput=it.filter { ch -> ch.isDigit() }.take(3)}, label={Text(if(ar) "عدد الصفحات" else "Page count")}, singleLine=true, modifier=Modifier.weight(1f))
                    Button(onClick={
                        val target=pageCountInput.toIntOrNull()?.coerceIn(1,500)
                        if(target != null && target != book.pages.size) {
                            if(target < book.pages.size) { pendingPageCount=target; showPageCountConfirm=true }
                            else { repeat(target-book.pages.size) { book.pages.add(BookPage(title=if(ar) "صفحة جديدة" else "New page")) }; pageCountInput=target.toString(); commitChange() }
                        } else pageCountInput=book.pages.size.toString()
                    }) { Text(if(ar) "تطبيق" else "Apply") }
                }
                Text(if(ar) "يمكنك زيادة العدد أو تقليله. عند التقليل ستُحذف الصفحات الأخيرة فقط بعد التأكيد." else "You can increase or decrease the count. Reducing it removes only the last pages after confirmation.", fontSize=11.sp, color=Color.Gray)
                Row(Modifier.fillMaxWidth().height(138.dp).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) { book.pages.forEachIndexed{i,p->Column(Modifier.width(92.dp).clip(RoundedCornerShape(9.dp)).background(if(i==selected) Color(0xFFE7F1EB) else Color.White).border(if(i==selected)2.dp else 1.dp,if(i==selected)green else Color(0xFFDfe8e1),RoundedCornerShape(9.dp)).clickable{onSelect(i);pageJumpInput=(i+1).toString()}.padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally){PageThumbnail(p,Modifier.weight(1f).fillMaxWidth());Text(p.title.ifBlank{if(ar) "صفحة ${i+1}" else "Page ${i+1}"},fontSize=10.sp,maxLines=1)} } }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={onAdd();commitChange()},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Text(if(ar) "إضافة صفحة" else "Add page",fontSize=11.sp)};OutlinedButton(onClick=onUpload,modifier=Modifier.weight(1f)){Icon(Icons.Default.Image,null);Text(if(ar) "رفع صورة" else "Upload",fontSize=11.sp)}}
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick=onImportImages,modifier=Modifier.weight(1f)){Text(if(ar) "استيراد صور كصفحات" else "Import images as pages",fontSize=10.sp)};OutlinedButton(onClick={onAddBack();commitChange()},modifier=Modifier.weight(1f)){Text(if(ar) "إضافة غلاف خلفي" else "Add back cover",fontSize=10.sp)}}
            }
            "design" -> {
                Text(if(ar) "إعدادات الصفحة" else "Page settings",fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
                val editingElement = page.elements.firstOrNull { it.id == editingElementId }
                Text(if(ar) "عناصر الصفحة" else "Page elements", fontWeight=FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick={ page.elements.add(PageElement()); commitChange() }, modifier=Modifier.weight(1f)) { Text(if(ar) "+ نص" else "+ Text") }
                    OutlinedButton(onClick={ page.elements.add(PageElement(type="rectangle",text="",x=0.18f,y=0.35f,width=0.42f,height=0.12f)); commitChange() }, modifier=Modifier.weight(1f)) { Text(if(ar) "+ مستطيل" else "+ Rectangle") }
                    OutlinedButton(onClick={ page.elements.add(PageElement(type="circle",text="",x=0.25f,y=0.5f,width=0.2f,height=0.2f)); commitChange() }, modifier=Modifier.weight(1f)) { Text(if(ar) "+ دائرة" else "+ Circle") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick={ page.elements.add(PageElement(type="line",text="",x=0.12f,y=0.68f,width=0.7f,height=0.015f)); commitChange() }, modifier=Modifier.weight(1f)) { Text(if(ar) "+ خط" else "+ Line") }
                    OutlinedButton(onClick={ if(editingElement!=null){page.elements.removeAll{it.id==editingElementId};editingElementId="";commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "حذف العنصر المحدد" else "Delete selected") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={ if(editingElement!=null){copiedElement=editingElement.copy(id=UUID.randomUUID().toString());} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "نسخ" else "Copy") }
                    OutlinedButton(onClick={ copiedElement?.let { c -> val clone=c.copy(id=UUID.randomUUID().toString(),x=(c.x+0.04f).coerceAtMost((1f-c.width).coerceAtLeast(0f)),y=(c.y+0.04f).coerceAtMost((1f-c.height).coerceAtLeast(0f)),locked=false,groupId="");page.elements.add(clone);editingElementId=clone.id;commitChange() } }, enabled=copiedElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "لصق" else "Paste") }
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.locked=!editingElement.locked;commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "قفل/فتح" else "Lock/Unlock") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.visible=!editingElement.visible;commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "إظهار/إخفاء" else "Show/Hide") }
                    OutlinedButton(onClick={ if(editingElement!=null){val i=page.elements.indexOfFirst{it.id==editingElementId};if(i>0){val e=page.elements.removeAt(i);page.elements.add(i-1,e);commitChange()} } }, enabled=editingElement!=null && page.elements.indexOfFirst{it.id==editingElementId}>0, modifier=Modifier.weight(1f)) { Text(if(ar) "للخلف" else "Send back") }
                    OutlinedButton(onClick={ if(editingElement!=null){val i=page.elements.indexOfFirst{it.id==editingElementId};if(i>=0 && i<page.elements.lastIndex){val e=page.elements.removeAt(i);page.elements.add(i+1,e);commitChange()} } }, enabled=editingElement!=null && page.elements.indexOfFirst{it.id==editingElementId} in 0 until (page.elements.lastIndex.coerceAtLeast(0)), modifier=Modifier.weight(1f)) { Text(if(ar) "للأمام" else "Bring front") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.x=((1f-editingElement.width)/2f).coerceAtLeast(0f);commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "توسيط أفقي" else "Center X") }
                    OutlinedButton(onClick={ if(editingElement!=null){editingElement.y=((1f-editingElement.height)/2f).coerceAtLeast(0f);commitChange()} }, enabled=editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "توسيط رأسي" else "Center Y") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick={
                        val targets=page.elements.filter{it.id in selectedElementIds}
                        if(targets.size>=2){val gid=UUID.randomUUID().toString();targets.forEach{it.groupId=gid};commitChange()}
                        else if(editingElement!=null){val gid=editingElement.groupId;if(gid.isBlank())editingElement.groupId=UUID.randomUUID().toString() else editingElement.groupId="";commitChange()}
                    }, enabled=selectedElementIds.size>=2 || editingElement!=null, modifier=Modifier.weight(1f)) { Text(if(ar) "تجميع المحدد" else "Group selected") }
                    OutlinedButton(onClick={
                        val targets=page.elements.filter{it.id in selectedElementIds};val groups=targets.map{it.groupId}.filter{it.isNotBlank()}.toSet()
                        if(groups.isNotEmpty()){page.elements.filter{it.groupId in groups}.forEach{it.groupId=""};commitChange()}
                    }, enabled=page.elements.any{it.id in selectedElementIds && it.groupId.isNotBlank()}, modifier=Modifier.weight(1f)) { Text(if(ar) "فك التجميع" else "Ungroup") }
                }
                if (page.elements.isNotEmpty()) {
                    Text(if(ar) "اختر عنصرًا لتعديل نصه" else "Select an element to edit its text", fontSize=11.sp, color=Color.Gray)
                    page.elements.forEach { element ->
                        Row(Modifier.fillMaxWidth().clickable { editingElementId=element.id }.background(if(editingElementId==element.id) Color(0xFFE7F1EB) else Color.Transparent).padding(5.dp), verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(checked=element.id in selectedElementIds, onCheckedChange={ checked -> selectedElementIds=if(checked) selectedElementIds+element.id else selectedElementIds-element.id })
                            Text(when(element.type){"text"->if(ar)"نص" else "Text";"rectangle"->if(ar)"مستطيل" else "Rectangle";"circle"->if(ar)"دائرة" else "Circle";else->if(ar)"خط" else "Line"}, modifier=Modifier.weight(1f), fontSize=12.sp)
                            Text((if(element.locked) "🔒 " else "") + (if(element.visible) "● " else "○ ") + if(element.type=="text") element.text else "•", maxLines=1, fontSize=11.sp)
                        }
                    }
                }
                if (editingElement != null) {
                    if (editingElement.type == "text") {
                        OutlinedTextField(value=editingElement.text, onValueChange={ editingElement.text=it; commitChange() }, enabled=!editingElement.locked, label={Text(if(ar) "محتوى النص" else "Text content")}, modifier=Modifier.fillMaxWidth())
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(if(ar) "حجم الخط" else "Font size", fontSize=12.sp)
                            Slider(value=editingElement.fontSize, onValueChange={editingElement.fontSize=it}, onValueChangeFinished={commitChange()}, valueRange=10f..48f, modifier=Modifier.weight(1f))
                            Text("${editingElement.fontSize.toInt()}", fontSize=11.sp)
                        }
                    }
                    Text(if(ar) "لون العنصر" else "Element color", fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        listOf(0xFF176044,0xFF172820,0xFF2563EB,0xFFDC2626,0xFFF59E0B,0xFF9333EA,0xFFFFFFFF).forEach { c ->
                            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(c)).border(1.dp,Color.LightGray,CircleShape).clickable { editingElement.color=c; commitChange() })
                        }
                    }
                    Text(if(ar) "الموضع والحجم" else "Position and size", fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("X", fontSize=11.sp); Slider(value=editingElement.x.coerceIn(0f,0.95f), onValueChange={editingElement.x=it}, onValueChangeFinished={commitChange()}, valueRange=0f..0.95f, modifier=Modifier.weight(1f))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("Y", fontSize=11.sp); Slider(value=editingElement.y.coerceIn(0f,0.95f), onValueChange={editingElement.y=it}, onValueChangeFinished={commitChange()}, valueRange=0f..0.95f, modifier=Modifier.weight(1f))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(if(ar) "العرض" else "Width", fontSize=11.sp); Slider(value=editingElement.width.coerceIn(0.03f,1f), onValueChange={editingElement.width=it}, onValueChangeFinished={commitChange()}, valueRange=0.03f..1f, modifier=Modifier.weight(1f))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(if(ar) "الارتفاع" else "Height", fontSize=11.sp); Slider(value=editingElement.height.coerceIn(0.01f,1f), onValueChange={editingElement.height=it}, onValueChangeFinished={commitChange()}, valueRange=0.01f..1f, modifier=Modifier.weight(1f))
                    }
                }
                OutlinedTextField(page.title,{page.title=it;commitChange()},label={Text(if(ar) "اسم / وصف الصفحة" else "Page title / description")},modifier=Modifier.fillMaxWidth())
                Text(
                    if(ar) {
                        if(page.imagePath.isNotBlank()) "أبعاد الصفحة مأخوذة تلقائيًا من الصورة المضافة، مع الحفاظ على تناسبها. لتغييرها اختر ملفًا آخر."
                        else "لم تتم إضافة صورة لهذه الصفحة بعد. أضف صورة وسيتم تحديد أبعاد الصفحة تلقائيًا من أبعادها."
                    } else {
                        if(page.imagePath.isNotBlank()) "Page dimensions were detected automatically from the selected image. Choose another file to change them."
                        else "No image has been added to this page. Add an image and its dimensions will be detected automatically."
                    },
                    fontSize=11.sp, color=Color.Gray
                )
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=page.type=="cover",onClick={page.type="cover";commitChange()},label={Text(if(ar) "الغلاف الأمامي" else "Front cover")});FilterChip(selected=page.type=="back",onClick={page.type="back";commitChange()},label={Text(if(ar) "الغلاف الخلفي" else "Back cover")});FilterChip(selected=page.type=="content",onClick={page.type="content";commitChange()},label={Text(if(ar) "داخلية" else "Content")})}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=page.fit=="contain",onClick={page.fit="contain";commitChange()},label={Text(if(ar) "ملاءمة الصورة" else "Fit image")});FilterChip(selected=page.fit=="cover",onClick={page.fit="cover";commitChange()},label={Text(if(ar) "ملء الصفحة" else "Fill page")})}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedButton(onClick={page.rotation=(page.rotation+90)%360;commitChange()}){Text(if(ar) "تدوير 90°" else "Rotate 90°")};OutlinedButton(onClick={page.imagePath="";commitChange()}){Text(if(ar) "إزالة الصورة" else "Remove image")};OutlinedButton(onClick=onUpload){Text(if(ar) "رفع صورة" else "Upload")}}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedButton(onClick={onMove(-1);commitChange()},enabled=selected>0){Text(if(ar) "تحريك لأعلى ↑" else "Move up ↑")};OutlinedButton(onClick={onMove(1);commitChange()},enabled=selected<book.pages.lastIndex){Text(if(ar) "تحريك لأسفل ↓" else "Move down ↓")};OutlinedButton(onClick=onDuplicate){Text(if(ar) "نسخ" else "Duplicate")}}
                Button(onClick={onDelete();commitChange()},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFC84450))){Text(if(ar) "حذف الصفحة" else "Delete page")}
                Spacer(Modifier.height(10.dp));Text(if(ar) "لون خلفية الصفحة" else "Page background",fontWeight=FontWeight.SemiBold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(0xFFFFFFFF,0xFFFFFDF7,0xFFF2F5F3,0xFFEAF0F8,0xFFFFF0E6).forEach{c->Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c)).border(1.dp,Color.LightGray,CircleShape).clickable{page.bg=c;commitChange()})}}
                Spacer(Modifier.height(10.dp));Text(if(ar) "اتجاه الكتاب" else "Book orientation");Row{FilterChip(selected=book.orientation=="portrait",onClick={book.orientation="portrait";commitChange()},label={Text(if(ar) "طولي" else "Portrait")});FilterChip(selected=book.orientation=="landscape",onClick={book.orientation="landscape";commitChange()},label={Text(if(ar) "عرضي" else "Landscape")})}
            }
            else -> { Text(if(ar) "إدارة المشروع" else "Project management",fontWeight=FontWeight.Bold);Button(onClick=onExport){Icon(Icons.Default.Share,null);Text(if(ar) "تصدير المشروع" else "Export project")};Text(if(ar) "يمكنك فتح ملف مشروع مكتبتي بصيغة JSON من تطبيق الملفات." else "You can import a Maktabati JSON project using the system document picker.") }
        }
        Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(if(ar) "معاينة الصفحة الحالية" else "Current page preview",fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));TextButton(onClick={previewZoom=(previewZoom-0.1f).coerceAtLeast(0.5f)}){Text("−")};Text("${(previewZoom*100).toInt()}%",fontSize=11.sp);TextButton(onClick={previewZoom=(previewZoom+0.1f).coerceAtMost(2f)}){Text("+")};TextButton(onClick={previewZoom=1f}){Text(if(ar) "إعادة" else "Reset")}}
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp).background(Color(0xFFE6EEE8),RoundedCornerShape(15.dp)).padding(12.dp),contentAlignment=Alignment.Center){
            val aspect=pageAspectRatio(page,book)
            PageDisplay(
                page,
                Modifier.fillMaxHeight().widthIn(max=420.dp).aspectRatio(aspect).graphicsLayer(scaleX=previewZoom,scaleY=previewZoom),
                onElementMoveEnd = { id, x, y ->
                    val moved = page.elements.firstOrNull { it.id == id }
                    if(moved != null) {
                        val dx=x-moved.x; val dy=y-moved.y; val gid=moved.groupId
                        if(gid.isNotBlank()) page.elements.filter{it.groupId==gid}.forEach{it.x=(it.x+dx).coerceIn(0f,(1f-it.width).coerceAtLeast(0f));it.y=(it.y+dy).coerceIn(0f,(1f-it.height).coerceAtLeast(0f))}
                        else { moved.x=x; moved.y=y }
                    }
                    commitChange()
                },
                selectedElementId = editingElementId,
                onElementTap = { id -> editingElementId=id; selectedElementIds=selectedElementIds+id }
            )
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick={if(selected>0){onSelect(selected-1);pageJumpInput=selected.toString()}},enabled=selected>0){Text(if(ar) "السابق" else "Previous")}
            OutlinedTextField(value=pageJumpInput,onValueChange={pageJumpInput=it.filter { ch->ch.isDigit() }.take(3)},label={Text(if(ar) "رقم الصفحة" else "Page")},singleLine=true,modifier=Modifier.weight(1f))
            TextButton(onClick={val target=pageJumpInput.toIntOrNull()?.minus(1);if(target!=null && target in book.pages.indices)onSelect(target) else pageJumpInput=(selected+1).toString()}){Text(if(ar) "انتقال" else "Go")}
            TextButton(onClick={if(selected<book.pages.lastIndex){onSelect(selected+1);pageJumpInput=(selected+2).toString()}},enabled=selected<book.pages.lastIndex){Text(if(ar) "التالي" else "Next")}
        }
    }
    if(showPageCountConfirm) AlertDialog(onDismissRequest={showPageCountConfirm=false;pageCountInput=book.pages.size.toString()},title={Text(if(ar) "تقليل عدد الصفحات؟" else "Reduce page count?")},text={Text(if(ar) "سيتم حذف آخر ${book.pages.size-pendingPageCount} صفحة فقط. لن تتغير الصفحات المتبقية. هل تريد المتابعة؟" else "Only the last ${book.pages.size-pendingPageCount} pages will be removed. Remaining pages will not change. Continue?")},confirmButton={TextButton(onClick={
        while(book.pages.size>pendingPageCount) book.pages.removeAt(book.pages.lastIndex)
        onSelect(selected.coerceAtMost(book.pages.lastIndex));pageCountInput=pendingPageCount.toString();showPageCountConfirm=false;commitChange()
    }){Text(if(ar) "حذف الصفحات الأخيرة" else "Remove last pages")}},dismissButton={TextButton(onClick={showPageCountConfirm=false;pageCountInput=book.pages.size.toString()}){Text(if(ar) "إلغاء" else "Cancel")}})
}

private object PageBitmapCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    @Synchronized fun get(path: String): Bitmap? = cache.get(path)
    @Synchronized fun put(path: String, bitmap: Bitmap) { cache.put(path, bitmap) }
}

private fun decodePageBitmap(path: String, maxDimension: Int): Bitmap? {
    if (path.isBlank()) return null
    PageBitmapCache.get(path)?.let { cached ->
        if (maxOf(cached.width, cached.height) <= maxDimension) return cached
    }
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxDimension && bounds.outHeight / (sample * 2) >= maxDimension) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeFile(path, options)?.also { PageBitmapCache.put(path, it) }
    } catch (_: OutOfMemoryError) { null } catch (_: Exception) { null }
}

@Composable private fun PageThumbnail(page: BookPage, modifier: Modifier=Modifier){PageDisplay(page,modifier.background(Color.White),320)}
@Composable private fun PageDisplay(
    page: BookPage,
    modifier: Modifier=Modifier,
    maxBitmapDimension: Int=1600,
    onElementMoveEnd: ((String, Float, Float) -> Unit)? = null,
    selectedElementId: String = "",
    onElementTap: ((String) -> Unit)? = null
){
    val density = LocalDensity.current
    val bmp by produceState<Bitmap?>(initialValue=null, page.imagePath, maxBitmapDimension) {
        value = if (page.imagePath.isNotBlank()) withContext(Dispatchers.IO) { decodePageBitmap(page.imagePath, maxBitmapDimension) } else null
    }
    BoxWithConstraints(modifier.background(Color(page.bg))) {
        if(bmp!=null) Image(bmp!!.asImageBitmap(),null,Modifier.fillMaxSize().graphicsLayer(rotationZ=page.rotation.toFloat()),contentScale=if(page.fit=="cover") androidx.compose.ui.layout.ContentScale.Crop else androidx.compose.ui.layout.ContentScale.Fit)
        else Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { Text(page.title.ifBlank{"▧"},color=Color.Gray,textAlign=TextAlign.Center) }
        page.elements.filter { it.visible }.forEach { element ->
            var dragOffset by remember(page.id, element.id) { mutableStateOf(Offset.Zero) }
            val elementModifier = Modifier
                .offset(x=maxWidth*element.x + with(density) { dragOffset.x.toDp() }, y=maxHeight*element.y + with(density) { dragOffset.y.toDp() })
                .width(maxWidth*element.width).height(maxHeight*element.height)
                .then(if(element.id==selectedElementId) Modifier.border(1.dp, Color(0xFF2563EB)) else Modifier)
                .then(if(onElementTap!=null) Modifier.clickable { onElementTap.invoke(element.id) } else Modifier)
                .then(if(onElementMoveEnd != null && !element.locked) Modifier.pointerInput(page.id, element.id, maxWidth, maxHeight) {
                    detectDragGestures(
                        onDragEnd = {
                            val pageWidthPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
                            val pageHeightPx = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)
                            val nextX = (element.x + dragOffset.x / pageWidthPx).coerceIn(0f, (1f-element.width).coerceAtLeast(0f))
                            val nextY = (element.y + dragOffset.y / pageHeightPx).coerceIn(0f, (1f-element.height).coerceAtLeast(0f))
                            dragOffset = Offset.Zero
                            onElementMoveEnd.invoke(element.id, nextX, nextY)
                        }
                    ) { change, amount -> change.consume(); dragOffset += amount }
                } else Modifier)
            when(element.type) {
                "text" -> Box(elementModifier, contentAlignment=Alignment.CenterStart) { Text(element.text, color=Color(element.color), fontSize=element.fontSize.sp, lineHeight=(element.fontSize*1.2f).sp) }
                "rectangle" -> Box(elementModifier.border(2.dp, Color(element.color)))
                "circle" -> Box(elementModifier.border(2.dp, Color(element.color), CircleShape))
                "line" -> Box(elementModifier.height(2.dp).background(Color(element.color)))
            }
        }
    }
}

@Composable private fun ReaderScreen(book: Book, index: Int, ar: Boolean, onIndex:(Int)->Unit, onPdf:()->Unit){
    val page = book.pages.getOrNull(index)
    var drag by remember(index) { mutableFloatStateOf(0f) }
    var nightMode by remember { mutableStateOf(false) }
    var immersive by remember { mutableStateOf(false) }
    var controlsVisible by remember { mutableStateOf(true) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var jumpValue by remember(index) { mutableStateOf((index + 1).toString()) }
    val view = androidx.compose.ui.platform.LocalView.current

    // Immersive reader mode hides Android system bars and restores them on exit.
    SideEffect {
        view.systemUiVisibility = if (immersive) {
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    DisposableEffect(view) {
        onDispose { view.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE }
    }

    val total = book.pages.size.coerceAtLeast(1)
    val progress = (index + 1).toFloat() / total.toFloat()
    val foreground = if (nightMode) Color(0xFFE8E8E8) else MaterialTheme.colorScheme.onSurface
    val readerBackground = if (nightMode) Color(0xFF101214) else MaterialTheme.colorScheme.surface
    val stageBackground = if (nightMode) Color(0xFF050607) else Color(0xFF0D2118)

    Column(Modifier.fillMaxSize().background(readerBackground).padding(if (immersive) 4.dp else 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (!immersive || controlsVisible) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(book.title, fontWeight = FontWeight.Bold, color = foreground, modifier = Modifier.weight(1f), maxLines = 1)
                TextButton(onClick = { nightMode = !nightMode }) { Text(if (nightMode) (if (ar) "وضع النهار" else "Day") else (if (ar) "الوضع الليلي" else "Night")) }
                TextButton(onClick = { immersive = !immersive }) { Text(if (immersive) (if (ar) "إنهاء ملء الشاشة" else "Exit full screen") else (if (ar) "ملء الشاشة" else "Full screen")) }
                TextButton(onClick = onPdf) { Text("PDF") }
            }
            Text(if (ar) "الصفحة ${index + 1} من ${book.pages.size}" else "Page ${index + 1} of ${book.pages.size}", color = foreground, fontSize = 13.sp)
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), color = if (nightMode) Color(0xFF9BC8AD) else MaterialTheme.colorScheme.primary)
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)
                .background(stageBackground, RoundedCornerShape(12.dp)).padding(8.dp)
                .pointerInput(index, immersive) {
                    detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                        if (drag < -40f && index < book.pages.lastIndex) onIndex(index + 1)
                        else if (drag > 40f && index > 0) onIndex(index - 1)
                        drag = 0f
                    })
                },
            contentAlignment = Alignment.Center
        ) {
            PageDisplay(page ?: BookPage(), Modifier.fillMaxHeight().fillMaxWidth(.96f).aspectRatio(page?.let { pageAspectRatio(it, book) } ?: defaultPageAspectRatio(book)))
            if (immersive && !controlsVisible) {
                TextButton(onClick = { controlsVisible = true }, modifier = Modifier.align(Alignment.BottomCenter)) {
                    Text(if (ar) "إظهار أدوات القراءة" else "Show reader controls", color = Color.White)
                }
            }
        }

        if (!immersive || controlsVisible) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { if (index > 0) onIndex(index - 1) }, enabled = index > 0, modifier = Modifier.weight(1f)) {
                    Text(if (ar) "السابقة" else "Previous")
                }
                OutlinedButton(onClick = { jumpValue = (index + 1).toString(); showJumpDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(if (ar) "انتقال" else "Go to page")
                }
                Button(onClick = { if (index < book.pages.lastIndex) onIndex(index + 1) }, enabled = index < book.pages.lastIndex, modifier = Modifier.weight(1f)) {
                    Text(if (ar) "التالية" else "Next")
                }
            }
            if (total > 1) {
                Slider(
                    value = (index + 1).toFloat(),
                    onValueChange = { value -> onIndex(value.toInt().coerceIn(1, total) - 1) },
                    valueRange = 1f..total.toFloat(),
                    steps = (total - 2).coerceAtLeast(0),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (ar) "البداية" else "Start", color = foreground, fontSize = 11.sp)
                Text("${(progress * 100).toInt()}%", color = foreground, fontSize = 11.sp)
                Text(if (ar) "النهاية" else "End", color = foreground, fontSize = 11.sp)
            }
        }
    }

    if (showJumpDialog) {
        AlertDialog(
            onDismissRequest = { showJumpDialog = false },
            title = { Text(if (ar) "الانتقال إلى صفحة" else "Go to page") },
            text = {
                OutlinedTextField(
                    value = jumpValue,
                    onValueChange = { jumpValue = it.filter(Char::isDigit).take(5) },
                    label = { Text(if (ar) "رقم الصفحة (1-${book.pages.size})" else "Page number (1-${book.pages.size})") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val target = jumpValue.toIntOrNull()
                    if (target != null && target in 1..book.pages.size) { onIndex(target - 1); showJumpDialog = false }
                }) { Text(if (ar) "انتقال" else "Go") }
            },
            dismissButton = { TextButton(onClick = { showJumpDialog = false }) { Text(if (ar) "إلغاء" else "Cancel") } }
        )
    }
}

/**
 * Derives a page size from an image file without asking the user to classify it as A4/A5.
 * Image files generally expose pixel dimensions rather than a reliable physical paper size,
 * so we preserve the exact aspect ratio and normalize the longest edge to at most 297 mm.
 */
private fun imagePageDimensionsMm(path: String): Pair<Float, Float> {
    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, options)
    val pixelWidth = options.outWidth
    val pixelHeight = options.outHeight
    if (pixelWidth <= 0 || pixelHeight <= 0) return 148f to 210f
    val scale = 297f / maxOf(pixelWidth, pixelHeight).toFloat()
    val width = (pixelWidth * scale).coerceAtLeast(10f)
    val height = (pixelHeight * scale).coerceAtLeast(10f)
    return width to height
}

private fun defaultPageDimensionsMm(book:Book):Pair<Float,Float>{
    val base=when(book.size.lowercase()){"a4"->210f to 297f;"a6"->105f to 148f;else->148f to 210f}
    return if(book.orientation=="landscape") base.second to base.first else base
}
private fun pageDimensionsMm(page:BookPage,book:Book):Pair<Float,Float>{
    return if(page.widthMm in 10f..1000f && page.heightMm in 10f..1000f) page.widthMm to page.heightMm else defaultPageDimensionsMm(book)
}
private fun defaultPageAspectRatio(book:Book):Float{val d=defaultPageDimensionsMm(book);return d.first/d.second}
private fun pageAspectRatio(page:BookPage,book:Book):Float{val d=pageDimensionsMm(page,book);return (d.first/d.second).coerceIn(0.2f,5f)}

private fun statusName(s:String,ar:Boolean)=if(ar) when(s){"later"->"للقراءة لاحقًا";"completed"->"تمت القراءة";"reading"->"ما زلت أقرأ";else->"باقي الكتب"} else when(s){"later"->"Read later";"completed"->"Completed";"reading"->"Currently reading";else->"Other books"}
private fun safeName(s:String)=(s.ifBlank{"book"}.replace(Regex("[\\\\/:*?\"<>|]"),"_").take(60))
private fun copyUri(context:android.content.Context,uri:Uri,dir:File):String?=try{dir.mkdirs();val f=File(dir,"img_${UUID.randomUUID()}.bin");context.contentResolver.openInputStream(uri)?.use{input->f.outputStream().use{input.copyTo(it)}};f.absolutePath}catch(_:Exception){null}
private fun loadTrash(file: File): List<TrashEntry> = try {
    if (!file.exists()) emptyList() else {
        val array = JSONArray(file.readText())
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val book = item.optJSONObject("book") ?: return@mapNotNull null
            TrashEntry(objToBook(book), item.optLong("deletedAt", System.currentTimeMillis()))
        }
    }
} catch (_: Exception) { emptyList() }

private fun saveTrash(file: File, entries: List<TrashEntry>) {
    file.parentFile?.mkdirs()
    val array = JSONArray()
    entries.forEach { entry -> array.put(JSONObject().put("deletedAt", entry.deletedAt).put("book", bookToJson(entry.book, false))) }
    val temp = File(file.parentFile, file.name + ".tmp")
    temp.writeText(array.toString(), Charsets.UTF_8)
    if (file.exists() && !file.delete()) throw java.io.IOException("Cannot replace trash")
    if (!temp.renameTo(file)) { temp.copyTo(file, overwrite = true); temp.delete() }
}

private fun exportLibraryBackup(context: android.content.Context, uri: Uri, books: List<Book>) {
    val root = JSONObject().put("format", "maktabati-backup").put("version", 1).put("createdAt", System.currentTimeMillis())
    val array = JSONArray()
    books.forEach { array.put(bookToJson(it, true)) }
    root.put("books", array)
    context.contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray(Charsets.UTF_8)) } ?: error("Cannot open backup destination")
}

private fun importLibraryBackup(context: android.content.Context, uri: Uri, dir: File): List<Book> {
    val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Empty backup")
    val root = JSONObject(raw)
    if (root.optString("format") != "maktabati-backup") error("Unsupported backup format")
    val array = root.optJSONArray("books") ?: error("Backup has no books")
    val imported = mutableListOf<Book>()
    for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        obj.put("id", UUID.randomUUID().toString())
        val pages = obj.optJSONArray("pages") ?: JSONArray()
        for (j in 0 until pages.length()) {
            val page = pages.getJSONObject(j)
            val encoded = page.optString("imageBase64")
            if (encoded.isNotBlank()) {
                val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                val image = File(dir, "img_${UUID.randomUUID()}.bin")
                image.writeBytes(bytes)
                page.put("imagePath", image.absolutePath)
            }
            page.remove("imageBase64")
        }
        imported.add(objToBook(obj).also { it.updated = System.currentTimeMillis() })
    }
    return imported
}

private fun loadBooks(file:File,dir:File):List<Book>{
    if(!file.exists()){val backup=File(file.parentFile,"${file.name}.bak");if(!backup.exists())return emptyList();return try{val a=JSONArray(backup.readText());(0 until a.length()).map{objToBook(a.getJSONObject(it))}}catch(_:Exception){emptyList()}}
    return try{val arr=JSONArray(file.readText());(0 until arr.length()).map{objToBook(arr.getJSONObject(it))}.toMutableList()}catch(_:Exception){
        val backup=File(file.parentFile,"${file.name}.bak")
        try{val arr=JSONArray(backup.readText());(0 until arr.length()).map{objToBook(arr.getJSONObject(it))}.toMutableList()}catch(_:Exception){emptyList()}
    }
}
private fun persistBooks(file:File,books:List<Book>){
    synchronized(file.absolutePath.intern()) {
        file.parentFile?.mkdirs()
        val arr=JSONArray();books.forEach{arr.put(bookToJson(it,false))}
        val temp=File(file.parentFile,"${file.name}.tmp")
        val backup=File(file.parentFile,"${file.name}.bak")
        java.io.FileOutputStream(temp).use{stream->stream.write(arr.toString().toByteArray(Charsets.UTF_8));stream.fd.sync()}
        if(file.exists()) { val backupTemp=File(file.parentFile,"${file.name}.bak.tmp");file.copyTo(backupTemp,overwrite=true);if(backup.exists())backup.delete();if(!backupTemp.renameTo(backup))backupTemp.copyTo(backup,overwrite=true) }
        if(file.exists() && !file.delete()) throw java.io.IOException("Could not replace library file")
        if(!temp.renameTo(file)) { temp.copyTo(file,overwrite=true);temp.delete() }
    }
}
private fun bookToJson(b:Book,embed:Boolean):JSONObject=JSONObject().apply{
    put("id",b.id);put("title",b.title);put("author",b.author);put("language",b.language);put("description",b.description);put("size",b.size);put("orientation",b.orientation);put("readingStatus",b.readingStatus);put("isFavorite",b.isFavorite);put("created",b.created);put("updated",b.updated);put("lastReadIndex",b.lastReadIndex);put("categoryIds",JSONArray(b.categoryIds));put("tags",JSONArray(b.tags));put("isPinned",b.isPinned)
    val a=JSONArray();b.pages.forEach{p->a.put(JSONObject().apply{put("id",p.id);put("type",p.type);put("title",p.title);put("fit",p.fit);put("rotation",p.rotation);put("bg",p.bg);put("widthMm",p.widthMm);put("heightMm",p.heightMm);put("elements", JSONArray().apply { p.elements.forEach { e -> put(JSONObject().apply { put("id",e.id);put("type",e.type);put("text",e.text);put("x",e.x);put("y",e.y);put("width",e.width);put("height",e.height);put("color",e.color);put("fontSize",e.fontSize);put("locked",e.locked);put("visible",e.visible);put("groupId",e.groupId) }) } });if(embed&&p.imagePath.isNotBlank()){val f=File(p.imagePath);if(f.exists())put("imageBase64",android.util.Base64.encodeToString(f.readBytes(),android.util.Base64.NO_WRAP))}else put("imagePath",p.imagePath)})};put("pages",a)
}
private fun objToBook(o:JSONObject):Book{val pages=mutableListOf<BookPage>();val a=o.optJSONArray("pages")?:JSONArray();for(i in 0 until a.length()){val p=a.getJSONObject(i);val elements=mutableListOf<PageElement>();val ea=p.optJSONArray("elements")?:JSONArray();for(j in 0 until ea.length()){val e=ea.getJSONObject(j);elements.add(PageElement(e.optString("id",UUID.randomUUID().toString()),e.optString("type","text"),e.optString("text"),e.optDouble("x",0.12).toFloat(),e.optDouble("y",0.12).toFloat(),e.optDouble("width",0.55).toFloat(),e.optDouble("height",0.12).toFloat(),e.optLong("color",0xFF176044),e.optDouble("fontSize",22.0).toFloat(),e.optBoolean("locked",false),e.optBoolean("visible",true),e.optString("groupId","")))};pages.add(BookPage(p.optString("id",UUID.randomUUID().toString()),p.optString("type","content"),p.optString("title"),p.optString("imagePath"),p.optString("fit","contain"),p.optInt("rotation"),p.optLong("bg",0xFFFFFFFF),p.optDouble("widthMm",0.0).toFloat(),p.optDouble("heightMm",0.0).toFloat(),elements))};val cats=o.optJSONArray("categoryIds")?:JSONArray();val tags=o.optJSONArray("tags")?:JSONArray();return Book(o.optString("id",UUID.randomUUID().toString()),o.optString("title","Untitled"),o.optString("author"),o.optString("language","العربية"),o.optString("description"),o.optString("size","a5"),o.optString("orientation","portrait"),pages,o.optString("readingStatus","other"),o.optBoolean("isFavorite"),o.optLong("created"),o.optLong("updated"),o.optInt("lastReadIndex"),MutableList(cats.length()){i->cats.getString(i)},MutableList(tags.length()){i->tags.getString(i)},o.optBoolean("isPinned"))}
private fun exportBook(context:android.content.Context,uri:Uri,b:Book){val json=bookToJson(b,true);context.contentResolver.openOutputStream(uri)?.use{it.write(json.toString().toByteArray())}?:error("Cannot open destination")}
private fun importBook(context:android.content.Context,uri:Uri,dir:File):Book{val raw=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:error("Empty");val o=JSONObject(raw);val id=UUID.randomUUID().toString();val pages=o.getJSONArray("pages");for(i in 0 until pages.length()){val p=pages.getJSONObject(i);val base=p.optString("imageBase64");if(base.isNotBlank()){val f=File(dir,"img_${UUID.randomUUID()}.bin");f.writeBytes(android.util.Base64.decode(base,android.util.Base64.DEFAULT));p.put("imagePath",f.absolutePath)};p.remove("imageBase64")};o.put("id",id);return objToBook(o).also{it.updated=System.currentTimeMillis()}}
private fun writePdf(context:android.content.Context,uri:Uri,b:Book){
    val pdf=PdfDocument()
    b.pages.forEachIndexed{i,p->
        val dims=pageDimensionsMm(p,b)
        val w=(dims.first*72f/25.4f).toInt().coerceIn(72,4000)
        val h=(dims.second*72f/25.4f).toInt().coerceIn(72,4000)
        val info=PdfDocument.PageInfo.Builder(w,h,i+1).create();val page=pdf.startPage(info);val c=page.canvas;c.drawColor(p.bg.toInt());val bmp=if(p.imagePath.isNotBlank())decodePageBitmap(p.imagePath,maxOf(w,h)*2) else null
        if(bmp!=null){val source=RectF(0f,0f,bmp.width.toFloat(),bmp.height.toFloat());val target=RectF(20f,20f,(w-20).toFloat(),(h-20).toFloat());val ratio=if(p.fit=="cover")maxOf(target.width()/source.width(),target.height()/source.height()) else minOf(target.width()/source.width(),target.height()/source.height());val dw=source.width()*ratio;val dh=source.height()*ratio;val dst=RectF((w-dw)/2,(h-dh)/2,(w+dw)/2,(h+dh)/2);c.save();c.rotate(p.rotation.toFloat(),w/2f,h/2f);c.drawBitmap(bmp,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG));c.restore()}
        else{val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.DKGRAY;textSize=24f;textAlign=Paint.Align.CENTER};c.drawText(p.title.ifBlank{" "},w/2f,h/2f,paint)}
        p.elements.filter { it.visible }.forEach { e ->
            val left=e.x*w; val top=e.y*h; val right=(e.x+e.width)*w; val bottom=(e.y+e.height)*h
            val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=e.color.toInt();style=Paint.Style.STROKE;strokeWidth=3f}
            when(e.type){
                "text"->{paint.style=Paint.Style.FILL;paint.textSize=e.fontSize*2f;c.drawText(e.text,left,top+e.fontSize*2f,paint)}
                "rectangle"->c.drawRect(left,top,right,bottom,paint)
                "circle"->c.drawOval(left,top,right,bottom,paint)
                "line"->c.drawLine(left,top,right,bottom,paint)
            }
        }
        pdf.finishPage(page)}
    context.contentResolver.openOutputStream(uri)?.use{pdf.writeTo(it)} ?: error("Cannot write PDF");pdf.close()
}
