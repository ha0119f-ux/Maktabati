# Maktabati – Phase 1 search enhancement

## Search improvements
- Added three explicit search scopes: book title, author name, and description/general idea.
- Description search also checks the book's tags.
- Multi-word searches match when every entered word is present, even if the words are not adjacent.
- Arabic search normalization ignores common diacritics and normalizes common alef/hamza and ya variants.
- Search UI labels and guidance are localized for Arabic, English, and French.

## Compatibility
- Existing Book fields are used; no database/schema migration is required.
- Existing saved books and page images are not rewritten by this change.
- applicationId remains `com.maktabati.app`.
- versionCode remains `2` and versionName remains `1.1.0`, as requested.

## Verification status
- Source-level changes reviewed.
- Gradle build could not be run in this environment because the Gradle 8.9 distribution is not cached and `services.gradle.org` is unreachable. Run the repository GitHub Actions workflow to perform the real Android build.

## Additional quality and reliability pass
- Strengthened Arabic search normalization by removing tatweel and zero-width formatting characters, normalizing alef-wasla, and treating common punctuation as word separators.
- Hardened library and trash JSON writes: data is written and synced to a temporary file first, the previous valid file is retained as a backup, and failed replacement attempts try to restore the backup.
- Added trash recovery from its backup file if the primary trash JSON is unreadable.
- Prevented a reader launch crash for imported or legacy books that contain zero pages.
- Corrected the displayed saved reading page to use human-facing one-based page numbering.
- Added the previously missing temporary-cache cleanup control in Storage & Backup; it targets app cache directories only and does not touch the library's book/page-image storage.
- Moved storage-size directory traversal off the UI thread to avoid blocking the screen when the library is large.
- Completed French translations for the dynamic reader and page-count strings reviewed in this pass.

## Verification update
- ZIP integrity and Android compilation still need separate verification. A local Gradle build was attempted, but Gradle 8.9 could not be downloaded because this environment cannot resolve `services.gradle.org`; no APK build is claimed.
- Improved crash recovery: when the main library JSON is corrupt or missing, a valid backup is now restored to the primary file before future saves can rotate it.
- Made move-to-trash and restore write ordering safer across the library/trash files: the recoverable copy is written first so interruption can at worst leave a duplicate rather than silently losing a book.
- Added an explicit confirmation dialog for deleting an individual book from the library, matching the existing bulk-delete confirmation.
- Book cover thumbnails now decode off the UI thread and use the bounded bitmap cache instead of decoding full-resolution cover images synchronously while scrolling.


## Backup and export reliability pass
- Library backup restore now validates the backup format version and rejects empty or unsupported backups before publishing any changes.
- Restored embedded page images are written with file-descriptor sync and verified; if parsing/import fails, images created during that import are cleaned up.
- Backup restore now commits the merged library to disk before updating the visible in-memory library, avoiding a UI state that claims restoration succeeded when persistence failed.
- Backup export uses a deep snapshot so edits made while serialization runs cannot produce a mixed-state backup.
- Project and library exports now fail visibly when a referenced page image is missing instead of silently creating an incomplete backup.
- PDF export closes its PdfDocument in a finally block even when rendering or writing fails.

## Verification status (this pass)
- Source changes reviewed and ZIP archive integrity will be checked after packaging.
- A full Android compile and device-level regression test remain unavailable in this environment; do not treat source review as a successful APK build.

## Project import/export hardening pass
- Single-book project export now serializes a detached snapshot, so edits made during background export cannot produce a mixed-state project file.
- Export writes through a file descriptor, flushes, and syncs before reporting completion.
- Single-book import now validates the document and page array, limits unreasonable input sizes/page counts, and rejects malformed pages before publishing a book.
- Embedded images are decoded and synced to disk before the imported book is returned; any images created by a failed import are removed.
- Imported book/page/element IDs are regenerated to prevent collisions with existing local objects.
- Imported reading position and bookmarks are clamped to the imported book's actual page range.
- Project import now persists the merged library before updating visible in-memory state, matching the safer backup-restore flow.

## Verification update (project import/export pass)
- Source-level review and repository structure checks performed.
- XML resource/manifest parsing and ZIP integrity are checked during packaging.
- Full Android compilation and on-device testing remain unverified in this environment; use GitHub Actions for the authoritative build.

## Multi-image import and PDF consistency pass
- Multi-image page import now performs file copying, image dimension inspection, and library persistence on the IO dispatcher rather than writing the JSON library on the UI thread.
- Imported pages are staged in a detached book/library snapshot and are published to Compose state only after persistence succeeds. A failed or empty import removes any copied image files and leaves the visible library unchanged.
- The multi-image import result is bound to the book ID that launched the picker, avoiding attachment to a different book if navigation changes while the picker is open.
- PDF export now receives a detached deep snapshot of the selected book so edits made while rendering cannot change later pages midway through the same PDF.
- Single-project import now removes restored embedded images if the subsequent library JSON commit fails, avoiding orphaned files after a failed import transaction.

## Verification update (multi-image/PDF pass)
- Kotlin source changes were reviewed in context and repository XML/ZIP checks are performed during packaging.
- Android compilation and device-level tests remain unverified because the required Gradle distribution is not available offline in this environment.
