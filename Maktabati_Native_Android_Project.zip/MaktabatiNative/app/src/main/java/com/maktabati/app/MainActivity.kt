package com.maktabati.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

private const val GREEN = 0xFF176044
private data class BookPage(
    val id: String = UUID.randomUUID().toString(), var type: String = "content", var title: String = "",
    var imagePath: String = "", var fit: String = "contain", var rotation: Int = 0, var bg: Long = 0xFFFFFFFF
)
private data class Book(
    val id: String = UUID.randomUUID().toString(), var title: String, var author: String = "", var language: String = "العربية",
    var description: String = "", var size: String = "a5", var orientation: String = "portrait", var pages: MutableList<BookPage>,
    var readingStatus: String = "other", var isFavorite: Boolean = false, var created: Long = System.currentTimeMillis(),
    var updated: Long = System.currentTimeMillis(), var lastReadIndex: Int = 0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaktabatiApp() } }
}

@Composable
private fun MaktabatiApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storage = remember { File(context.filesDir, "maktabati") }
    val prefs = remember { context.getSharedPreferences("maktabati_settings", android.content.Context.MODE_PRIVATE) }
    val dbFile = remember { File(storage, "library.json") }
    var books by remember { mutableStateOf(mutableListOf<Book>()) }
    var screen by remember { mutableStateOf("home") }
    var current by remember { mutableStateOf<Book?>(null) }
    var selectedPage by remember { mutableIntStateOf(0) }
    var readIndex by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf(prefs.getString("language", "ar") ?: "ar") }
    var primary by remember { mutableLongStateOf(prefs.getLong("primary", GREEN)) }
    var filter by remember { mutableStateOf("all") }
    var showCreate by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }
    var authorInput by remember { mutableStateOf("") }
    var bookLanguage by remember { mutableStateOf("العربية") }
    var descriptionInput by remember { mutableStateOf("") }
    var sizeInput by remember { mutableStateOf("a5") }
    var orientationInput by remember { mutableStateOf("portrait") }
    var toast by remember { mutableStateOf("") }
    var pendingImageTarget by remember { mutableStateOf("page") }
    var createCoverPath by remember { mutableStateOf("") }
    val ar = language == "ar"
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) { copyUri(context, uri, storage) }
                val b = current
                if (path != null) {
                    if (pendingImageTarget == "cover" && showCreate) {
                        createCoverPath = path
                    } else if (b != null && selectedPage in b.pages.indices) {
                        b.pages[selectedPage].imagePath = path
                        b.updated = System.currentTimeMillis(); persistBooks(dbFile, books)
                        books = books.toMutableList()
                    }
                }
            }
        }
    }
    val pickManyImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val b = current
        if (b != null && uris.isNotEmpty()) scope.launch {
            val paths = withContext(Dispatchers.IO) { uris.mapNotNull { copyUri(context, it, storage) } }
            paths.forEachIndexed { i, path -> b.pages.add(BookPage(title=uris.getOrNull(i)?.lastPathSegment?.substringAfterLast('/') ?: "", imagePath=path)) }
            b.updated = System.currentTimeMillis(); persistBooks(dbFile, books); books = books.toMutableList()
        }
    }
    val importProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val imported = withContext(Dispatchers.IO) { importBook(context, uri, storage) }
                books = (books + imported).toMutableList(); persistBooks(dbFile, books); toast = if (ar) "تم استيراد المشروع" else "Project imported"
            } catch (_: Exception) { toast = if (ar) "الملف غير صالح" else "Invalid project file" }
        }
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val b = current
        if (uri != null && b != null) scope.launch { try { withContext(Dispatchers.IO) { writePdf(context, uri, b) }; toast = if (ar) "تم حفظ ملف PDF" else "PDF saved" } catch (_: Exception) { toast = if (ar) "تعذر إنشاء PDF" else "Could not create PDF" } }
    }
    val exportProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val b = current
        if (uri != null && b != null) scope.launch {
            try { withContext(Dispatchers.IO) { exportBook(context, uri, b) }; toast = if (ar) "تم تصدير المشروع" else "Project exported" }
            catch (_: Exception) { toast = if (ar) "تعذر التصدير" else "Export failed" }
        }
    }
    LaunchedEffect(Unit) { storage.mkdirs(); books = withContext(Dispatchers.IO) { loadBooks(dbFile, storage) }.toMutableList() }
    fun persist() { scope.launch(Dispatchers.IO) { persistBooks(dbFile, books) } }
    fun goHome() { screen = "home"; current = null }
    fun openDetails(book: Book) { current = book; screen = "details" }
    fun openEditor(book: Book) { current = book; selectedPage = 0; screen = "editor" }
    fun startReader(book: Book, resume: Boolean) { current = book; readIndex = if (resume) book.lastReadIndex.coerceIn(0, book.pages.lastIndex) else 0; screen = "reader" }
    BackHandler(enabled = screen != "home" || showCreate || showSettings) {
        when { showSettings -> showSettings = false; showCreate -> showCreate = false; screen == "reader" -> screen = "details"; screen == "editor" -> { persist(); screen = "details" }; screen == "details" -> goHome(); else -> goHome() }
    }
    val bg = Color(0xFFF1F5F2); val ink = Color(0xFF172820); val muted = Color(0xFF718078); val green = Color(primary)
    MaterialTheme(colorScheme = lightColorScheme(primary = green, onPrimary = Color.White, background = bg, surface = Color.White, onSurface = ink)) {
        Scaffold(containerColor = bg, topBar = {
            Row(Modifier.fillMaxWidth().height(62.dp).background(Color(0xFF14583D)).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                if (screen != "home") IconButton(onClick = { when(screen){"reader"->screen="details";"editor"->{persist();screen="details"};"details"->goHome();else->goHome()} }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                Text("مكتبتي", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(if (ar) " | استوديو إنشاء الكتب" else " | Book Creation Studio", color = Color(0xFFC9E2D1), fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (screen == "home") { IconButton(onClick = { importProject.launch(arrayOf("application/json", "*/*")) }) { Icon(Icons.Default.Book, null, tint = Color.White) }; IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) } }
                else if (screen == "editor") IconButton(onClick = { persist(); toast = if(ar) "تم الحفظ محليًا" else "Saved locally" }) { Icon(Icons.Default.Save, null, tint = Color.White) }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "home" -> HomeScreen(books, filter, ar, green, onFilter={filter=it}, onCreate={
                        titleInput="";authorInput="";descriptionInput="";bookLanguage="العربية";sizeInput="a5";orientationInput="portrait";createCoverPath="";showCreate=true
                    }, onOpen={openDetails(it)}, onFavorite={b->b.isFavorite=!b.isFavorite;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onStatus={b,s->b.readingStatus=s;b.updated=System.currentTimeMillis();persist();books=books.toMutableList()}, onDelete={b->books.removeAll{it.id==b.id};persist();books=books.toMutableList()})
                    "details" -> current?.let { DetailsScreen(it, ar, onEdit={openEditor(it)}, onRead={startReader(it,true)}) }
                    "editor" -> current?.let { b -> EditorScreen(b, selectedPage, ar, green,
                        onSelect={selectedPage=it}, onAdd={b.pages.add(BookPage(title=if(ar) "صفحة جديدة" else "New page"));selectedPage=b.pages.lastIndex;persist();books=books.toMutableList()},
                        onUpload={pendingImageTarget="page";pickImage.launch("image/*")}, onImportImages={pickManyImages.launch("image/*")}, onMove={delta->val from=selectedPage;val to=(from+delta).coerceIn(0,b.pages.lastIndex);if(to!=from){val moved=b.pages.removeAt(from);b.pages.add(to,moved);selectedPage=to;persist();books=books.toMutableList()}}, onAddBack={b.pages.add(BookPage(type="back",title=if(ar) "الغلاف الخلفي" else "Back cover"));selectedPage=b.pages.lastIndex;persist();books=books.toMutableList()}, onDuplicate={val p=b.pages[selectedPage].copy(id=UUID.randomUUID().toString(),title=b.pages[selectedPage].title+if(ar) " - نسخة" else " - Copy");b.pages.add(selectedPage+1,p);selectedPage++;persist();books=books.toMutableList()},
                        onDelete={if(b.pages.size>1){b.pages.removeAt(selectedPage);selectedPage=selectedPage.coerceAtMost(b.pages.lastIndex);persist();books=books.toMutableList()}},
                        onChange={persist();books=books.toMutableList()}, onExport={exportProject.launch("${safeName(b.title)}.kutubi.json")}) }
                    "reader" -> current?.let { b -> ReaderScreen(b, readIndex, ar, onIndex={readIndex=it;b.lastReadIndex=it;b.readingStatus=if(it>=b.pages.lastIndex) "completed" else if(it>0) "reading" else b.readingStatus;persist();books=books.toMutableList()}, onPdf={savePdf.launch("${safeName(b.title)}.pdf")}) }
                }
            }
        }
        if (showCreate) AlertDialog(onDismissRequest={showCreate=false}, title={Text(if(ar) "إعداد كتاب جديد" else "New book settings")}, text={
            Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(titleInput,{titleInput=it},label={Text(if(ar) "عنوان الكتاب *" else "Book title *")},singleLine=true)
                OutlinedTextField(authorInput,{authorInput=it},label={Text(if(ar) "اسم المؤلف" else "Author")},singleLine=true)
                OutlinedTextField(descriptionInput,{descriptionInput=it},label={Text(if(ar) "وصف الكتاب" else "Description")})
                Text(if(ar) "لغة الكتاب" else "Book language",fontWeight=FontWeight.SemiBold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf("العربية","English","Français","أخرى").forEach { FilterChip(selected=bookLanguage==it,onClick={bookLanguage=it},label={Text(it)}) } }
                Text(if(ar) "مقاس الصفحات" else "Page size",fontWeight=FontWeight.SemiBold)
                Row { listOf("a4","a5","a6","custom").forEach { FilterChip(selected=sizeInput==it,onClick={sizeInput=it},label={Text(it.uppercase())}) } }
                Text(if(ar) "اتجاه الصفحات" else "Orientation",fontWeight=FontWeight.SemiBold)
                Row { FilterChip(selected=orientationInput=="portrait",onClick={orientationInput="portrait"},label={Text(if(ar) "طولي" else "Portrait")});FilterChip(selected=orientationInput=="landscape",onClick={orientationInput="landscape"},label={Text(if(ar) "عرضي" else "Landscape")}) }
                OutlinedButton(onClick={pendingImageTarget="cover";pickImage.launch("image/*")}) { Icon(Icons.Default.Image,null); Text(if(ar) "صورة الغلاف (اختياري)" else "Optional cover image") }
            }
        }, confirmButton={TextButton(onClick={
            if(titleInput.isNotBlank()) { val b=Book(title=titleInput.trim(),author=authorInput.trim(),language=bookLanguage,description=descriptionInput.trim(),size=sizeInput,orientation=orientationInput,pages= mutableListOf(BookPage(type="cover",title=if(ar) "الغلاف الأمامي" else "Front cover",imagePath=createCoverPath),BookPage(title=if(ar) "الصفحة الأولى" else "Page 1")));books.add(b);persist();showCreate=false;openEditor(b) }
        }){Text(if(ar) "إنشاء الكتاب" else "Create book")}}, dismissButton={TextButton(onClick={showCreate=false}){Text(if(ar) "إلغاء" else "Cancel")}})
        if(showSettings) AlertDialog(onDismissRequest={showSettings=false},title={Text(if(ar) "الإعدادات" else "Settings")},text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text(if(ar) "لغة التطبيق" else "App language",fontWeight=FontWeight.Bold)
            Row { FilterChip(selected=ar,onClick={language="ar"},label={Text("العربية")});Spacer(Modifier.width(8.dp));FilterChip(selected=!ar,onClick={language="en"},label={Text("English")}) }
            Text(if(ar) "اللون الأساسي" else "Primary color",fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){ listOf(0xFF176044,0xFF2457A6,0xFF7041A6,0xFFA64B35,0xFFB17A18,0xFF344054).forEach { c->Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).border(if(primary==c)3.dp else 0.dp,Color.Black,CircleShape).clickable{primary=c}) } }
        }},confirmButton={TextButton(onClick={prefs.edit().putString("language",language).putLong("primary",primary).apply();showSettings=false}){Text(if(ar) "حفظ الإعدادات" else "Save settings")}})
        if(toast.isNotBlank()) LaunchedEffect(toast) { kotlinx.coroutines.delay(2400);toast="" }
    }
}

@Composable
private fun HomeScreen(books: List<Book>, filter: String, ar: Boolean, green: Color, onFilter:(String)->Unit, onCreate:()->Unit, onOpen:(Book)->Unit, onFavorite:(Book)->Unit, onStatus:(Book,String)->Unit, onDelete:(Book)->Unit) {
    val labels=if(ar) listOf("باقي الكتب","المفضلة","للقراءة لاحقًا","تمت القراءة","ما زلت أقرأ") else listOf("Other books","Favorites","Read later","Completed","Currently reading")
    val keys=listOf("all","favorites","later","completed","reading")
    val shown=books.filter { when(filter){"favorites"->it.isFavorite;"all"->it.readingStatus=="other";else->it.readingStatus==filter} }.sortedByDescending{it.updated}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text(if(ar) "اصنع كتابك بطريقتك" else "Create your book your way",fontSize=25.sp,fontWeight=FontWeight.Bold,color=Color(0xFF172820))
        Text(if(ar) "أنشئ مكتبتك الخاصة، ثم افتح أي كتاب للتعديل أو القراءة ومتابعة آخر صفحة وصلت إليها." else "Build your own library, then open any book to edit, read, and resume where you left off.",color=Color(0xFF718078),fontSize=13.sp)
        Button(onClick=onCreate,modifier=Modifier.fillMaxWidth().padding(vertical=14.dp),colors=ButtonDefaults.buttonColors(containerColor=green),shape=RoundedCornerShape(11.dp)){Icon(Icons.Default.Add,null);Text(if(ar) "إنشاء كتاب جديد" else "Create new book")}
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){keys.forEachIndexed{i,k->FilterChip(selected=filter==k,onClick={onFilter(k)},label={Text(labels[i])})}}
        Spacer(Modifier.height(12.dp))
        if(shown.isEmpty()) Box(Modifier.fillMaxWidth().padding(35.dp),contentAlignment=Alignment.Center){Text(if(books.isEmpty()){if(ar) "لا توجد كتب بعد. استخدم زر «إنشاء كتاب جديد» للبدء." else "No books yet. Use Create new book to get started."}else{if(ar) "لا توجد كتب في هذا التصنيف حتى الآن." else "No books in this category yet."},color=Color.Gray,textAlign=TextAlign.Center)}
        shown.forEach { b ->
            Card(Modifier.fillMaxWidth().padding(bottom=12.dp).clickable{onOpen(b)},shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    BookCover(b,Modifier.size(width=94.dp,height=128.dp),green)
                    Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)) {
                        Text(b.title,fontWeight=FontWeight.Bold,fontSize=17.sp)
                        Text("${b.pages.size} ${if(ar) "صفحة" else "pages"} · ${b.author.ifBlank{if(ar) "مؤلف غير محدد" else "Unknown author"}}",fontSize=12.sp,color=Color.Gray)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={onFavorite(b)}){Icon(if(b.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(b.isFavorite) Color.Red else green)};TextButton(onClick={onOpen(b)}){Text(if(ar) "فتح الكتاب" else "Open book")};IconButton(onClick={onDelete(b)}){Icon(Icons.Default.Delete,null,tint=Color.Red)}}
                        var expanded by remember { mutableStateOf(false) }
                        Box { OutlinedButton(onClick={expanded=true},contentPadding=PaddingValues(horizontal=8.dp,vertical=3.dp)){Text(statusName(b.readingStatus,ar),fontSize=11.sp)};DropdownMenu(expanded,{expanded=false}){listOf("other","later","reading","completed").forEach{s->DropdownMenuItem(text={Text(statusName(s,ar))},onClick={expanded=false;onStatus(b,s)})}} }
                    }
                }
            }
        }
    }
}

@Composable private fun BookCover(book: Book, modifier: Modifier=Modifier, green: Color=Color(GREEN)) {
    val path=book.pages.firstOrNull{it.type=="cover"}?.imagePath.orEmpty()
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(if(path.isBlank()) green else Color.White),contentAlignment=Alignment.Center){
        val bmp=remember(path){if(path.isNotBlank()) BitmapFactory.decodeFile(path) else null}
        if(bmp!=null) Image(bmp.asImageBitmap(),null,Modifier.fillMaxSize()) else Text("م",fontSize=40.sp,fontWeight=FontWeight.Black,color=Color(0xFFEAF4ED))
    }
}

@Composable private fun DetailsScreen(book: Book, ar: Boolean, onEdit:()->Unit, onRead:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        BookCover(book,Modifier.size(width=205.dp,height=290.dp))
        Spacer(Modifier.height(22.dp));Text(book.title,fontSize=27.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
        Text("${book.author.ifBlank{if(ar) "مؤلف غير محدد" else "Unknown author"}} · ${book.pages.size} ${if(ar) "صفحة" else "pages"} · ${book.language}",color=Color.Gray,textAlign=TextAlign.Center)
        if(book.description.isNotBlank()) Text(book.description,Modifier.padding(top=12.dp),textAlign=TextAlign.Center)
        Spacer(Modifier.height(20.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick=onEdit){Text(if(ar) "✎ تعديل الكتاب" else "✎ Edit book")};OutlinedButton(onClick=onRead){Text(if(ar) "◉ قراءة الكتاب" else "◉ Read book")}}
        Text(if(book.lastReadIndex>0){if(ar) "آخر موضع قراءة محفوظ: الصفحة ${book.lastReadIndex}. يمكنك المتابعة من حيث توقفت." else "Last saved position: page ${book.lastReadIndex}. Resume reading."}else{if(ar) "لم تبدأ قراءة هذا الكتاب بعد." else "You have not started reading this book yet."},Modifier.padding(top=18.dp).fillMaxWidth().background(Color(0xFFEDF5EF),RoundedCornerShape(11.dp)).padding(14.dp),color=Color(0xFF315D45),textAlign=TextAlign.Center,fontSize=13.sp)
    }
}

@Composable private fun EditorScreen(book: Book, selected: Int, ar: Boolean, green: Color, onSelect:(Int)->Unit, onAdd:()->Unit, onUpload:()->Unit, onImportImages:()->Unit, onMove:(Int)->Unit, onAddBack:()->Unit, onDuplicate:()->Unit, onDelete:()->Unit, onChange:()->Unit, onExport:()->Unit) {
    val page=book.pages.getOrNull(selected) ?: return
    var tab by remember { mutableStateOf("pages") }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("pages" to if(ar) "الصفحات" else "Pages","design" to if(ar) "إعدادات الصفحة" else "Page settings","export" to if(ar) "المشروع" else "Project").forEach{(k,v)->FilterChip(selected=tab==k,onClick={tab=k},label={Text(v,fontSize=12.sp)})}}
        when(tab){
            "pages" -> {
                Text("${if(ar) "صفحات الكتاب" else "Book pages"} (${book.pages.size})",fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
                Row(Modifier.fillMaxWidth().height(138.dp).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) { book.pages.forEachIndexed{i,p->Column(Modifier.width(92.dp).clip(RoundedCornerShape(9.dp)).background(if(i==selected) Color(0xFFE7F1EB) else Color.White).border(if(i==selected)2.dp else 1.dp,if(i==selected)green else Color(0xFFDfe8e1),RoundedCornerShape(9.dp)).clickable{onSelect(i)}.padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally){PageThumbnail(p,Modifier.weight(1f).fillMaxWidth());Text(p.title.ifBlank{if(ar) "صفحة ${i+1}" else "Page ${i+1}"},fontSize=10.sp,maxLines=1)} } }
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick=onAdd,modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Text(if(ar) "إضافة صفحة" else "Add page",fontSize=11.sp)};OutlinedButton(onClick=onUpload,modifier=Modifier.weight(1f)){Icon(Icons.Default.Image,null);Text(if(ar) "رفع صورة" else "Upload",fontSize=11.sp)}}
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick=onImportImages,modifier=Modifier.weight(1f)){Text(if(ar) "استيراد صور كصفحات" else "Import images as pages",fontSize=10.sp)};OutlinedButton(onClick=onAddBack,modifier=Modifier.weight(1f)){Text(if(ar) "إضافة غلاف خلفي" else "Add back cover",fontSize=10.sp)}}
            }
            "design" -> {
                Text(if(ar) "إعدادات الصفحة" else "Page settings",fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
                OutlinedTextField(page.title,{page.title=it;onChange()},label={Text(if(ar) "اسم / وصف الصفحة" else "Page title / description")},modifier=Modifier.fillMaxWidth())
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=page.type=="cover",onClick={page.type="cover";onChange()},label={Text(if(ar) "الغلاف الأمامي" else "Front cover")});FilterChip(selected=page.type=="back",onClick={page.type="back";onChange()},label={Text(if(ar) "الغلاف الخلفي" else "Back cover")});FilterChip(selected=page.type=="content",onClick={page.type="content";onChange()},label={Text(if(ar) "داخلية" else "Content")})}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=page.fit=="contain",onClick={page.fit="contain";onChange()},label={Text(if(ar) "ملاءمة الصورة" else "Fit image")});FilterChip(selected=page.fit=="cover",onClick={page.fit="cover";onChange()},label={Text(if(ar) "ملء الصفحة" else "Fill page")})}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedButton(onClick={page.rotation=(page.rotation+90)%360;onChange()}){Text(if(ar) "تدوير 90°" else "Rotate 90°")};OutlinedButton(onClick={page.imagePath="";onChange()}){Text(if(ar) "إزالة الصورة" else "Remove image")};OutlinedButton(onClick=onUpload){Text(if(ar) "رفع صورة" else "Upload")}}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedButton(onClick={onMove(-1)},enabled=selected>0){Text(if(ar) "تحريك لأعلى ↑" else "Move up ↑")};OutlinedButton(onClick={onMove(1)},enabled=selected<book.pages.lastIndex){Text(if(ar) "تحريك لأسفل ↓" else "Move down ↓")};OutlinedButton(onClick=onDuplicate){Text(if(ar) "نسخ" else "Duplicate")}}
                Button(onClick=onDelete,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFC84450))){Text(if(ar) "حذف الصفحة" else "Delete page")}
                Spacer(Modifier.height(10.dp));Text(if(ar) "لون خلفية الصفحة" else "Page background",fontWeight=FontWeight.SemiBold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(0xFFFFFFFF,0xFFFFFDF7,0xFFF2F5F3,0xFFEAF0F8,0xFFFFF0E6).forEach{c->Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c)).border(1.dp,Color.LightGray,CircleShape).clickable{page.bg=c;onChange()})}}
                Spacer(Modifier.height(10.dp));Text(if(ar) "اتجاه الكتاب" else "Book orientation");Row{FilterChip(selected=book.orientation=="portrait",onClick={book.orientation="portrait";onChange()},label={Text(if(ar) "طولي" else "Portrait")});FilterChip(selected=book.orientation=="landscape",onClick={book.orientation="landscape";onChange()},label={Text(if(ar) "عرضي" else "Landscape")})}
            }
            else -> { Text(if(ar) "إدارة المشروع" else "Project management",fontWeight=FontWeight.Bold);Button(onClick=onExport){Icon(Icons.Default.Share,null);Text(if(ar) "تصدير المشروع" else "Export project")};Text(if(ar) "يمكنك فتح ملف مشروع مكتبتي بصيغة JSON من تطبيق الملفات." else "You can import a Maktabati JSON project using the system document picker.") }
        }
        Spacer(Modifier.height(12.dp));Text(if(ar) "معاينة الصفحة الحالية" else "Current page preview",fontWeight=FontWeight.SemiBold)
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp).background(Color(0xFFE6EEE8),RoundedCornerShape(15.dp)).padding(12.dp),contentAlignment=Alignment.Center){
            val aspect=if(book.orientation=="landscape") 1.414f else .707f
            PageDisplay(page,Modifier.fillMaxHeight().widthIn(max=420.dp).aspectRatio(aspect))
        }
        Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){TextButton(onClick={if(selected>0)onSelect(selected-1)}){Text(if(ar) "السابق" else "Previous")};Text("${selected+1}/${book.pages.size}",modifier=Modifier.align(Alignment.CenterVertically));TextButton(onClick={if(selected<book.pages.lastIndex)onSelect(selected+1)}){Text(if(ar) "التالي" else "Next")}}
    }
}

@Composable private fun PageThumbnail(page: BookPage, modifier: Modifier=Modifier){PageDisplay(page,modifier.background(Color.White))}
@Composable private fun PageDisplay(page: BookPage, modifier: Modifier=Modifier){
    val bmp=remember(page.imagePath){if(page.imagePath.isNotBlank())BitmapFactory.decodeFile(page.imagePath) else null}
    Box(modifier.background(Color(page.bg)),contentAlignment=Alignment.Center){if(bmp!=null)Image(bmp.asImageBitmap(),null,Modifier.fillMaxSize().graphicsLayer(rotationZ=page.rotation.toFloat()),contentScale=if(page.fit=="cover") androidx.compose.ui.layout.ContentScale.Crop else androidx.compose.ui.layout.ContentScale.Fit) else Text(page.title.ifBlank{"▧"},color=Color.Gray,textAlign=TextAlign.Center)}
}

@Composable private fun ReaderScreen(book: Book, index: Int, ar: Boolean, onIndex:(Int)->Unit, onPdf:()->Unit){
    val page=book.pages.getOrNull(index)
    var drag by remember(index) { mutableFloatStateOf(0f) }
    Column(Modifier.fillMaxSize().padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(book.title,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));IconButton(onClick=onPdf){Icon(Icons.Default.Print,null)}}
        Text(if(index==0){if(ar) "الغلاف الأمامي" else "Front cover"}else if(ar) "الصفحة $index من ${book.pages.lastIndex}" else "Page $index of ${book.pages.lastIndex}",color=Color.Gray,fontSize=13.sp)
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical=10.dp).background(Color(0xFF0D2118),RoundedCornerShape(12.dp)).padding(10.dp).pointerInput(index){detectHorizontalDragGestures(onHorizontalDrag={_,amount->drag+=amount},onDragEnd={if(drag < -40f && index<book.pages.lastIndex)onIndex(index+1) else if(drag > 40f && index>0)onIndex(index-1);drag=0f})},contentAlignment=Alignment.Center){
            PageDisplay(page?:BookPage(),Modifier.fillMaxHeight().fillMaxWidth(.92f).aspectRatio(if(book.orientation=="landscape")1.414f else .707f))
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){OutlinedButton(onClick={if(index>0)onIndex(index-1)},enabled=index>0,modifier=Modifier.weight(1f)){Icon(Icons.Default.ChevronLeft,null);Text(if(ar) "الصفحة السابقة" else "Previous")};Button(onClick={if(index<book.pages.lastIndex)onIndex(index+1)},enabled=index<book.pages.lastIndex,modifier=Modifier.weight(1f)){Text(if(ar) "الصفحة التالية" else "Next");Icon(Icons.Default.ChevronRight,null)}}
        TextButton(onClick={onIndex(0)}){Text(if(ar) "العودة إلى الغلاف" else "Return to cover")}
    }
}

private fun statusName(s:String,ar:Boolean)=if(ar) when(s){"later"->"للقراءة لاحقًا";"completed"->"تمت القراءة";"reading"->"ما زلت أقرأ";else->"باقي الكتب"} else when(s){"later"->"Read later";"completed"->"Completed";"reading"->"Currently reading";else->"Other books"}
private fun safeName(s:String)=(s.ifBlank{"book"}.replace(Regex("[\\\\/:*?\"<>|]"),"_").take(60))
private fun copyUri(context:android.content.Context,uri:Uri,dir:File):String?=try{dir.mkdirs();val f=File(dir,"img_${UUID.randomUUID()}.bin");context.contentResolver.openInputStream(uri)?.use{input->f.outputStream().use{input.copyTo(it)}};f.absolutePath}catch(_:Exception){null}
private fun loadBooks(file:File,dir:File):List<Book>{if(!file.exists())return emptyList();return try{val arr=JSONArray(file.readText());(0 until arr.length()).map{objToBook(arr.getJSONObject(it))}.toMutableList()}catch(_:Exception){emptyList()}}
private fun persistBooks(file:File,books:List<Book>){file.parentFile?.mkdirs();val arr=JSONArray();books.forEach{arr.put(bookToJson(it,false))};file.writeText(arr.toString())}
private fun bookToJson(b:Book,embed:Boolean):JSONObject=JSONObject().apply{
    put("id",b.id);put("title",b.title);put("author",b.author);put("language",b.language);put("description",b.description);put("size",b.size);put("orientation",b.orientation);put("readingStatus",b.readingStatus);put("isFavorite",b.isFavorite);put("created",b.created);put("updated",b.updated);put("lastReadIndex",b.lastReadIndex)
    val a=JSONArray();b.pages.forEach{p->a.put(JSONObject().apply{put("id",p.id);put("type",p.type);put("title",p.title);put("fit",p.fit);put("rotation",p.rotation);put("bg",p.bg);if(embed&&p.imagePath.isNotBlank()){val f=File(p.imagePath);if(f.exists())put("imageBase64",android.util.Base64.encodeToString(f.readBytes(),android.util.Base64.NO_WRAP))}else put("imagePath",p.imagePath)})};put("pages",a)
}
private fun objToBook(o:JSONObject):Book{val pages=mutableListOf<BookPage>();val a=o.optJSONArray("pages")?:JSONArray();for(i in 0 until a.length()){val p=a.getJSONObject(i);pages.add(BookPage(p.optString("id",UUID.randomUUID().toString()),p.optString("type","content"),p.optString("title"),p.optString("imagePath"),p.optString("fit","contain"),p.optInt("rotation"),p.optLong("bg",0xFFFFFFFF)))};return Book(o.optString("id",UUID.randomUUID().toString()),o.optString("title","Untitled"),o.optString("author"),o.optString("language","العربية"),o.optString("description"),o.optString("size","a5"),o.optString("orientation","portrait"),pages,o.optString("readingStatus","other"),o.optBoolean("isFavorite"),o.optLong("created"),o.optLong("updated"),o.optInt("lastReadIndex"))}
private fun exportBook(context:android.content.Context,uri:Uri,b:Book){val json=bookToJson(b,true);context.contentResolver.openOutputStream(uri)?.use{it.write(json.toString().toByteArray())}?:error("Cannot open destination")}
private fun importBook(context:android.content.Context,uri:Uri,dir:File):Book{val raw=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:error("Empty");val o=JSONObject(raw);val id=UUID.randomUUID().toString();val pages=o.getJSONArray("pages");for(i in 0 until pages.length()){val p=pages.getJSONObject(i);val base=p.optString("imageBase64");if(base.isNotBlank()){val f=File(dir,"img_${UUID.randomUUID()}.bin");f.writeBytes(android.util.Base64.decode(base,android.util.Base64.DEFAULT));p.put("imagePath",f.absolutePath)};p.remove("imageBase64")};o.put("id",id);return objToBook(o).also{it.updated=System.currentTimeMillis()}}
private fun writePdf(context:android.content.Context,uri:Uri,b:Book){
    val pdf=PdfDocument();val w=if(b.orientation=="landscape")842 else 595;val h=if(b.orientation=="landscape")595 else 842
    b.pages.forEachIndexed{i,p->val info=PdfDocument.PageInfo.Builder(w,h,i+1).create();val page=pdf.startPage(info);val c=page.canvas;c.drawColor(p.bg.toInt());val bmp=if(p.imagePath.isNotBlank())BitmapFactory.decodeFile(p.imagePath) else null
        if(bmp!=null){val source=RectF(0f,0f,bmp.width.toFloat(),bmp.height.toFloat());val target=RectF(20f,20f,(w-20).toFloat(),(h-20).toFloat());val ratio=if(p.fit=="cover")maxOf(target.width()/source.width(),target.height()/source.height()) else minOf(target.width()/source.width(),target.height()/source.height());val dw=source.width()*ratio;val dh=source.height()*ratio;val dst=RectF((w-dw)/2,(h-dh)/2,(w+dw)/2,(h+dh)/2);c.save();c.rotate(p.rotation.toFloat(),w/2f,h/2f);c.drawBitmap(bmp,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG));c.restore()}
        else{val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.DKGRAY;textSize=24f;textAlign=Paint.Align.CENTER};c.drawText(p.title.ifBlank{" "},w/2f,h/2f,paint)};pdf.finishPage(page)}
    context.contentResolver.openOutputStream(uri)?.use{pdf.writeTo(it)} ?: error("Cannot write PDF");pdf.close()
}
