# Maktabati — Native Android project

This archive contains the Android Studio / GitHub Actions project for **Maktabati**. The app is written in Kotlin with Jetpack Compose.

## Included project features

- Arabic and English interface, theme preferences, and primary color settings.
- Library views, search, sorting, categories/tags, favorites, and book management.
- Book/page editing, image import, and automatic page proportions based on the imported image rather than asking the user to choose A4/A5.
- Page elements such as text, shapes, and lines, with editing controls and layer-related operations included in the editor source.
- Reader navigation, reading-position persistence, progress, night mode, and immersive display.
- Storage screen, trash/recovery operations, and library backup/restore flows.
- PDF export and local app-private storage.

## Upload to GitHub from Android

1. Extract this ZIP file.
2. Open the extracted `MaktabatiNative` folder.
3. Upload the **contents** of `MaktabatiNative` to the root of a new GitHub repository. Make sure the hidden `.github` folder is included.
4. Open the repository's **Actions** tab. The workflow named **Android APK Build** runs on pushes to `main` or `master`; it can also be started manually with **Run workflow**.
5. When the workflow succeeds, open its run and download the `maktabati-debug-apk` artifact.

## Project configuration

- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- JDK: 17
- Compile SDK: 35
- Minimum SDK: 23
- Jetpack Compose + Material 3

## Important verification note

The source files and project structure have been packaged, and the ZIP archive has been integrity-checked. An Android Gradle compilation and runtime test were **not** performed in this environment. The first GitHub Actions run is therefore the required compilation check. If it fails, share the complete Actions error log so the exact Kotlin/Gradle issue can be corrected. No APK was built locally.
